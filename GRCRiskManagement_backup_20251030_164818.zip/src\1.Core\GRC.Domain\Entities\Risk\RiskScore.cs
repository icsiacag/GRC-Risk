﻿namespace GRC.Domain.Entities.Risk
{
    public class RiskScore
    {
        public int Id { get; set; }
        public int RiskId { get; set; }
        public decimal InherentRisk { get; set; }
        public decimal ResidualRisk { get; set; }
        public decimal Likelihood { get; set; }
        public decimal Impact { get; set; }
        public decimal OverallScore { get; set; }
        public string CalculationMethod { get; set; } = string.Empty;
        public DateTime CalculatedAt { get; set; } = DateTime.UtcNow;
        public string CalculatedBy { get; set; } = string.Empty;
        
        // Navigation
        public virtual GRC.Domain.Entities.RiskManagement.Risk? Risk { get; set; }
    }
}
