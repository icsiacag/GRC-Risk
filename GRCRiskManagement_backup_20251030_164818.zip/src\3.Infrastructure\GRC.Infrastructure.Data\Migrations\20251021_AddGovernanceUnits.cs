using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GRC.Infrastructure.Data.Migrations
{
 public partial class AddGovernanceUnits : Migration
 {
 protected override void Up(MigrationBuilder migrationBuilder)
 {
 migrationBuilder.CreateTable(
 name: "GovernanceUnits",
 columns: table => new
 {
 Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
 Name = table.Column<string>(type: "nvarchar(500)", maxLength:500, nullable: false),
 Type = table.Column<string>(type: "nvarchar(100)", maxLength:100, nullable: true),
 ParentId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
 SortOrder = table.Column<int>(type: "int", nullable: false)
 },
 constraints: table =>
 {
 table.PrimaryKey("PK_GovernanceUnits", x => x.Id);
 });

 migrationBuilder.CreateIndex(
 name: "IX_GovernanceUnits_ParentId",
 table: "GovernanceUnits",
 column: "ParentId");
 }

 protected override void Down(MigrationBuilder migrationBuilder)
 {
 migrationBuilder.DropTable(name: "GovernanceUnits");
 }
 }
}
