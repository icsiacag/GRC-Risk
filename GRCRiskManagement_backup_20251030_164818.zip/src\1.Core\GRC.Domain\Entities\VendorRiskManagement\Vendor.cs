﻿using System;
using System.Collections.Generic;
using GRC.SharedKernel;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.VendorRiskManagement
{
    /// <summary>
    /// Vendor entity for GRC system
    /// Generated on: 2025-10-30 16:18:22
    /// </summary>
    public class Vendor : GRC.SharedKernel.Entities.BaseEntity
    {
        public string VendorName { get; set; }
        public string VendorCode { get; set; }
        public VendorType Type { get; set; }
        public string ContactPerson { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
        public VendorStatus Status { get; set; }
        public RiskLevel RiskRating { get; set; }
        public DateTime OnboardingDate { get; set; }
        public DateTime? LastAssessmentDate { get; set; }
        public List<VendorRisk> Risks { get; set; }
        public List<VendorAssessment> Assessments { get; set; }
        public List<VendorContract> Contracts { get; set; }
        
        // Navigation properties and domain logic can be added here
        
        /// <summary>
        /// Validates the entity state
        /// </summary>
        
        /// <summary>
        /// Domain event when entity is created
        /// </summary>
        public void OnCreated()
        {
            CreatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
        
        /// <summary>
        /// Domain event when entity is updated
        /// </summary>
        public void OnUpdated()
        {
            UpdatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
    }
}



