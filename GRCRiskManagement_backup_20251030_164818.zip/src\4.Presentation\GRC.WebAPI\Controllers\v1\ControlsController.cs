using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using GRC.Infrastructure.Data.Content;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using GRC.Domain.Entities.Controls;

namespace GRC.WebAPI.Controllers.v1
{
 [ApiController]
 [Route("api/v1/controls")]
 public class ControlsController : ControllerBase
 {
 private readonly GRCDbContext _db;
 public ControlsController(GRCDbContext db) { _db = db; }

 [HttpGet]
 public async Task<IActionResult> GetAll() { var list = await _db.Set<Control>().Include(c => c.TestRecords).ToListAsync(); return Ok(list); }

 [HttpGet("{id}")]
 public async Task<IActionResult> Get(int id) { var ctl = await _db.Set<Control>().Include(c => c.TestRecords).FirstOrDefaultAsync(c => c.Id == id); if (ctl == null) return NotFound(); return Ok(ctl); }

 [HttpPost]
 [Authorize]
 public async Task<IActionResult> Create([FromBody] Control model) { _db.Controls.Add(model); await _db.SaveChangesAsync(); return CreatedAtAction(nameof(Get), new { id = model.Id }, model); }

 [HttpPut("{id}")]
 [Authorize]
 public async Task<IActionResult> Update(int id, [FromBody] Control model)
 {
 var existing = await _db.Controls.FindAsync(id);
 if (existing == null) return NotFound();
 // Map allowed fields only
 existing.Name = model.Name;
 existing.Description = model.Description;
 existing.ControlCode = model.ControlCode;
 existing.ControlType = model.ControlType;
 existing.Category = model.Category;
 existing.Frequency = model.Frequency;
 existing.Owner = model.Owner;
 existing.ControlUnitId = model.ControlUnitId;
 existing.ActionType = model.ActionType;
 // Note: do not overwrite TestRecords here; separate endpoints handle test history
 _db.Controls.Update(existing);
 await _db.SaveChangesAsync();
 return Ok(existing);
 }

 [HttpPost("{id}/test")]
 [Authorize]
 public async Task<IActionResult> AddTest(int id, [FromBody] ControlTestRecord input)
 {
 var ctl = await _db.Set<Control>().FindAsync(id);
 if (ctl == null) return NotFound();
 input.ControlId = id;
 _db.Add(input);
 await _db.SaveChangesAsync();
 return Ok(input);
 }

 [HttpGet("units")]
 public async Task<IActionResult> GetUnits()
 {
 var units = await _db.Set<GRC.Domain.Entities.Controls.ControlUnit>().ToListAsync();
 return Ok(units);
 }
 }
}
