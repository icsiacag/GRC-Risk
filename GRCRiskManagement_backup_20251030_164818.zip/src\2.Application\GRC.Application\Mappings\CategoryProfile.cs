using AutoMapper;
using GRC.Application.Contracts.DTOs.Categories;
using System.Reflection;
using System.Collections.Generic;

namespace GRC.Application.Mappings
{
 public class CategoryProfile : Profile
 {
 public CategoryProfile()
 {
 // Map concrete RiskCategory type from RiskManagement project to CategoryDto using reflection-based mapper
 CreateMap<GRC.Domain.Entities.RiskManagement.RiskCategory, CategoryDto>()
 .ConstructUsing(src => MapToDto(src));

 // Fallback generic mapping for objects
 CreateMap<object, CategoryDto>()
 .ConstructUsing((src, ctx) => MapToDto(src));
 }

 private static CategoryDto MapToDto(object src)
 {
 var dto = new CategoryDto();
 var type = src.GetType();

 dto.CategoryType = type.Name;
 dto.Name = TryGet<string>(src, "Name") ?? string.Empty;
 dto.Description = TryGet<string>(src, "Description") ?? string.Empty;
 dto.Color = TryGet<string>(src, "Color") ?? string.Empty;
 dto.MetadataJson = TryGet<string>(src, "MetadataJson");

 // generic details dictionary
 dto.Details = MapDetailsDictionary(src);

 // typed sub DTOs (populate if expected properties exist)
 // Technologic details
 if (HasAnyProperty(src, new[] { "TechStackVulnerabilities", "TechDomain", "RequiresPenTest" }))
 {
 var tech = new TechnologicDetailsDto
 {
 TechStackVulnerabilities = TryGet<string>(src, "TechStackVulnerabilities") ?? TryGet<string>(src, "TechDomain"),
 InnovationAdoptionRate = TryGet<double?>(src, "InnovationAdoptionRate")
 };
 dto.TechnologicDetails = tech;
 }

 // Programmatic project details
 if (HasAnyProperty(src, new[] { "MilestoneDependencies", "BudgetVariances" }))
 {
 dto.ProgrammaticProjectDetails = new ProgrammaticProjectDetailsDto
 {
 MilestoneDependencies = TryGet<string>(src, "MilestoneDependencies"),
 BudgetVariances = TryGet<decimal?>(src, "BudgetVariances")
 };
 }

 // ESG
 if (HasAnyProperty(src, new[] { "ESGPillars", "SustainabilityReportingStandards", "CarbonFootprint" }))
 {
 var pillars = TryGet<string>(src, "ESGPillars");
 var standards = TryGet<string>(src, "SustainabilityReportingStandards");
 var esg = new ESGDetailsDto
 {
 CarbonFootprint = TryGet<decimal?>(src, "CarbonFootprint"),
 DiversityScore = TryGet<int?>(src, "DiversityScore"),
 GovernanceScore = TryGet<int?>(src, "GovernanceScore")
 };
 try { esg.ESGPillars = System.Text.Json.JsonSerializer.Deserialize<System.Collections.Generic.Dictionary<string, decimal>>(pillars ?? "{}"); } catch { esg.ESGPillars = null; }
 try { esg.SustainabilityReportingStandards = System.Text.Json.JsonSerializer.Deserialize<System.Collections.Generic.List<string>>(standards ?? "[]"); } catch { esg.SustainabilityReportingStandards = null; }
 dto.ESGDetails = esg;
 }

 // Human capital
 if (HasAnyProperty(src, new[] { "TalentRetentionMetrics", "DiversityIndices" }))
 {
 var h = new HumanCapitalDetailsDto
 {
 TalentRetentionMetrics = TryGet<double?>(src, "TalentRetentionMetrics") ?? TryGet<double?>(src, "TalentRetentionMetrics"),
 LinkedProcesses = TryGet<System.Collections.Generic.List<object>>(src, "LinkedProcesses")
 };
 try { h.DiversityIndices = System.Text.Json.JsonSerializer.Deserialize<System.Collections.Generic.Dictionary<string, double>>(TryGet<string>(src, "DiversityIndices") ?? "{}"); } catch { h.DiversityIndices = null; }
 dto.HumanCapitalDetails = h;
 }

 // Supply chain
 if (HasAnyProperty(src, new[] { "SupplierDependencies", "DisruptionScenarios" }))
 {
 var sc = new SupplyChainDetailsDto
 {
 SupplierDependencies = TryGet<System.Collections.Generic.List<string>>(src, "SupplierDependencies") ?? TryGet<System.Collections.Generic.List<string>>(src, "SupplierDependencies"),
 DisruptionScenarios = TryGet<System.Collections.Generic.List<string>>(src, "DisruptionScenarios") ?? TryGet<System.Collections.Generic.List<string>>(src, "DisruptionScenarios"),
 LinkedSubsidiaries = TryGet<System.Collections.Generic.List<object>>(src, "LinkedSubsidiaries")
 };
 dto.SupplyChainDetails = sc;
 }

 return dto;
 }

 private static Dictionary<string, object?> MapDetailsDictionary(object src)
 {
 var dict = new Dictionary<string, object?>();
 var propsToCheck = new[]
 {
 "TechStackVulnerabilities","InnovationAdoptionRate","ObsolescenceScore",
 "ESGPillars","SustainabilityReportingStandards",
 "MilestoneDependencies","BudgetVariances","ProjectComplexityScore","CriticalPath",
 "AssetProtectionLevels","ThreatVectors",
 "TalentRetentionMetrics","DiversityIndices",
 "SupplierDependencies","DisruptionScenarios",
 "JurisdictionLaws","PenaltyEstimates",
 "CountryRiskScores","TradeBarrierFlags",
 "PatentExposures","TechAdoptionRisks"
 };

 foreach (var p in propsToCheck)
 {
 var val = TryGet<object>(src, p);
 if (val != null) dict[p] = val;
 }

 return dict;
 }

 private static T? TryGet<T>(object src, string propName)
 {
 var pi = src.GetType().GetProperty(propName, BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase);
 if (pi == null) return default;
 try
 {
 var v = pi.GetValue(src);
 if (v == null) return default;
 if (v is T t) return t;
 // attempt conversions for common numeric types
 return (T)Convert.ChangeType(v, typeof(T));
 }
 catch
 {
 return default;
 }
 }

 private static bool HasAnyProperty(object src, string[] names)
 {
 var t = src.GetType();
 foreach (var n in names)
 {
 if (t.GetProperty(n, BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase) != null) return true;
 }
 return false;
 }
 }
}
