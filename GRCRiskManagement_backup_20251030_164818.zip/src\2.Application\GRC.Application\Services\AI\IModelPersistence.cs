using System.IO;
using System.Threading.Tasks;

namespace GRC.Application.Services.AI
{
 public interface IModelPersistence
 {
 Task SaveModelAsync(string name, Stream modelStream);
 Task<Stream?> LoadModelAsync(string name);
 Task<bool> ExistsAsync(string name);
 }
}
