﻿using System;
using System.Collections.Generic;
using GRC.SharedKernel;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.RiskAppetite
{
    /// <summary>
    /// RiskAppetiteStatement entity for GRC system
    /// Generated on: 2025-10-30 16:18:22
    /// </summary>
    public class RiskAppetiteStatement : GRC.SharedKernel.Entities.BaseEntity
    {
        public string StatementText { get; set; }
        public RiskCategory Category { get; set; }
        public RiskLevel AcceptableLevel { get; set; }
        public DateTime EffectiveDate { get; set; }
        public DateTime ReviewDate { get; set; }
        public string ApprovedBy { get; set; }
        public bool IsActive { get; set; }
        public List<RiskTolerance> Tolerances { get; set; }
        
        // Navigation properties and domain logic can be added here
        
        /// <summary>
        /// Validates the entity state
        /// </summary>
        
        /// <summary>
        /// Domain event when entity is created
        /// </summary>
        public void OnCreated()
        {
            CreatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
        
        /// <summary>
        /// Domain event when entity is updated
        /// </summary>
        public void OnUpdated()
        {
            UpdatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
    }
}



