namespace GRC.Application.Contracts.DTOs.Categories
{
 public class ProgrammaticProjectDetailsDto
 {
 public string? MilestoneDependencies { get; set; }
 public decimal? BudgetVariances { get; set; }
 }
}