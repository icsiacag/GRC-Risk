﻿using GRC.SharedKernel;
using GRC.Domain.Common;
using System;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.Audit
{
    public class AuditPlan : AuditableEntity<int>
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Status { get; set; }
        public string Scope { get; set; }
        public string Objectives { get; set; }
        public string Criteria { get; set; }
        public string Resources { get; set; }
        public string TeamMembers { get; set; }
    }
}






