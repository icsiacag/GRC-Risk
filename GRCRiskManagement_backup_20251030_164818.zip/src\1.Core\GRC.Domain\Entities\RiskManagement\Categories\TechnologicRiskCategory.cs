﻿using System;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.RiskManagement.Categories
{
 public class TechnologicRiskCategory : RiskCategory
 {
 public string TechDomain { get; set; } = string.Empty; // e.g., Infrastructure, Applications
 public bool RequiresPenTest { get; set; } = false;

 public TechnologicRiskCategory() : base() { }
 public TechnologicRiskCategory(string name, string description, string color) : base(name, description, color) { }
 }
}



