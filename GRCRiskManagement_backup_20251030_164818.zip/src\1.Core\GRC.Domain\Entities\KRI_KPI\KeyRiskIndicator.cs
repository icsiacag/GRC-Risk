﻿using System;
using System.Collections.Generic;
using GRC.SharedKernel;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.KRI_KPI
{
    /// <summary>
    /// KeyRiskIndicator entity for GRC system
    /// Generated on: 2025-10-30 16:18:22
    /// </summary>
    public class KeyRiskIndicator : GRC.SharedKernel.Entities.BaseEntity
    {
        public string KRICode { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public RiskCategory Category { get; set; }
        public string MeasurementUnit { get; set; }
        public decimal GreenThreshold { get; set; }
        public decimal YellowThreshold { get; set; }
        public decimal RedThreshold { get; set; }
        public string DataSource { get; set; }
        public MeasurementFrequency Frequency { get; set; }
        public string Owner { get; set; }
        public bool IsActive { get; set; }
        public List<KRIMeasurement> Measurements { get; set; }
        
        // Navigation properties and domain logic can be added here
        
        /// <summary>
        /// Validates the entity state
        /// </summary>
        
        /// <summary>
        /// Domain event when entity is created
        /// </summary>
        public void OnCreated()
        {
            CreatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
        
        /// <summary>
        /// Domain event when entity is updated
        /// </summary>
        public void OnUpdated()
        {
            UpdatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
    }
}



