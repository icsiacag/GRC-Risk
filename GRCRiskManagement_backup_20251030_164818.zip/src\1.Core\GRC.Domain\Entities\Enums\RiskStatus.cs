﻿namespace GRC.Domain.Entities.Enums
{
    public enum RiskStatus
    {
        Identified = 1,
        Assessed = 2,
        Mitigated = 3,
        Accepted = 4,
        Closed = 5
    }
}


