using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;

namespace GRC.WebAPI.Controllers.v1
{
 [ApiController]
 [Route("api/v1/assets")]
 public class AssetController : ControllerBase
 {
 private static readonly List<AssetDto> Assets = new List<AssetDto>
 {
 new AssetDto{ Id=Guid.NewGuid(), Name="Server-01", Category="Infrastructure", Owner="IT" }
 };
 [HttpGet]
 public ActionResult<IEnumerable<AssetDto>> Get() => Ok(Assets);
 [HttpGet("{id}")]
 public ActionResult<AssetDto> Get(Guid id){ var a=Assets.Find(x=>x.Id==id); if(a==null)return NotFound(); return Ok(a); }
 [HttpPost]
 public ActionResult<AssetDto> Create([FromBody] AssetCreateDto dto){ var a=new AssetDto{ Id=Guid.NewGuid(), Name=dto.Name, Category=dto.Category, Owner=dto.Owner}; Assets.Add(a); return CreatedAtAction(nameof(Get), new { id = a.Id }, a); }
 public class AssetDto{ public Guid Id{get;set;} public string Name{get;set;} public string Category{get;set;} public string Owner{get;set;} }
 public class AssetCreateDto{ public string Name{get;set;} public string Category{get;set;} public string Owner{get;set;} }
 }
}
