﻿using System;

namespace GRC.Audit.Data
{
    public class SecurityAuditLog
    {
        public int Id { get; set; }
        public string UserId { get; set; } = string.Empty;
        public string Action { get; set; } = string.Empty;
        public string Resource { get; set; } = string.Empty;
        public DateTime Timestamp { get; set; } = DateTime.UtcNow;
        public string IpAddress { get; set; } = string.Empty;
        public string? Details { get; set; }
        public bool Success { get; set; }
    }
}
