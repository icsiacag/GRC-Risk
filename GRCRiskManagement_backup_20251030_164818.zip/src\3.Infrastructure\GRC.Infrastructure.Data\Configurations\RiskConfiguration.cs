// ...existing code...
 public class RiskConfiguration : IEntityTypeConfiguration<Risk>
 {
 public void Configure(EntityTypeBuilder<Risk> builder)
 {
 builder.ToTable("Risks");
 builder.HasKey(x => x.Id);
 builder.Property(x => x.Title).HasMaxLength(500).IsRequired();
 builder.Property(x => x.Description).HasColumnType("nvarchar(max)");
 builder.Property(x => x.RiskLevel).HasMaxLength(200);
+ builder.Property(x => x.RiskLevelId).IsRequired(false);
+ builder.HasIndex(x => x.RiskLevelId);
 builder.Property(x => x.Status).HasMaxLength(100);
 builder.Property(x => x.IdentifiedDate).HasColumnType("datetime2");
 builder.HasMany(x => x.Controls).WithOne().HasForeignKey("RiskId").OnDelete(DeleteBehavior.Cascade);
 }
 }
// ...existing code...