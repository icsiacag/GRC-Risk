﻿using Microsoft.EntityFrameworkCore;
using GRC.Infrastructure.Data.Content;
using GRC.SharedKernel.Interfaces;

namespace GRC.Infrastructure.Data.UnitOfWork;

/// <summary>
/// Unit of Work implementation.
/// DbContext already implements UoW pattern, this is a wrapper.
/// </summary>
public class UnitOfWork : IUnitOfWork
{
    private readonly GRCDbContext _context;

    public UnitOfWork(GRCDbContext context)
    {
        _context = context;
    }

    public async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        return await _context.SaveChangesAsync(cancellationToken);
    }

    public async Task BeginTransactionAsync(CancellationToken cancellationToken = default)
    {
        await _context.BeginTransactionAsync(cancellationToken);
    }

    public async Task CommitTransactionAsync(CancellationToken cancellationToken = default)
    {
        await _context.CommitTransactionAsync(cancellationToken);
    }

    public async Task RollbackTransactionAsync(CancellationToken cancellationToken = default)
    {
        await _context.RollbackTransactionAsync(cancellationToken);
    }

    public void Dispose()
    {
        _context.Dispose();
    }
}



