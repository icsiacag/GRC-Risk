using System.Security.Claims;
using System.Text.Json;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Hosting;
using GRC.Infrastructure.Identity.Services;
using System.Threading.Tasks;
using System.IO;

namespace GRC.WebAPI.Middleware
{
 public class UserEmbeddingMiddleware
 {
 private readonly RequestDelegate _next;
 private readonly IWebHostEnvironment _env;

 private static readonly string[] TargetFiles = new[] { "/dashboard.html", "/enhanced-dashboard.html", "/index.html" };

 public UserEmbeddingMiddleware(RequestDelegate next, IWebHostEnvironment env)
 {
 _next = next;
 _env = env;
 }

 public async Task InvokeAsync(HttpContext context)
 {
 var path = context.Request.Path.Value ?? string.Empty;
 // only run for our target SPA HTML files
 if (!TargetFiles.Contains(path, System.StringComparer.OrdinalIgnoreCase))
 {
 await _next(context);
 return;
 }

 var physical = Path.Combine(_env.WebRootPath ?? "wwwroot", path.TrimStart('/').Replace('/', Path.DirectorySeparatorChar));
 if (!File.Exists(physical))
 {
 await _next(context);
 return;
 }

 string html = await File.ReadAllTextAsync(physical);

 // Build user object
 object? payload = null;
 if (context.User?.Identity != null && context.User.Identity.IsAuthenticated)
 {
 var id = context.User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
 var email = context.User.FindFirst(ClaimTypes.Email)?.Value;
 var fullName = context.User.FindFirst(ClaimTypes.Name)?.Value ?? context.User.Identity.Name;
 var roles = context.User.Claims.Where(c => c.Type == ClaimTypes.Role).Select(c => c.Value).ToArray();

 // attempt to get subscription info if service available
 object? subscription = null;
 try
 {
 var subs = context.RequestServices.GetService(typeof(IUserSubscriptionService)) as IUserSubscriptionService;
 if (subs != null && !string.IsNullOrEmpty(id))
 {
 var sub = await subs.GetActiveSubscriptionAsync(id);
 if (sub != null)
 {
 subscription = new { planId = sub.PlanId, isActive = sub.IsActive, startDate = sub.StartDate, endDate = sub.EndDate, status = sub.Status };
 }
 }
 }
 catch
 {
 // ignore subscription failures
 }

 payload = new { id, email, fullName, roles, subscription };
 }

 var options = new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase, DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull };
 var json = JsonSerializer.Serialize(payload, options);
 var script = $"<script>window.__GRC_USER = {json};</script>";

 // inject before closing </head> if present, otherwise at beginning of body
 var index = html.IndexOf("</head>", System.StringComparison.OrdinalIgnoreCase);
 if (index >=0)
 {
 html = html.Insert(index, script);
 }
 else
 {
 // try body
 index = html.IndexOf("<body", System.StringComparison.OrdinalIgnoreCase);
 if (index >=0)
 {
 // find closing '>' of body tag
 var bodyStart = html.IndexOf('>', index);
 if (bodyStart >=0)
 {
 html = html.Insert(bodyStart +1, script);
 }
 else
 {
 html = script + html;
 }
 }
 else
 {
 html = script + html;
 }
 }

 context.Response.ContentType = "text/html; charset=utf-8";
 await context.Response.WriteAsync(html);
 }
 }
}
