﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GRC.Domain.Entities.IncidentManagement;

using GRC.Domain.Interfaces;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Interfaces
{
    /// <summary>
    /// Repository interface for IncidentResponse
    /// </summary>
    public interface IIncidentResponseRepository : IGenericRepository<IncidentResponse>
    {
        Task<IEnumerable<IncidentResponse>> GetActiveAsync();
        Task<IncidentResponse> GetByCodeAsync(string code);
        Task<IEnumerable<IncidentResponse>> SearchAsync(string searchTerm);
        Task<bool> ExistsAsync(Guid id);
    }
}




