﻿namespace GRC.SharedKernel.Interfaces;

public interface IAggregateRoot { }

