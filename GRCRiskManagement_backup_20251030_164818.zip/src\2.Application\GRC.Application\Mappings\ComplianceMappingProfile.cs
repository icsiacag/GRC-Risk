using AutoMapper;

namespace GRC.Application.Mappings;

public class ComplianceMappingProfile : Profile
{
    public ComplianceMappingProfile()
    {
        // Compliance mapping'ler buraya eklenecek
        // �rnek: CreateMap<ComplianceFramework, ComplianceFrameworkDto>();
    }
}



