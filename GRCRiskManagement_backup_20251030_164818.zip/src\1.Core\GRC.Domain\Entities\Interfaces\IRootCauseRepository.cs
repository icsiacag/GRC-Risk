﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GRC.Domain.Entities.IncidentManagement;

using GRC.Domain.Interfaces;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Interfaces
{
    /// <summary>
    /// Repository interface for RootCause
    /// </summary>
    public interface IRootCauseRepository : IGenericRepository<RootCause>
    {
        Task<IEnumerable<RootCause>> GetActiveAsync();
        Task<RootCause> GetByCodeAsync(string code);
        Task<IEnumerable<RootCause>> SearchAsync(string searchTerm);
        Task<bool> ExistsAsync(Guid id);
    }
}




