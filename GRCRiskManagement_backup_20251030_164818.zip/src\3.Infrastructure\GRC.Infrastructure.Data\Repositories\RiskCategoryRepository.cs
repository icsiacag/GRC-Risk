using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using GRC.Domain.Entities.Risk;
using GRC.Infrastructure.Data.Content;
using GRC.SharedKernel.Interfaces;

namespace GRC.Infrastructure.Data.Repositories
{
 /// <summary>
 /// Repository for risk category operations with polymorphic support
 /// </summary>
 public interface IRiskCategoryRepository : IGenericRepository<RiskCategory>
 {
 Task<List<T>> GetByTypeAsync<T>() where T : RiskCategory;
 Task<RiskCategory?> GetByCodeAsync(string code);
 Task<List<RiskCategory>> GetHierarchyAsync(int rootId);
 Task<Dictionary<string, int>> GetCategoryDistributionAsync();
 }

 public class RiskCategoryRepository : GenericRepository<RiskCategory>, IRiskCategoryRepository
 {
 private readonly GRCDbContext _context;

 public RiskCategoryRepository(GRCDbContext context) : base(context)
 {
 _context = context;
 }

 public async Task<List<T>> GetByTypeAsync<T>() where T : RiskCategory
 {
 return await _context.Set<RiskCategory>()
 .OfType<T>()
 .Include(c => c.Risks)
 .Include(c => c.Children)
 .ToListAsync();
 }

 public async Task<RiskCategory?> GetByCodeAsync(string code)
 {
 return await _context.Set<RiskCategory>()
 .Include(c => c.Parent)
 .Include(c => c.Children)
 .FirstOrDefaultAsync(c => c.Code == code);
 }

 public async Task<List<RiskCategory>> GetHierarchyAsync(int rootId)
 {
 var root = await _context.Set<RiskCategory>()
 .Include(c => c.Children)
 .ThenInclude(c => c.Children)
 .FirstOrDefaultAsync(c => c.Id == rootId);

 return root != null ? FlattenHierarchy(root) : new List<RiskCategory>();
 }

 private List<RiskCategory> FlattenHierarchy(RiskCategory root)
 {
 var result = new List<RiskCategory> { root };
 foreach (var child in root.Children)
 {
 result.AddRange(FlattenHierarchy(child));
 }
 return result;
 }

 public async Task<Dictionary<string, int>> GetCategoryDistributionAsync()
 {
 return await _context.Set<RiskCategory>()
 .GroupBy(c => EF.Property<string>(c, "CategoryType"))
 .Select(g => new { Type = g.Key, Count = g.Count() })
 .ToDictionaryAsync(x => x.Type ?? "Unknown", x => x.Count!);
 }
 }
}
