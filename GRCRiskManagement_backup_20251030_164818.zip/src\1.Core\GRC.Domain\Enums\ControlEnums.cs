using GRC.Domain.Entities.RiskManagement;
namespace GRC.Domain.Enums;

/// <summary>
/// Kontrol tipi - COSO framework standard�.
/// </summary>
public enum ControlType
{
    /// <summary>
    /// �nleyici (Preventive) kontrol - riski olu�madan �nler.
    /// �rnek: Firewall, �ifre politikas�, access control
    /// </summary>
    Preventive = 1,

    /// <summary>
    /// Tespit edici (Detective) kontrol - riski sonradan tespit eder.
    /// �rnek: Log monitoring, audit trail, reconciliation
    /// </summary>
    Detective = 2,

    /// <summary>
    /// D�zeltici (Corrective) kontrol - olu�an zarar� d�zeltir.
    /// �rnek: Backup restore, incident response plan
    /// </summary>
    Corrective = 3,

    /// <summary>
    /// Direktif (Directive) kontrol - y�nlendirici/e�itici.
    /// �rnek: Politika d�k�man�, training programs
    /// </summary>
    Directive = 4
}

/// <summary>
/// Kontrol etkinli�i - test sonu�lar�ndan belirlenir.
/// </summary>
public enum ControlEffectiveness
{
    /// <summary>
    /// Etkisiz - kontrol i�levini yerine getirmiyor.
    /// Risk azalt�m�nda katk� sa�lam�yor (0% reduction).
    /// </summary>
    Ineffective = 0,

    /// <summary>
    /// K�smen etkili - kontrol k�smen �al���yor.
    /// S�n�rl� risk azalt�m� sa�l�yor (10% reduction).
    /// </summary>
    PartiallyEffective = 1,

    /// <summary>
    /// Etkili - kontrol beklenen �ekilde �al���yor.
    /// �nemli risk azalt�m� sa�l�yor (25% reduction).
    /// </summary>
    Effective = 2,

    /// <summary>
    /// �ok etkili - kontrol m�kemmel �al���yor.
    /// Maksimum risk azalt�m� sa�l�yor (40% reduction).
    /// </summary>
    HighlyEffective = 3
}

/// <summary>
/// Kontrol durumu.
/// </summary>
public enum ControlStatus
{
    /// <summary>
    /// Planlanm�� - hen�z devreye al�nmam��.
    /// </summary>
    Planned = 1,

    /// <summary>
    /// Aktif - kontrol �al���yor.
    /// </summary>
    Active = 2,

    /// <summary>
    /// Devre d��� - ge�ici olarak kapal�.
    /// </summary>
    Inactive = 3,

    /// <summary>
    /// �ptal edilmi� - art�k kullan�lm�yor.
    /// </summary>
    Cancelled = 4
}



