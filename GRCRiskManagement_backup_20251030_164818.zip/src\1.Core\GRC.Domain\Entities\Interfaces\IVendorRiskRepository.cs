﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GRC.Domain.Entities.VendorRiskManagement;

using GRC.Domain.Interfaces;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Interfaces
{
    /// <summary>
    /// Repository interface for VendorRisk
    /// </summary>
    public interface IVendorRiskRepository : IGenericRepository<VendorRisk>
    {
        Task<IEnumerable<VendorRisk>> GetActiveAsync();
        Task<VendorRisk> GetByCodeAsync(string code);
        Task<IEnumerable<VendorRisk>> SearchAsync(string searchTerm);
        Task<bool> ExistsAsync(Guid id);
    }
}




