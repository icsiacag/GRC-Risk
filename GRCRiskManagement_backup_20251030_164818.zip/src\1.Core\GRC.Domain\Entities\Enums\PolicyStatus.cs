﻿namespace GRC.Domain.Entities.Enums
{
    public enum PolicyStatus
    {
        Draft = 1,
        UnderReview = 2,
        Approved = 3,
        Active = 4,
        Archived = 5
    }
}


