using System.Threading.Tasks;
using GRC.Domain.Entities.Compliance;

namespace GRC.Domain.Interfaces.Services
{
    public interface IComplianceValidationService
    {
        Task<bool> ValidateFrameworkAsync(ComplianceFramework framework);
        Task<bool> ValidateEvidenceAsync(ComplianceEvidence evidence);
        Task<bool> CheckComplianceAsync(ComplianceFramework framework);
        Task<bool> IsRequirementMetAsync(ComplianceRequirement requirement);
    }
}


