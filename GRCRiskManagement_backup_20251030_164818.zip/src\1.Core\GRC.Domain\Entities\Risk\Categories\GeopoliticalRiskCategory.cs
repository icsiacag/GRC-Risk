﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using GRC.Domain.Entities.RiskManagement;
using GRC.Domain.Common;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.Risk.Categories
{
    public class GeopoliticalRiskCategory : GRC.Domain.Entities.RiskManagement.RiskCategory
    {
        public string? CountryRiskScores { get; set; }
        public bool? TradeBarrierFlags { get; set; }

        public GeopoliticalRiskCategory() : base() { }

        );
        }

        

        public override async Task<List<string>> GetAIRecommendationsAsync()
        {
            var rec = new List<string>();
            if (TradeBarrierFlags == true) rec.Add("Trade barriers detected — review supply chain exposures.");
            return await Task.FromResult(rec);
        }

        private List<decimal> DeserializeScores()
        {
            if (string.IsNullOrWhiteSpace(CountryRiskScores)) return new();
            try { return JsonSerializer.Deserialize<List<decimal>>(CountryRiskScores) ?? new(); } catch { return new(); }
        }

        private string DetermineLevel(decimal score)
        {
            return score switch
            {
                <3 => "Low",
                <6 => "Medium",
                <9 => "High",
                _ => "Critical"
            };
        }

        public override RiskCategoryOutput ExportData()
        {
            var o = base.ExportData();
            o.Metrics["CountryScoresCount"] = DeserializeScores().Count;
            return o;
        }
    }
}





