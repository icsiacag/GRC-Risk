﻿using GRC.SharedKernel;
using GRC.Domain.Common;
using System;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.Audit
{
    public class AuditFinding : AuditableEntity<int>
    {
        public int AuditExecutionId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Severity { get; set; }
        public string Category { get; set; }
        public string Evidence { get; set; }
        public string RootCause { get; set; }
        public string Recommendation { get; set; }
        public DateTime DueDate { get; set; }
        public string Status { get; set; }
    }
}






