using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;

namespace GRC.WebAPI.Controllers.v1
{
 [ApiController]
 [Route("api/v1/privacy")]
 public class PrivacyController : ControllerBase
 {
 private static readonly List<RequestDto> Requests = new List<RequestDto>
 {
 new RequestDto{ Id = Guid.NewGuid(), Type = "Erasure", Date = DateTime.UtcNow, Summary = "User requested deletion of personal data" }
 };
 [HttpGet("requests")]
 public ActionResult<IEnumerable<RequestDto>> GetRequests() => Ok(Requests);
 [HttpPost("requests")]
 public ActionResult<RequestDto> Create([FromBody] CreateDto dto){ var r=new RequestDto{ Id=Guid.NewGuid(), Type=dto.Type, Date=DateTime.UtcNow, Summary=dto.Summary }; Requests.Add(r); return CreatedAtAction(nameof(GetRequests), new { id=r.Id }, r); }
 public class RequestDto{ public Guid Id { get; set; } public string Type { get; set; } public DateTime Date { get; set; } public string Summary { get; set; } }
 public class CreateDto{ public string Type { get; set; } public string Summary { get; set; } }
 }
}
