﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GRC.Domain.Entities.RiskAppetite;

using GRC.Domain.Interfaces;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Interfaces
{
    /// <summary>
    /// Repository interface for RiskAppetiteStatement
    /// </summary>
    public interface IRiskAppetiteStatementRepository : IGenericRepository<RiskAppetiteStatement>
    {
        Task<IEnumerable<RiskAppetiteStatement>> GetActiveAsync();
        Task<RiskAppetiteStatement> GetByCodeAsync(string code);
        Task<IEnumerable<RiskAppetiteStatement>> SearchAsync(string searchTerm);
        Task<bool> ExistsAsync(Guid id);
    }
}




