﻿namespace GRC.Domain.Entities.Enums
{
    public enum ApprovalLevel
    {
        L1 = 1,
        L2 = 2,
        L3 = 3,
        Executive = 4
    }
}


