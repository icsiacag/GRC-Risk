﻿using System;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.RiskManagement.Categories
{
 public class HumanCapitalRiskCategory : RiskCategory
 {
 public bool RequiresTrainingPrograms { get; set; }
 public HumanCapitalRiskCategory() : base() { }
 public HumanCapitalRiskCategory(string name, string description, string color) : base(name, description, color) { }
 }
}



