using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GRC.Infrastructure.Data.Migrations
{
 public partial class AddModelAuditAndFeedback : Migration
 {
 protected override void Up(MigrationBuilder migrationBuilder)
 {
 migrationBuilder.CreateTable(
 name: "ModelAudits",
 columns: table => new
 {
 Id = table.Column<int>(type: "int", nullable: false)
 .Annotation("SqlServer:Identity", "1,1"),
 ModelName = table.Column<string>(type: "nvarchar(200)", maxLength:200, nullable: false),
 Action = table.Column<string>(type: "nvarchar(200)", maxLength:200, nullable: false),
 RequestJson = table.Column<string>(type: "nvarchar(max)", nullable: true),
 ResponseJson = table.Column<string>(type: "nvarchar(max)", nullable: true),
 ExecutionTimeMs = table.Column<int>(type: "int", nullable: false),
 Success = table.Column<bool>(type: "bit", nullable: false),
 ErrorMessage = table.Column<string>(type: "nvarchar(1000)", maxLength:1000, nullable: true),
 InvokedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
 CorrelationId = table.Column<string>(type: "nvarchar(200)", maxLength:200, nullable: true)
 },
 constraints: table =>
 {
 table.PrimaryKey("PK_ModelAudits", x => x.Id);
 });

 migrationBuilder.CreateTable(
 name: "Feedbacks",
 columns: table => new
 {
 Id = table.Column<int>(type: "int", nullable: false)
 .Annotation("SqlServer:Identity", "1,1"),
 EntityType = table.Column<string>(type: "nvarchar(200)", maxLength:200, nullable: false),
 EntityId = table.Column<int>(type: "int", nullable: false),
 FeedbackText = table.Column<string>(type: "nvarchar(max)", nullable: true),
 Rating = table.Column<int>(type: "int", nullable: false),
 UserId = table.Column<string>(type: "nvarchar(200)", maxLength:200, nullable: true),
 IsUseful = table.Column<bool>(type: "bit", nullable: false),
 CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
 },
 constraints: table =>
 {
 table.PrimaryKey("PK_Feedbacks", x => x.Id);
 });
 }

 protected override void Down(MigrationBuilder migrationBuilder)
 {
 migrationBuilder.DropTable(name: "ModelAudits");
 migrationBuilder.DropTable(name: "Feedbacks");
 }
 }
}
