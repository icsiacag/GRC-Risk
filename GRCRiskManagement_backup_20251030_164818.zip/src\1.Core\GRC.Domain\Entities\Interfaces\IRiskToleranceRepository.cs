﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GRC.Domain.Entities.RiskAppetite;

using GRC.Domain.Interfaces;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Interfaces
{
    /// <summary>
    /// Repository interface for RiskTolerance
    /// </summary>
    public interface IRiskToleranceRepository : IGenericRepository<RiskTolerance>
    {
        Task<IEnumerable<RiskTolerance>> GetActiveAsync();
        Task<RiskTolerance> GetByCodeAsync(string code);
        Task<IEnumerable<RiskTolerance>> SearchAsync(string searchTerm);
        Task<bool> ExistsAsync(Guid id);
    }
}




