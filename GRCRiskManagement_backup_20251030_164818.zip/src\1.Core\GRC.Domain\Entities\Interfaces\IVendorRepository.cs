﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GRC.Domain.Entities.VendorRiskManagement;

using GRC.Domain.Interfaces;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Interfaces
{
    /// <summary>
    /// Repository interface for Vendor
    /// </summary>
    public interface IVendorRepository : IGenericRepository<Vendor>
    {
        Task<IEnumerable<Vendor>> GetActiveAsync();
        Task<Vendor> GetByCodeAsync(string code);
        Task<IEnumerable<Vendor>> SearchAsync(string searchTerm);
        Task<bool> ExistsAsync(Guid id);
    }
}




