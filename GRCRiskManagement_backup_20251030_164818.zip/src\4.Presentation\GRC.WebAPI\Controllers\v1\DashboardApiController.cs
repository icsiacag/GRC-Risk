using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Microsoft.AspNetCore.Mvc;

namespace GRC.WebAPI.Controllers.v1
{
 [ApiController]
 [Route("api/v1")]
 public class DashboardApiController : ControllerBase
 {
 [HttpPost("risks")]
 public IActionResult CreateRisk([FromBody] object payload)
 {
 // minimal placeholder - in real app this would use application layer to persist
 return CreatedAtAction(nameof(GetRisks), new { id = Guid.NewGuid() }, new { ok = true });
 }

 [HttpGet("risks")]
 public IActionResult GetRisks([FromQuery] int take =25)
 {
 var list = new List<object>();
 for (var i =0; i < Math.Max(1, Math.Min(take,25)); i++)
 {
 list.Add(new { id = Guid.NewGuid(), title = $"Risk #{i +1}", category = "operational" });
 }
 return Ok(list);
 }

 [HttpPost("controls")]
 public IActionResult CreateControl([FromBody] object payload)
 {
 return Created(string.Empty, new { ok = true });
 }

 [HttpGet("controls")]
 public IActionResult GetControls([FromQuery] int take =50)
 {
 var list = new List<object>();
 for (var i =0; i < Math.Max(1, Math.Min(take,50)); i++)
 {
 list.Add(new { id = Guid.NewGuid(), name = $"Control {i +1}", category = "process", owner = "Owner" + (i +1) });
 }
 return Ok(list);
 }

 [HttpPost("assessments")]
 public IActionResult CreateAssessment([FromBody] object payload)
 {
 return Created(string.Empty, new { ok = true });
 }

 [HttpPost("mitigations")]
 public IActionResult CreateMitigation([FromBody] object payload)
 {
 return Created(string.Empty, new { ok = true });
 }

 [HttpPost("incidents")]
 public IActionResult CreateIncident([FromBody] object payload)
 {
 return Created(string.Empty, new { ok = true });
 }

 [HttpGet("notificationcenter/recent")]
 public IActionResult GetRecentNotifications([FromQuery] int take =20)
 {
 var list = new List<object>();
 for (var i =0; i < Math.Max(1, Math.Min(take,20)); i++)
 {
 list.Add(new { id = Guid.NewGuid(), title = $"Notification {i +1}", body = "This is a sample notification" });
 }
 return Ok(list);
 }

 [HttpGet("notificationcenter/unread-count")]
 public IActionResult GetUnreadCount()
 {
 return Ok(new { unread =3 });
 }

 [HttpPost("reports/export")]
 public IActionResult ExportReport()
 {
 // return a simple CSV file as example
 var csv = new StringBuilder();
 csv.AppendLine("Id,Title,Category");
 csv.AppendLine($"{Guid.NewGuid()},Sample Risk,operational");
 var bytes = Encoding.UTF8.GetBytes(csv.ToString());
 return File(bytes, "text/csv", "export.csv");
 }
 }
}
