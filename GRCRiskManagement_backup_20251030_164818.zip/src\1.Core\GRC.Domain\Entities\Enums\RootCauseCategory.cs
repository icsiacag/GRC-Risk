﻿namespace GRC.Domain.Entities.Enums
{
    public enum RootCauseCategory
    {
        Technical = 1,
        Human = 2,
        Process = 3,
        External = 4
    }
}


