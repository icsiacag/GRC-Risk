﻿using GRC.SharedKernel;
using System.Collections.Generic;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.Controls
{
 public enum ControlUnitType { Branch, Delegation, HeadOfficeUnit, Company }

 public class ControlUnit : AuditableEntity<int>
 {
 public string Name { get; set; } = string.Empty;
 public ControlUnitType Type { get; set; }
 public string Code { get; set; } = string.Empty;
 public int? ParentId { get; set; }
 public ControlUnit? Parent { get; set; }
 public List<ControlUnit> Children { get; set; } = new();
 }
}



