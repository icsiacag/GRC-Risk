﻿using GRC.SharedKernel.Entities;

namespace GRC.Domain.Entities.RiskManagement
{
    public class Control : GRC.SharedKernel.Entities.BaseEntity
    {
        public int RiskId { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string Type { get; set; } = string.Empty;
        public string Effectiveness { get; set; } = string.Empty;
        
        // Navigation
        public virtual Risk? Risk { get; set; }
    }
}
