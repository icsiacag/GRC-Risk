﻿// src/2.Application/GRC.Application/Services/Reporting/ReportGenerationService.cs
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using GRC.Infrastructure.Data;

namespace GRC.Application.Services.Reporting
{
    public interface IReportGenerationService
    {
        Task<byte[]> GenerateExecutiveDashboard(DateTime startDate, DateTime endDate);
        Task<byte[]> GenerateRiskReport(DateTime startDate, DateTime endDate);
        Task<byte[]> GenerateComplianceReport(Guid? frameworkId);
        Task<byte[]> GenerateVendorRiskReport();
        Task<byte[]> GenerateKRIReport();
        Task<byte[]> GenerateAuditSummary(DateTime startDate, DateTime endDate);
    }
    
    public class ReportGenerationService : IReportGenerationService
    {
        private readonly GRCDbContext _context;
        
        public ReportGenerationService(GRCDbContext context)
        {
            _context = context;
        }
        
        public async Task<byte[]> GenerateExecutiveDashboard(DateTime startDate, DateTime endDate)
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            
            using var package = new ExcelPackage();
            
            // Dashboard Summary Sheet
            var dashboardSheet = package.Workbook.Worksheets.Add(""Executive Summary"");
            
            // Get data
            var riskData = await _context.Risks
                .Where(r => r.CreatedDate >= startDate && r.CreatedDate <= endDate)
                .GroupBy(r => r.Status)
                .Select(g => new { Status = g.Key, Count = g.Count() })
                .ToListAsync();
            
            var complianceScore = await CalculateComplianceScore();
            var activeIncidents = await _context.Incidents
                .CountAsync(i => i.Status != ""Closed"");
            
            // Add headers
            dashboardSheet.Cells[""A1""].Value = ""GRC Executive Dashboard"";
            dashboardSheet.Cells[""A1""].Style.Font.Size = 16;
            dashboardSheet.Cells[""A1""].Style.Font.Bold = true;
            
            dashboardSheet.Cells[""A2""].Value = ""Period:"";
            dashboardSheet.Cells[""B2""].Value = $""{startDate:yyyy-MM-dd} to {endDate:yyyy-MM-dd}"";
            
            // Risk Summary
            int row = 4;
            dashboardSheet.Cells[$""A{row}""].Value = ""Risk Summary"";
            dashboardSheet.Cells[$""A{row}""].Style.Font.Bold = true;
            row++;
            
            foreach (var item in riskData)
            {
                dashboardSheet.Cells[$""A{row}""].Value = item.Status;
                dashboardSheet.Cells[$""B{row}""].Value = item.Count;
                row++;
            }
            
            // Compliance Summary
            row += 2;
            dashboardSheet.Cells[$""A{row}""].Value = ""Compliance Score"";
            dashboardSheet.Cells[$""A{row}""].Style.Font.Bold = true;
            row++;
            dashboardSheet.Cells[$""A{row}""].Value = ""Overall Score:"";
            dashboardSheet.Cells[$""B{row}""].Value = complianceScore;
            dashboardSheet.Cells[$""B{row}""].Style.Numberformat.Format = ""0.00%"";
            
            // Auto-fit columns
            dashboardSheet.Cells[dashboardSheet.Dimension.Address].AutoFitColumns();
            
            // Risk Details Sheet
            var riskSheet = package.Workbook.Worksheets.Add(""Risk Details"");
            var risks = await _context.Risks
                .Where(r => r.CreatedDate >= startDate && r.CreatedDate <= endDate)
                .OrderByDescending(r => r.InherentRisk)
                .ToListAsync();
            
            // Add risk data
            riskSheet.Cells[""A1""].Value = ""Risk ID"";
            riskSheet.Cells[""B1""].Value = ""Title"";
            riskSheet.Cells[""C1""].Value = ""Category"";
            riskSheet.Cells[""D1""].Value = ""Inherent Risk"";
            riskSheet.Cells[""E1""].Value = ""Residual Risk"";
            riskSheet.Cells[""F1""].Value = ""Status"";
            riskSheet.Cells[""G1""].Value = ""Owner"";
            
            row = 2;
            foreach (var risk in risks)
            {
                riskSheet.Cells[$""A{row}""].Value = risk.Id.ToString();
                riskSheet.Cells[$""B{row}""].Value = risk.Title;
                riskSheet.Cells[$""C{row}""].Value = risk.CategoryId.ToString();
                riskSheet.Cells[$""D{row}""].Value = risk.InherentRisk.ToString();
                riskSheet.Cells[$""E{row}""].Value = risk.ResidualRisk.ToString();
                riskSheet.Cells[$""F{row}""].Value = risk.Status.ToString();
                riskSheet.Cells[$""G{row}""].Value = risk.Owner;
                row++;
            }
            
            riskSheet.Cells[riskSheet.Dimension.Address].AutoFitColumns();
            
            return await Task.FromResult(package.GetAsByteArray());
        }
        
        private async Task<decimal> CalculateComplianceScore()
        {
            var total = await _context.ComplianceRequirements.CountAsync();
            if (total == 0) return 0;
            
            var compliant = await _context.ComplianceRequirements
                .CountAsync(c => c.Status == ""Compliant"");
            
            return (decimal)compliant / total;
        }
        
        // Implement other report methods similarly...
        public Task<byte[]> GenerateRiskReport(DateTime startDate, DateTime endDate)
        {
            throw new NotImplementedException();
        }
        
        public Task<byte[]> GenerateComplianceReport(Guid? frameworkId)
        {
            throw new NotImplementedException();
        }
        
        public Task<byte[]> GenerateVendorRiskReport()
        {
            throw new NotImplementedException();
        }
        
        public Task<byte[]> GenerateKRIReport()
        {
            throw new NotImplementedException();
        }
        
        public Task<byte[]> GenerateAuditSummary(DateTime startDate, DateTime endDate)
        {
            throw new NotImplementedException();
        }
    }
}
