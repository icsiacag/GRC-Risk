using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;

namespace GRC.WebAPI.Controllers.v1
{
 [ApiController]
 [Route("api/v1/businesscontinuity")]
 public class BusinessContinuityController : ControllerBase
 {
 // Simple in-memory placeholder store (for demo only)
 private static readonly List<PlanDto> Plans = new List<PlanDto>
 {
 new PlanDto { Id = Guid.NewGuid(), Name = "Data Center Recovery", Owner = "Infra Team", Unit = "IT", Status = "Published", RtoHours =24, CreatedAt = DateTime.UtcNow }
 };

 [HttpGet("/api/v1/businesscontinuity/plans")]
 [HttpGet("plans")]
 public ActionResult<IEnumerable<PlanDto>> GetPlans()
 {
 return Ok(Plans);
 }

 [HttpGet("plans/{id}")]
 public ActionResult<PlanDto> GetPlan(Guid id)
 {
 var p = Plans.Find(x => x.Id == id);
 if (p == null) return NotFound();
 return Ok(p);
 }

 [HttpPost("plans")]
 public ActionResult<PlanDto> CreatePlan([FromBody] PlanCreateDto dto)
 {
 var p = new PlanDto
 {
 Id = Guid.NewGuid(),
 Name = dto.Name,
 Owner = dto.Owner,
 Unit = dto.Unit,
 Status = dto.Status ?? "Draft",
 RtoHours = dto.RtoHours,
 Procedure = dto.Procedure,
 CreatedAt = DateTime.UtcNow
 };
 Plans.Add(p);
 return CreatedAtAction(nameof(GetPlan), new { id = p.Id }, p);
 }

 // DTOs
 public class PlanDto
 {
 public Guid Id { get; set; }
 public string Name { get; set; }
 public string Owner { get; set; }
 public string Unit { get; set; }
 public string Status { get; set; }
 public int RtoHours { get; set; }
 public string Procedure { get; set; }
 public DateTime CreatedAt { get; set; }
 }

 public class PlanCreateDto
 {
 public string Name { get; set; }
 public string Owner { get; set; }
 public string Unit { get; set; }
 public string Status { get; set; }
 public int RtoHours { get; set; }
 public string Procedure { get; set; }
 }
 }
}
