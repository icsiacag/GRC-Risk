using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;

namespace GRC.WebAPI.Controllers.v1
{
 [ApiController]
 [Route("api/v1/training")]
 public class TrainingController : ControllerBase
 {
 private static readonly List<CourseDto> Courses = new List<CourseDto>
 {
 new CourseDto{ Id = Guid.NewGuid(), Title = "Risk Awareness", Duration = "2h" }
 };

 [HttpGet("/api/v1/training/courses")]
 [HttpGet("courses")]
 public ActionResult<IEnumerable<CourseDto>> GetCourses() => Ok(Courses);

 [HttpPost("courses")]
 public ActionResult<CourseDto> CreateCourse([FromBody] CourseCreateDto dto)
 {
 var c = new CourseDto{ Id = Guid.NewGuid(), Title = dto.Title, Duration = dto.Duration };
 Courses.Add(c);
 return CreatedAtAction(nameof(GetCourses), new { id = c.Id }, c);
 }

 public class CourseDto{ public Guid Id { get; set; } public string Title { get; set; } public string Duration { get; set; } }
 public class CourseCreateDto{ public string Title { get; set; } public string Duration { get; set; } }
 }
}
