using GRC.Domain.Interfaces.Repositories;
using GRC.Domain.Interfaces.Services;

namespace GRC.Application.Services;

/// <summary>
/// Risk scoring application service.
/// </summary>
public interface IRiskScoringApplicationService
{
    Task<decimal> CalculateRiskScoreAsync(int riskId, CancellationToken cancellationToken = default);
    Task<string> DetermineRiskLevelAsync(int riskId, CancellationToken cancellationToken = default);
}

public class RiskScoringApplicationService : IRiskScoringApplicationService
{
    private readonly IRiskCalculationService _calculationService;
    private readonly IRiskRepository _riskRepository;

    public RiskScoringApplicationService(
        IRiskCalculationService calculationService,
        IRiskRepository riskRepository)
    {
        _calculationService = calculationService;
        _riskRepository = riskRepository;
    }

    public async Task<decimal> CalculateRiskScoreAsync(int riskId, CancellationToken cancellationToken = default)
    {
        var risk = await _riskRepository.GetByIdAsync(riskId, cancellationToken);
        
        if (risk == null)
            throw new InvalidOperationException($"Risk not found: {riskId}");

        return _calculationService.CalculateRiskScore(risk);
    }

    public async Task<string> DetermineRiskLevelAsync(int riskId, CancellationToken cancellationToken = default)
    {
        var score = await CalculateRiskScoreAsync(riskId, cancellationToken);
        return _calculationService.DetermineRiskLevel(score);
    }
}

