using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace GRC.Application.Services.AI
{
 public class ModelRegistry : IModelPersistence
 {
 private readonly string _storagePath;
 private readonly ILogger<ModelRegistry> _logger;
 public ModelRegistry(ILogger<ModelRegistry> logger)
 {
 _logger = logger;
 _storagePath = Path.Combine(AppContext.BaseDirectory, "ml-models");
 Directory.CreateDirectory(_storagePath);
 }
 public async Task SaveModelAsync(string name, Stream modelStream)
 {
 var path = Path.Combine(_storagePath, name + ".zip");
 using var fs = File.Create(path);
 await modelStream.CopyToAsync(fs);
 _logger.LogInformation("Model saved: {Path}", path);
 }
 public async Task<Stream?> LoadModelAsync(string name)
 {
 var path = Path.Combine(_storagePath, name + ".zip");
 if (!File.Exists(path)) return null;
 var ms = new MemoryStream();
 using var fs = File.OpenRead(path);
 await fs.CopyToAsync(ms);
 ms.Position =0;
 return ms;
 }
 public Task<bool> ExistsAsync(string name)
 {
 var path = Path.Combine(_storagePath, name + ".zip");
 return Task.FromResult(File.Exists(path));
 }
 }
}
