﻿using System;
using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.Risk.Categories
{
 public class ReputationalRiskCategory : GRC.Domain.Entities.RiskManagement.RiskCategory
 {
 public string? MonitoringKeywords { get; set; }
 public ReputationalRiskCategory() : base() { }
 }
}




