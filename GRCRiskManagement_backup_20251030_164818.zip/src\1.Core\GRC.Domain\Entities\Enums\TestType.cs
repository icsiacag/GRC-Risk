﻿namespace GRC.Domain.Entities.Enums
{
    public enum TestType
    {
        Manual = 1,
        Automated = 2,
        SemiAutomated = 3
    }
}


