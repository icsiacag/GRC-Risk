﻿using GRC.SharedKernel.Entities;

namespace GRC.Domain.Entities.RiskManagement
{
    public class RootCause : GRC.SharedKernel.Entities.BaseEntity
    {
        public int RiskId { get; set; }
        public string Description { get; set; } = string.Empty;
        public string Category { get; set; } = string.Empty;
        public string Analysis { get; set; } = string.Empty;
        
        // Navigation
        public virtual Risk? Risk { get; set; }
    }
}
