﻿namespace GRC.Domain.Entities.Enums
{
    public enum ChangePriority
    {
        Low = 1,
        Medium = 2,
        High = 3,
        Critical = 4
    }
}


