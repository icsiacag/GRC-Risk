﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GRC.Domain.Entities.IncidentManagement;

using GRC.Domain.Interfaces;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Interfaces
{
    /// <summary>
    /// Repository interface for Incident
    /// </summary>
    public interface IIncidentRepository : IGenericRepository<Incident>
    {
        Task<IEnumerable<Incident>> GetActiveAsync();
        Task<Incident> GetByCodeAsync(string code);
        Task<IEnumerable<Incident>> SearchAsync(string searchTerm);
        Task<bool> ExistsAsync(Guid id);
    }
}




