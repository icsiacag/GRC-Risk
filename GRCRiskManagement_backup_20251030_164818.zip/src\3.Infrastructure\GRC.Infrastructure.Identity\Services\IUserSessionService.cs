using System.Threading.Tasks;

namespace GRC.Infrastructure.Identity.Services
{
 public interface IUserSessionService
 {
 Task TrackUserSessionAsync(string userId, string ipAddress, string userAgent);
 Task EndUserSessionAsync(string sessionId);
 Task CleanupExpiredSessionsAsync();
 }
}
