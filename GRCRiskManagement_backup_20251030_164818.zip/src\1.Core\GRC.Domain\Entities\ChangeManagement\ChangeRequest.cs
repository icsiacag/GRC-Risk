﻿using System;
using System.Collections.Generic;
using GRC.SharedKernel;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.ChangeManagement
{
    /// <summary>
    /// ChangeRequest entity for GRC system
    /// Generated on: 2025-10-30 16:18:22
    /// </summary>
    public class ChangeRequest : GRC.SharedKernel.Entities.BaseEntity
    {
        public string ChangeNumber { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public ChangeType Type { get; set; }
        public ChangePriority Priority { get; set; }
        public ChangeStatus Status { get; set; }
        public string Requestor { get; set; }
        public DateTime RequestDate { get; set; }
        public DateTime? PlannedImplementationDate { get; set; }
        public DateTime? ActualImplementationDate { get; set; }
        public string BusinessJustification { get; set; }
        public RiskLevel RiskLevel { get; set; }
        public List<ChangeApproval> Approvals { get; set; }
        public List<ChangeImpact> Impacts { get; set; }
        
        // Navigation properties and domain logic can be added here
        
        /// <summary>
        /// Validates the entity state
        /// </summary>
        
        /// <summary>
        /// Domain event when entity is created
        /// </summary>
        public void OnCreated()
        {
            CreatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
        
        /// <summary>
        /// Domain event when entity is updated
        /// </summary>
        public void OnUpdated()
        {
            UpdatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
    }
}



