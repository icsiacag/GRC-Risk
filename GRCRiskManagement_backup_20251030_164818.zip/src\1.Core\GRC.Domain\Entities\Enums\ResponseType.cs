﻿namespace GRC.Domain.Entities.Enums
{
    public enum ResponseType
    {
        Immediate = 1,
        Planned = 2,
        Emergency = 3
    }
}


