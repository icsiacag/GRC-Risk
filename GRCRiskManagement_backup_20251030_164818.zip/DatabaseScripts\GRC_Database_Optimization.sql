﻿-- =============================================
-- GRC DATABASE OPTIMIZATION SCRIPT
-- Performance indexes, views, and stored procedures
-- =============================================

USE [GRCRiskManagement];
GO

-- =============================================
-- 1. PERFORMANCE INDEXES
-- =============================================
PRINT 'Creating performance indexes...';

-- Risk Management Indexes
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Risks_Status_Priority')
CREATE NONCLUSTERED INDEX IX_Risks_Status_Priority 
ON Risks(Status, Priority, CreatedDate DESC)
INCLUDE (Title, Owner, RiskLevel);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Risks_Category_Level')
CREATE NONCLUSTERED INDEX IX_Risks_Category_Level 
ON Risks(CategoryId, InherentRisk, ResidualRisk);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Risks_Owner')
CREATE NONCLUSTERED INDEX IX_Risks_Owner 
ON Risks(Owner, Status);

-- Compliance Indexes
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Compliance_Framework_Status')
CREATE NONCLUSTERED INDEX IX_Compliance_Framework_Status 
ON ComplianceRequirements(FrameworkId, Status, DueDate);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Compliance_DueDate')
CREATE NONCLUSTERED INDEX IX_Compliance_DueDate 
ON ComplianceRequirements(DueDate, Status)
WHERE Status != 'Compliant';

-- Audit Indexes
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Audits_Status_Date')
CREATE NONCLUSTERED INDEX IX_Audits_Status_Date 
ON Audits(Status, PlannedDate DESC);

-- Vendor Indexes
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Vendors_RiskRating')
CREATE NONCLUSTERED INDEX IX_Vendors_RiskRating 
ON Vendors(RiskRating, Status);

-- =============================================
-- 2. FULL-TEXT SEARCH SETUP
-- =============================================
PRINT 'Setting up full-text search...';

IF NOT EXISTS (SELECT * FROM sys.fulltext_catalogs WHERE name = 'GRC_FTS_Catalog')
BEGIN
    CREATE FULLTEXT CATALOG GRC_FTS_Catalog AS DEFAULT;
END

-- Risk full-text index
IF NOT EXISTS (SELECT * FROM sys.fulltext_indexes WHERE object_id = OBJECT_ID('Risks'))
BEGIN
    CREATE FULLTEXT INDEX ON Risks(Title, Description) 
    KEY INDEX PK_Risks 
    ON GRC_FTS_Catalog 
    WITH CHANGE_TRACKING AUTO;
END

-- Policy full-text index
IF NOT EXISTS (SELECT * FROM sys.fulltext_indexes WHERE object_id = OBJECT_ID('Policies'))
BEGIN
    CREATE FULLTEXT INDEX ON Policies(Title, Content) 
    KEY INDEX PK_Policies 
    ON GRC_FTS_Catalog 
    WITH CHANGE_TRACKING AUTO;
END

-- =============================================
-- 3. MIS REPORTING VIEWS
-- =============================================
PRINT 'Creating MIS reporting views...';

-- Executive Dashboard View
CREATE OR ALTER VIEW vw_ExecutiveDashboard AS
SELECT 
    -- Risk Metrics
    (SELECT COUNT(*) FROM Risks WHERE Status != 'Closed') as ActiveRisks,
    (SELECT COUNT(*) FROM Risks WHERE RiskLevel IN ('Critical', 'High') AND Status != 'Closed') as HighRisks,
    (SELECT COUNT(*) FROM Risks WHERE CreatedDate >= DATEADD(month, -1, GETDATE())) as NewRisksLastMonth,
    
    -- Compliance Metrics
    (SELECT COUNT(*) FROM ComplianceRequirements WHERE Status = 'Compliant') as CompliantControls,
    (SELECT COUNT(*) FROM ComplianceRequirements) as TotalControls,
    (SELECT CAST(COUNT(*) * 100.0 / NULLIF((SELECT COUNT(*) FROM ComplianceRequirements), 0) AS DECIMAL(5,2))
     FROM ComplianceRequirements WHERE Status = 'Compliant') as CompliancePercentage,
    
    -- Audit Metrics
    (SELECT COUNT(*) FROM Audits WHERE Status = 'Planned' AND PlannedDate >= GETDATE()) as UpcomingAudits,
    (SELECT COUNT(*) FROM Audits WHERE Status IN ('InProgress', 'Fieldwork')) as OngoingAudits,
    
    -- Incident Metrics
    (SELECT COUNT(*) FROM Incidents WHERE Status != 'Closed') as ActiveIncidents,
    (SELECT COUNT(*) FROM Incidents WHERE Severity = 'Critical' AND Status != 'Closed') as CriticalIncidents,
    
    -- Vendor Metrics
    (SELECT COUNT(*) FROM Vendors WHERE RiskRating IN ('Critical', 'High')) as HighRiskVendors,
    (SELECT COUNT(*) FROM Vendors WHERE Status = 'Active') as ActiveVendors;
GO

-- Risk Heat Map View
CREATE OR ALTER VIEW vw_RiskHeatMap AS
SELECT 
    Likelihood,
    Impact,
    COUNT(*) as RiskCount,
    CASE 
        WHEN Likelihood * Impact >= 15 THEN 'Critical'
        WHEN Likelihood * Impact >= 10 THEN 'High'
        WHEN Likelihood * Impact >= 5 THEN 'Medium'
        ELSE 'Low'
    END as RiskLevel
FROM Risks
WHERE Status != 'Closed'
GROUP BY Likelihood, Impact;
GO

-- Compliance by Framework View
CREATE OR ALTER VIEW vw_ComplianceByFramework AS
SELECT 
    cf.Id as FrameworkId,
    cf.Name as FrameworkName,
    COUNT(*) as TotalRequirements,
    SUM(CASE WHEN cr.Status = 'Compliant' THEN 1 ELSE 0 END) as CompliantCount,
    SUM(CASE WHEN cr.Status = 'NonCompliant' THEN 1 ELSE 0 END) as NonCompliantCount,
    SUM(CASE WHEN cr.Status = 'PartiallyCompliant' THEN 1 ELSE 0 END) as PartiallyCompliantCount,
    CAST(SUM(CASE WHEN cr.Status = 'Compliant' THEN 1 ELSE 0 END) * 100.0 / 
         NULLIF(COUNT(*), 0) AS DECIMAL(5,2)) as ComplianceScore
FROM ComplianceFrameworks cf
LEFT JOIN ComplianceRequirements cr ON cf.Id = cr.FrameworkId
GROUP BY cf.Id, cf.Name;
GO

-- KRI Trend Analysis View
CREATE OR ALTER VIEW vw_KRITrends AS
SELECT 
    kri.Id as KRIId,
    kri.Name as KRIName,
    kri.Category,
    m.MeasurementDate,
    m.Value,
    m.Level as ThresholdLevel,
    CASE 
        WHEN m.Value > LAG(m.Value) OVER (PARTITION BY kri.Id ORDER BY m.MeasurementDate) THEN 'Deteriorating'
        WHEN m.Value < LAG(m.Value) OVER (PARTITION BY kri.Id ORDER BY m.MeasurementDate) THEN 'Improving'
        ELSE 'Stable'
    END as Trend
FROM KeyRiskIndicators kri
JOIN KRIMeasurements m ON kri.Id = m.KRIId
WHERE kri.IsActive = 1;
GO

-- Vendor Risk Summary View
CREATE OR ALTER VIEW vw_VendorRiskSummary AS
SELECT 
    v.Id as VendorId,
    v.VendorName,
    v.RiskRating,
    COUNT(vr.Id) as TotalRisks,
    SUM(CASE WHEN vr.Status = 'Open' THEN 1 ELSE 0 END) as OpenRisks,
    MAX(va.AssessmentDate) as LastAssessmentDate,
    DATEDIFF(day, MAX(va.AssessmentDate), GETDATE()) as DaysSinceLastAssessment,
    CASE 
        WHEN DATEDIFF(day, MAX(va.AssessmentDate), GETDATE()) > 365 THEN 'Overdue'
        WHEN DATEDIFF(day, MAX(va.AssessmentDate), GETDATE()) > 300 THEN 'Due Soon'
        ELSE 'Current'
    END as AssessmentStatus
FROM Vendors v
LEFT JOIN VendorRisks vr ON v.Id = vr.VendorId
LEFT JOIN VendorAssessments va ON v.Id = va.VendorId
GROUP BY v.Id, v.VendorName, v.RiskRating;
GO

-- Audit Findings Trend
CREATE OR ALTER VIEW vw_AuditFindingsTrend AS
SELECT 
    YEAR(a.CompletionDate) as Year,
    MONTH(a.CompletionDate) as Month,
    af.Severity,
    COUNT(*) as FindingCount
FROM Audits a
JOIN AuditFindings af ON a.Id = af.AuditId
WHERE a.Status = 'Completed'
GROUP BY YEAR(a.CompletionDate), MONTH(a.CompletionDate), af.Severity;
GO

-- =============================================
-- 4. STORED PROCEDURES FOR REPORTING
-- =============================================
PRINT 'Creating stored procedures...';

-- Get Risk Dashboard
CREATE OR ALTER PROCEDURE sp_GetRiskDashboard
    @StartDate DATE = NULL,
    @EndDate DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    IF @StartDate IS NULL SET @StartDate = DATEADD(year, -1, GETDATE());
    IF @EndDate IS NULL SET @EndDate = GETDATE();
    
    -- Risk by Status
    SELECT 
        Status,
        COUNT(*) as Count,
        CAST(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER() AS DECIMAL(5,2)) as Percentage
    FROM Risks
    WHERE CreatedDate BETWEEN @StartDate AND @EndDate
    GROUP BY Status;
    
    -- Risk by Category
    SELECT 
        rc.Name as Category,
        COUNT(r.Id) as Count
    FROM RiskCategories rc
    LEFT JOIN Risks r ON rc.Id = r.CategoryId 
        AND r.CreatedDate BETWEEN @StartDate AND @EndDate
    GROUP BY rc.Name
    ORDER BY COUNT(r.Id) DESC;
    
    -- Risk Trend
    SELECT 
        CONVERT(DATE, DATEADD(month, DATEDIFF(month, 0, CreatedDate), 0)) as Month,
        RiskLevel,
        COUNT(*) as Count
    FROM Risks
    WHERE CreatedDate BETWEEN @StartDate AND @EndDate
    GROUP BY DATEADD(month, DATEDIFF(month, 0, CreatedDate), 0), RiskLevel
    ORDER BY Month;
END;
GO

-- Get Compliance Report
CREATE OR ALTER PROCEDURE sp_GetComplianceReport
    @FrameworkId UNIQUEIDENTIFIER = NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    SELECT 
        cf.Name as Framework,
        cr.RequirementId,
        cr.Description,
        cr.Status,
        cr.DueDate,
        cr.ResponsiblePerson,
        DATEDIFF(day, GETDATE(), cr.DueDate) as DaysUntilDue,
        CASE 
            WHEN cr.Status = 'Compliant' THEN 'Green'
            WHEN cr.Status = 'NonCompliant' THEN 'Red'
            WHEN DATEDIFF(day, GETDATE(), cr.DueDate) < 30 THEN 'Amber'
            ELSE 'Green'
        END as RAGStatus
    FROM ComplianceRequirements cr
    JOIN ComplianceFrameworks cf ON cr.FrameworkId = cf.Id
    WHERE (@FrameworkId IS NULL OR cr.FrameworkId = @FrameworkId)
    ORDER BY cf.Name, cr.DueDate;
END;
GO

-- Get Vendor Risk Assessment
CREATE OR ALTER PROCEDURE sp_GetVendorRiskAssessment
AS
BEGIN
    SET NOCOUNT ON;
    
    SELECT 
        v.VendorName,
        v.RiskRating,
        v.Status,
        COUNT(DISTINCT vr.Id) as TotalRisks,
        COUNT(DISTINCT va.Id) as AssessmentCount,
        MAX(va.AssessmentDate) as LastAssessmentDate,
        SUM(CASE WHEN vr.Status = 'Open' THEN 1 ELSE 0 END) as OpenRisks,
        CASE 
            WHEN MAX(va.AssessmentDate) IS NULL THEN 'Never Assessed'
            WHEN DATEDIFF(day, MAX(va.AssessmentDate), GETDATE()) > 365 THEN 'Assessment Overdue'
            ELSE 'Assessment Current'
        END as AssessmentStatus
    FROM Vendors v
    LEFT JOIN VendorRisks vr ON v.Id = vr.VendorId
    LEFT JOIN VendorAssessments va ON v.Id = va.VendorId
    WHERE v.Status = 'Active'
    GROUP BY v.VendorName, v.RiskRating, v.Status
    ORDER BY 
        CASE v.RiskRating 
            WHEN 'Critical' THEN 1 
            WHEN 'High' THEN 2 
            WHEN 'Medium' THEN 3 
            ELSE 4 
        END;
END;
GO

-- Get KRI Status Report
CREATE OR ALTER PROCEDURE sp_GetKRIStatusReport
AS
BEGIN
    SET NOCOUNT ON;
    
    WITH LatestMeasurements AS (
        SELECT 
            KRIId,
            Value,
            Level,
            MeasurementDate,
            ROW_NUMBER() OVER (PARTITION BY KRIId ORDER BY MeasurementDate DESC) as rn
        FROM KRIMeasurements
    )
    SELECT 
        kri.Name as KRIName,
        kri.Description,
        kri.Category,
        lm.Value as CurrentValue,
        lm.Level as CurrentLevel,
        lm.MeasurementDate as LastMeasured,
        kri.GreenThreshold,
        kri.YellowThreshold,
        kri.RedThreshold,
        kri.Owner,
        CASE 
            WHEN lm.Level = 'Red' THEN 'Critical'
            WHEN lm.Level = 'Yellow' THEN 'Warning'
            ELSE 'Normal'
        END as AlertStatus
    FROM KeyRiskIndicators kri
    LEFT JOIN LatestMeasurements lm ON kri.Id = lm.KRIId AND lm.rn = 1
    WHERE kri.IsActive = 1
    ORDER BY 
        CASE lm.Level 
            WHEN 'Red' THEN 1 
            WHEN 'Yellow' THEN 2 
            ELSE 3 
        END;
END;
GO

-- =============================================
-- 5. TEMPORAL TABLES FOR AUDIT HISTORY
-- =============================================
PRINT 'Setting up temporal tables...';

-- Add system versioning to Risks table
IF NOT EXISTS (
    SELECT * FROM sys.tables 
    WHERE name = 'Risks' 
    AND temporal_type = 2
)
BEGIN
    ALTER TABLE Risks ADD
        SysStartTime datetime2 GENERATED ALWAYS AS ROW START HIDDEN NOT NULL DEFAULT SYSUTCDATETIME(),
        SysEndTime datetime2 GENERATED ALWAYS AS ROW END HIDDEN NOT NULL DEFAULT CONVERT(datetime2, '9999-12-31 23:59:59.9999999'),
        PERIOD FOR SYSTEM_TIME (SysStartTime, SysEndTime);
    
    ALTER TABLE Risks 
    SET (SYSTEM_VERSIONING = ON (HISTORY_TABLE = dbo.RisksHistory));
END;
GO

-- =============================================
-- 6. DATA ARCHIVAL STRATEGY
-- =============================================
PRINT 'Setting up data archival...';

-- Archive old closed risks
CREATE OR ALTER PROCEDURE sp_ArchiveClosedRisks
    @ArchiveDate DATE = NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    IF @ArchiveDate IS NULL 
        SET @ArchiveDate = DATEADD(year, -2, GETDATE());
    
    -- Create archive table if not exists
    IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'RisksArchive')
    BEGIN
        SELECT * INTO RisksArchive FROM Risks WHERE 1=0;
    END;
    
    -- Move old closed risks to archive
    INSERT INTO RisksArchive
    SELECT * FROM Risks
    WHERE Status = 'Closed' 
    AND UpdatedDate < @ArchiveDate
    AND Id NOT IN (SELECT Id FROM RisksArchive);
    
    -- Delete from main table
    DELETE FROM Risks
    WHERE Status = 'Closed' 
    AND UpdatedDate < @ArchiveDate;
    
    PRINT CONCAT('Archived ', @@ROWCOUNT, ' closed risks');
END;
GO

-- =============================================
-- 7. BACKUP AND MAINTENANCE
-- =============================================
PRINT 'Creating maintenance jobs...';

-- Update statistics
CREATE OR ALTER PROCEDURE sp_UpdateGRCStatistics
AS
BEGIN
    SET NOCOUNT ON;
    
    UPDATE STATISTICS Risks WITH FULLSCAN;
    UPDATE STATISTICS ComplianceRequirements WITH FULLSCAN;
    UPDATE STATISTICS Audits WITH FULLSCAN;
    UPDATE STATISTICS Vendors WITH FULLSCAN;
    
    PRINT 'Statistics updated successfully';
END;
GO

-- Database health check
CREATE OR ALTER PROCEDURE sp_GRCDatabaseHealthCheck
AS
BEGIN
    SET NOCOUNT ON;
    
    -- Check for missing indexes
    SELECT 
        'Missing Index' as CheckType,
        OBJECT_NAME(d.object_id) as TableName,
        d.equality_columns,
        d.inequality_columns,
        d.included_columns,
        s.avg_total_user_cost * s.avg_user_impact * (s.user_seeks + s.user_scans) as ImprovementMeasure
    FROM sys.dm_db_missing_index_details d
    JOIN sys.dm_db_missing_index_groups g ON d.index_handle = g.index_handle
    JOIN sys.dm_db_missing_index_group_stats s ON g.index_group_handle = s.group_handle
    WHERE d.database_id = DB_ID()
    ORDER BY ImprovementMeasure DESC;
    
    -- Check table sizes
    SELECT 
        'Table Size' as CheckType,
        t.NAME as TableName,
        p.rows as RowCounts,
        CAST(ROUND(((SUM(a.total_pages) * 8) / 1024.00), 2) AS NUMERIC(36, 2)) as TotalSpaceMB
    FROM sys.tables t
    JOIN sys.indexes i ON t.OBJECT_ID = i.object_id
    JOIN sys.partitions p ON i.object_id = p.OBJECT_ID AND i.index_id = p.index_id
    JOIN sys.allocation_units a ON p.partition_id = a.container_id
    WHERE t.is_ms_shipped = 0
    GROUP BY t.Name, p.Rows
    ORDER BY TotalSpaceMB DESC;
END;
GO

PRINT 'Database optimization completed successfully!';
