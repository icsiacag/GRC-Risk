﻿namespace GRC.Domain.Entities.Enums
{
    public enum TestResult
    {
        Passed = 1,
        Failed = 2,
        PartiallyPassed = 3,
        NotTested = 4
    }
}


