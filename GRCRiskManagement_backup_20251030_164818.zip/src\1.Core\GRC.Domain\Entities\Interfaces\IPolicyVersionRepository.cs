﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GRC.Domain.Entities.PolicyManagement;

using GRC.Domain.Interfaces;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Interfaces
{
    /// <summary>
    /// Repository interface for PolicyVersion
    /// </summary>
    public interface IPolicyVersionRepository : IGenericRepository<PolicyVersion>
    {
        Task<IEnumerable<PolicyVersion>> GetActiveAsync();
        Task<PolicyVersion> GetByCodeAsync(string code);
        Task<IEnumerable<PolicyVersion>> SearchAsync(string searchTerm);
        Task<bool> ExistsAsync(Guid id);
    }
}




