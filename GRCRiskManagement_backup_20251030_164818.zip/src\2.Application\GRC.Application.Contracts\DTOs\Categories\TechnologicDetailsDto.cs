namespace GRC.Application.Contracts.DTOs.Categories
{
 public class TechnologicDetailsDto
 {
 public string? TechStackVulnerabilities { get; set; }
 public double? InnovationAdoptionRate { get; set; }
 }
}}