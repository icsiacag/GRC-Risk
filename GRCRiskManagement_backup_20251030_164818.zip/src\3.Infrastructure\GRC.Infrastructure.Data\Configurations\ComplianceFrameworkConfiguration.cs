using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using GRC.Domain.Entities.Compliance;

namespace GRC.Infrastructure.Data.Configurations
{
    public class ComplianceFrameworkConfiguration : IEntityTypeConfiguration<ComplianceFramework>
    {
        private const string TableName = "ComplianceFrameworks";

        public void Configure(EntityTypeBuilder<ComplianceFramework> builder)
        {
            builder.ToTable(TableName);

            builder.HasKey(cf => cf.Id);

            builder.Property(cf => cf.Name)
                .IsRequired()
                .HasMaxLength(200);

            builder.Property(cf => cf.Description)
                .HasMaxLength(1000);

            // Di�er konfig�rasyonlar
        }
    }
}











