﻿using Microsoft.EntityFrameworkCore;
using GRC.Domain.Entities.Audit;
using GRC.Domain.Entities.RiskManagement;
using GRC.Domain.Entities.Compliance;
using Microsoft.EntityFrameworkCore.Storage;
using GRC.Infrastructure.Data.Entities;
using GRC.Domain.Entities.Billing;

namespace GRC.Infrastructure.Data.Content
{
    public class GRCDbContext : DbContext
    {
        private IDbContextTransaction? _currentTransaction;

        public GRCDbContext(DbContextOptions<GRCDbContext> options) : base(options)
        {
        }

        // DbSets for entities
        public DbSet<Risk> Risks { get; set; }
        public DbSet<RiskCategory> RiskCategories { get; set; }
        public DbSet<AuditPlan> AuditPlans { get; set; }
        public DbSet<AuditExecution> AuditExecutions { get; set; }
        public DbSet<AuditFinding> AuditFindings { get; set; }
        public DbSet<CorrectiveAction> CorrectiveActions { get; set; }
        public DbSet<ComplianceFramework> ComplianceFrameworks { get; set; }
        public DbSet<ModelAudit> ModelAudits { get; set; }
        public DbSet<Feedback> Feedbacks { get; set; }
        public DbSet<AssessmentResult> AssessmentResults { get; set; }

        // Billing
        public DbSet<MembershipPlan> MembershipPlans { get; set; }
        public DbSet<UserSubscription> UserSubscriptions { get; set; }
        // Governance units for hierarchy visualization
        public DbSet<GRC.Infrastructure.Data.Entities.GovernanceUnit> GovernanceUnits { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            
            // Apply configurations from assembly
            modelBuilder.ApplyConfigurationsFromAssembly(typeof(GRCDbContext).Assembly);
            // Ensure ControlConfiguration is applied
            modelBuilder.ApplyConfiguration(new GRC.Infrastructure.Data.Configurations.ControlConfiguration());

            modelBuilder.Entity<ModelAudit>(entity =>
            {
                entity.ToTable("ModelAudits");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.ModelName).HasMaxLength(200);
                entity.Property(e => e.Action).HasMaxLength(200);
                entity.Property(e => e.RequestJson).HasColumnType("nvarchar(max)");
                entity.Property(e => e.ResponseJson).HasColumnType("nvarchar(max)");
                entity.Property(e => e.ExecutionTimeMs);
                entity.Property(e => e.Success);
                entity.Property(e => e.ErrorMessage).HasMaxLength(1000);
                entity.Property(e => e.InvokedAt).HasColumnType("datetime2");
                entity.Property(e => e.CorrelationId).HasMaxLength(200);
            });

            modelBuilder.Entity<Feedback>(entity =>
            {
                entity.ToTable("Feedbacks");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.EntityType).HasMaxLength(200);
                entity.Property(e => e.EntityId);
                entity.Property(e => e.FeedbackText).HasColumnType("nvarchar(max)");
                entity.Property(e => e.Rating);
                entity.Property(e => e.UserId).HasMaxLength(200);
                entity.Property(e => e.IsUseful);
                entity.Property(e => e.CreatedAt).HasColumnType("datetime2");
            });

            modelBuilder.Entity<AssessmentResult>(entity =>
            {
                entity.ToTable("AssessmentResults");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Type).HasMaxLength(100);
                entity.Property(e => e.Assessor).HasMaxLength(200);
                entity.Property(e => e.Label).HasMaxLength(200);
                entity.Property(e => e.RawPayload).HasColumnType("nvarchar(max)");
            });

            // Billing table configuration
            modelBuilder.Entity<MembershipPlan>(entity =>
            {
                entity.ToTable("MembershipPlans");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Name).HasMaxLength(200).IsRequired();
                entity.Property(e => e.Currency).HasMaxLength(10).IsRequired();
                entity.Property(e => e.BillingPeriod).HasMaxLength(20).IsRequired();
            });

            modelBuilder.Entity<UserSubscription>(entity =>
            {
                entity.ToTable("UserSubscriptions");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Status).HasMaxLength(50).IsRequired();
                entity.HasIndex(e => e.UserId);
                entity.HasIndex(e => e.PlanId);
                entity.Property(e => e.UserId).HasMaxLength(200).IsRequired();
            });

            modelBuilder.Entity<GRC.Infrastructure.Data.Entities.GovernanceUnit>(entity =>
            {
                entity.ToTable("GovernanceUnits");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Name).HasMaxLength(500).IsRequired();
                entity.Property(e => e.Type).HasMaxLength(100);
                entity.HasIndex(e => e.ParentId);
                entity.HasIndex(e => e.Path);
                entity.HasIndex(e => e.Depth);

                // relationships
                entity.HasMany(e => e.Children).WithOne(e => e.Parent).HasForeignKey(e => e.ParentId).OnDelete(DeleteBehavior.Restrict);

                // default values
                entity.Property(e => e.CreatedAt).HasDefaultValueSql("GETUTCDATE()");
                entity.Property(e => e.UpdatedAt).HasDefaultValueSql("GETUTCDATE()");
                entity.Property(e => e.IsActive).HasDefaultValue(true);
            });

            // RiskLevel lookup table to normalize free-text risk level values
            modelBuilder.Entity<GRC.Infrastructure.Data.Entities.RiskLevelLookup>(entity =>
            {
                entity.ToTable("RiskLevelLookup");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Label).HasMaxLength(100).IsRequired();
                entity.Property(e => e.Keywords).HasMaxLength(1000);

                // seed from code when applying migrations is also possible, but we will keep seeding in startup
            });

            modelBuilder.Entity<GRC.Infrastructure.Data.Entities.KpiSnapshot>(entity =>
            {
                entity.ToTable("KpiSnapshots");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.SnapshotAt).IsRequired();
                entity.Property(e => e.JsonPayload).HasColumnType("nvarchar(max)");
                entity.HasIndex(e => e.SnapshotAt);
            });

            // user sessions
            modelBuilder.Entity<GRC.Infrastructure.Data.Entities.UserSession>(entity =>
            {
                entity.ToTable("UserSessions");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.UserId).HasMaxLength(200);
                entity.Property(e => e.IpAddress).HasMaxLength(100);
                entity.Property(e => e.UserAgent).HasMaxLength(1000);
                entity.Property(e => e.LoginTime).IsRequired();
                entity.HasIndex(e => e.UserId);
            });

            modelBuilder.Entity<GRC.Domain.Entities.Controls.Control>(entity =>
            {
                entity.ToTable("Controls");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.ControlCode).HasMaxLength(100);
                entity.Property(e => e.Name).HasMaxLength(500).IsRequired();
                entity.Property(e => e.Description).HasColumnType("nvarchar(max)");
                entity.Property(e => e.ControlType).HasMaxLength(100);
                entity.Property(e => e.Category).HasMaxLength(100);
                entity.Property(e => e.Frequency).HasMaxLength(50);
                entity.Property(e => e.Owner).HasMaxLength(200);
                entity.HasIndex(e => e.ControlCode);
                entity.HasOne(e => e.Risk).WithMany().HasForeignKey(e => e.RiskId).OnDelete(DeleteBehavior.SetNull);
            });

            modelBuilder.Entity<GRC.Domain.Entities.Controls.ControlTestRecord>(entity =>
            {
                entity.ToTable("ControlTestRecords");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.PerformedBy).HasMaxLength(200);
                entity.Property(e => e.PerformedAt).IsRequired();
                entity.Property(e => e.Result).HasMaxLength(100);
                entity.Property(e => e.Notes).HasColumnType("nvarchar(max)");
                entity.Property(e => e.Frequency).HasMaxLength(50);
                entity.HasIndex(e => e.ControlId);
                entity.HasOne<GRC.Domain.Entities.Controls.Control>().WithMany(c => c.TestRecords).HasForeignKey("ControlId");
            });

            modelBuilder.Entity<GRC.Domain.Entities.Controls.ControlUnit>(entity =>
            {
                entity.ToTable("ControlUnits");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Name).HasMaxLength(500).IsRequired();
                entity.Property(e => e.Code).HasMaxLength(100);
                entity.Property(e => e.Type).HasConversion<string>().HasMaxLength(50);
                entity.HasMany(e => e.Children).WithOne(e => e.Parent).HasForeignKey(e => e.ParentId).OnDelete(DeleteBehavior.Restrict);
            });

            // wire Control -> ControlUnit
            modelBuilder.Entity<GRC.Domain.Entities.Controls.Control>(entity =>
            {
                entity.HasOne(e => e.ControlUnit).WithMany().HasForeignKey(e => e.ControlUnitId).OnDelete(DeleteBehavior.SetNull);
            });
        }

        // Transaction methods for UnitOfWork
        public async Task BeginTransactionAsync(CancellationToken cancellationToken = default)
        {
            if (_currentTransaction != null)
            {
                return;
            }

            _currentTransaction = await Database.BeginTransactionAsync(cancellationToken);
        }

        public async Task CommitTransactionAsync(CancellationToken cancellationToken = default)
        {
            try
            {
                await SaveChangesAsync(cancellationToken);
                await _currentTransaction?.CommitAsync(cancellationToken)!;
            }
            catch
            {
                await RollbackTransactionAsync(cancellationToken);
                throw;
            }
            finally
            {
                if (_currentTransaction != null)
                {
                    _currentTransaction.Dispose();
                    _currentTransaction = null;
                }
            }
        }

        public async Task RollbackTransactionAsync(CancellationToken cancellationToken = default)
        {
            try
            {
                await _currentTransaction?.RollbackAsync(cancellationToken)!;
            }
            finally
            {
                if (_currentTransaction != null)
                {
                    _currentTransaction.Dispose();
                    _currentTransaction = null;
                }
            }
        }

        public override int SaveChanges()
        {
            UpdateTimestamps();
            return base.SaveChanges();
        }

        public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            UpdateTimestamps();
            return base.SaveChangesAsync(cancellationToken);
        }

        private void UpdateTimestamps()
        {
            var entries = ChangeTracker.Entries<GRC.Infrastructure.Data.Entities.GovernanceUnit>();
            var utcNow = DateTime.UtcNow;
            foreach (var e in entries)
            {
                if (e.State == EntityState.Added)
                {
                    e.Entity.CreatedAt = utcNow;
                    e.Entity.UpdatedAt = utcNow;
                    if (string.IsNullOrEmpty(e.Entity.Path)) e.Entity.Path = e.Entity.Id.ToString();
                    e.Entity.Depth = e.Entity.ParentId == null ?0 :1; // caller should recalc path/depth as needed
                }
                else if (e.State == EntityState.Modified)
                {
                    e.Entity.UpdatedAt = utcNow;
                }
            }
        }
    }
}

