using System;
using System.Collections.Generic;

namespace GRC.Infrastructure.Data.Entities
{
 public class GovernanceUnit
 {
 public Guid Id { get; set; }
 public string Name { get; set; } = string.Empty;
 public string Type { get; set; } = string.Empty;
 public Guid? ParentId { get; set; }

 // Navigation
 public GovernanceUnit? Parent { get; set; }
 public List<GovernanceUnit> Children { get; set; } = new List<GovernanceUnit>();

 // Ordering and hierarchy optimizations
 public int SortOrder { get; set; }
 public string? Path { get; set; } // materialized path (e.g. "rootId/parentId/thisId")
 public int Depth { get; set; }

 // Audit
 public DateTime CreatedAt { get; set; }
 public DateTime UpdatedAt { get; set; }

 // Soft-delete / active flag could be added later
 public bool IsActive { get; set; } = true;
 }
}
