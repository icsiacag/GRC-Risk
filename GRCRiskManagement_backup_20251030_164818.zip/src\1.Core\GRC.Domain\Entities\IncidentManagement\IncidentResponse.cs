﻿using System;
using System.Collections.Generic;
using GRC.SharedKernel;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.IncidentManagement
{
    /// <summary>
    /// IncidentResponse entity for GRC system
    /// Generated on: 2025-10-30 16:18:22
    /// </summary>
    public class IncidentResponse : GRC.SharedKernel.Entities.BaseEntity
    {
        public Guid IncidentId { get; set; }
        public ResponseType Type { get; set; }
        public string Action { get; set; }
        public string ResponsiblePerson { get; set; }
        public DateTime ActionDate { get; set; }
        public string Outcome { get; set; }
        public ResponseStatus Status { get; set; }
        
        // Navigation properties and domain logic can be added here
        
        /// <summary>
        /// Validates the entity state
        /// </summary>
        
        /// <summary>
        /// Domain event when entity is created
        /// </summary>
        public void OnCreated()
        {
            CreatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
        
        /// <summary>
        /// Domain event when entity is updated
        /// </summary>
        public void OnUpdated()
        {
            UpdatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
    }
}



