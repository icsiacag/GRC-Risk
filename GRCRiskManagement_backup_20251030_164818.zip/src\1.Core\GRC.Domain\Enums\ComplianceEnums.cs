namespace GRC.Domain.Enums;

/// <summary>
/// Compliance framework types.
/// </summary>
public enum ComplianceFrameworkType
{
    /// <summary>
    /// ISO/IEC 27001 - Information Security Management System
    /// </summary>
    ISO27001 = 1,

    /// <summary>
    /// SOC 2 - Service Organization Control 2
    /// </summary>
    SOC2 = 2,

    /// <summary>
    /// GDPR - General Data Protection Regulation
    /// </summary>
    GDPR = 3,

    /// <summary>
    /// KVKK - Ki�isel Verilerin Korunmas� Kanunu
    /// </summary>
    KVKK = 4,

    /// <summary>
    /// ISO 9001 - Quality Management System
    /// </summary>
    ISO9001 = 5,

    /// <summary>
    /// ISO 14001 - Environmental Management System
    /// </summary>
    ISO14001 = 6,

    /// <summary>
    /// PCI DSS - Payment Card Industry Data Security Standard
    /// </summary>
    PCIDSS = 7,

    /// <summary>
    /// HIPAA - Health Insurance Portability and Accountability Act
    /// </summary>
    HIPAA = 8
}

/// <summary>
/// Compliance status.
/// </summary>
public enum ComplianceStatus
{
    /// <summary>
    /// Not started - compliance work has not begun
    /// </summary>
    NotStarted = 1,

    /// <summary>
    /// In Progress - compliance work is ongoing
    /// </summary>
    InProgress = 2,

    /// <summary>
    /// Compliant - fully compliant with the framework
    /// </summary>
    Compliant = 3,

    /// <summary>
    /// Non-Compliant - not meeting compliance requirements
    /// </summary>
    NonCompliant = 4,

    /// <summary>
    /// Partially Compliant - some requirements met
    /// </summary>
    PartiallyCompliant = 5
}
