﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Compression;
using System.Diagnostics;
using GRC.Infrastructure.Data.Content;
using GRC.WebAPI.Middleware;
using Microsoft.OpenApi.Models;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using GRC.WebAPI.Services.AI;
using GRC.Infrastructure.Data.Repositories;
using GRC.Infrastructure.Integration;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.StaticFiles;
using GRC.Application.Services;
using GRC.WebAPI.Services;
using Microsoft.AspNetCore.SignalR;
using GRC.WebAPI.Hubs;
using GRC.WebAPI.Services.Notifications;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.ResponseCompression;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using GRC.Infrastructure.Identity.Seeds;
using GRC.WebAPI.Authorization;
using GRC.Infrastructure.Data;
using GRC.WebAPI.Authorization; // duplicate ok
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.ApplicationInsights.AspNetCore;
using Microsoft.AspNetCore.Identity;

var builder = WebApplication.CreateBuilder(args);

// Validate DI on build — helps surfacing missing registrations early
// Disable ValidateOnBuild in Development to allow debugger to attach and to surfice runtime errors instead of failing fast.
builder.Host.UseDefaultServiceProvider((context, options) =>
{
 var isDev = context.HostingEnvironment.IsDevelopment();
 options.ValidateScopes = true;
 options.ValidateOnBuild = !isDev; // keep strict validation in non-dev (production)
});

// Add services to the container.
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();

// Add in-memory cache for negotiate nonces (use Redis in production)
builder.Services.AddMemoryCache();

// Add Application Insights telemetry
builder.Services.AddApplicationInsightsTelemetry();
builder.Services.AddSingleton<Microsoft.ApplicationInsights.TelemetryClient>();

// Add distributed cache (Redis for production scalability)
builder.Services.AddStackExchangeRedisCache(options =>
{
 options.Configuration = builder.Configuration.GetConnectionString("Redis") ?? "localhost:6379";
 options.InstanceName = "GRC_";
});
builder.Services.AddSingleton<IDistributedCache, Microsoft.Extensions.Caching.StackExchangeRedis.RedisCache>();

// Register ReportGenerationService implementation
builder.Services.AddScoped<IReportGenerationService, ReportGenerationServiceImpl>();

// Add DbContext from connection string
var connection = builder.Configuration.GetConnectionString("DefaultConnection");
if (string.IsNullOrWhiteSpace(connection))
{
 throw new InvalidOperationException("DefaultConnection string is missing in configuration.");
}
builder.Services.AddDbContext<GRCDbContext>(options => options.UseSqlServer(connection));
builder.Services.AddScoped<GRCDbContext>();

// UnitOfWork registration (doğru namespace ve tam sınıf adı)
builder.Services.AddScoped<GRC.SharedKernel.Interfaces.IUnitOfWork, GRC.Infrastructure.Data.UnitOfWork.UnitOfWork>();

// Response compression and caching
// --- Response compression: yalnızca production (veya konfig ile) etkinleştir ---
if (!builder.Environment.IsDevelopment())
{
 builder.Services.AddResponseCompression(options =>
 {
 options.EnableForHttps = true;
 options.Providers.Add<BrotliCompressionProvider>();
 options.Providers.Add<GzipCompressionProvider>();
 });
 builder.Services.Configure<BrotliCompressionProviderOptions>(options => options.Level = CompressionLevel.Fastest);
 builder.Services.Configure<GzipCompressionProviderOptions>(options => options.Level = CompressionLevel.Fastest);
}
else
{
 // development: response compression kapalı => BrowserLink/BrowserRefresh uyarılarını azaltır
}

builder.Services.AddResponseCaching();

// Configure Swagger to support JWT Bearer authorization in UI
builder.Services.AddSwaggerGen(c =>
{
 c.SwaggerDoc("v1", new OpenApiInfo { Title = "GRC API", Version = "v1" });
 var securityScheme = new OpenApiSecurityScheme
 {
 Name = "Authorization",
 Description = "Enter 'Bearer {token}'",
 In = ParameterLocation.Header,
 Type = SecuritySchemeType.Http,
 Scheme = "bearer",
 BearerFormat = "JWT",
 Reference = new OpenApiReference
 {
 Type = ReferenceType.SecurityScheme,
 Id = "Bearer"
 }
 };

 c.AddSecurityDefinition("Bearer", securityScheme);
 c.AddSecurityRequirement(new OpenApiSecurityRequirement
 {
 { securityScheme, Array.Empty<string>() }
 });
});

// JWT configuration — production-safe defaults (read from configuration)
var jwtKey = builder.Configuration["Jwt:Key"];
var jwtIssuer = builder.Configuration["Jwt:Issuer"];
var jwtAudience = builder.Configuration["Jwt:Audience"];

// If no key and running development, keep permissive but warn
if (string.IsNullOrWhiteSpace(jwtKey) && !builder.Environment.IsDevelopment())
{
 throw new InvalidOperationException("Jwt:Key is missing in configuration for non-development environment.");
}

var signingKey = !string.IsNullOrWhiteSpace(jwtKey)
 ? new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey))
 : null;

// Authentication (JWT Bearer) with SignalR support
builder.Services.AddAuthentication(options =>
{
 options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
 options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
 options.RequireHttpsMetadata = !builder.Environment.IsDevelopment();
 options.SaveToken = true;

 options.TokenValidationParameters = new TokenValidationParameters
 {
 ValidateIssuerSigningKey = signingKey != null,
 IssuerSigningKey = signingKey,
 ValidateIssuer = !string.IsNullOrWhiteSpace(jwtIssuer),
 ValidIssuer = jwtIssuer,
 ValidateAudience = !string.IsNullOrWhiteSpace(jwtAudience),
 ValidAudience = jwtAudience,
 ValidateLifetime = true,
 ClockSkew = TimeSpan.FromSeconds(30)
 };

 // Support SignalR access_token via query string for websockets (securely)
 options.Events = new JwtBearerEvents
 {
 OnMessageReceived = context =>
 {
 var accessToken = context.Request.Query["access_token"].FirstOrDefault();
 var path = context.HttpContext.Request.Path;
 if (!string.IsNullOrEmpty(accessToken) && path.StartsWithSegments("/hubs/notifications"))
 {
 context.Token = accessToken;
 }
 return Task.CompletedTask;
 }
 };
});

// authorization handlers
builder.Services.AddSingleton<IAuthorizationHandler, PermissionAuthorizationHandler>();
builder.Services.AddScoped<IAuthorizationHandler, SubscriptionAuthorizationHandler>();
// session & subscription services
builder.Services.AddScoped<IUserSessionService, GRC.Infrastructure.Identity.Services.UserSessionService>();
builder.Services.AddScoped<IUserSubscriptionService, GRC.Infrastructure.Identity.Services.UserSubscriptionService>();
builder.Services.AddAuthorization(options => {
 options.AddPolicy("RequireActiveSubscription", policy => policy.Requirements.Add(new SubscriptionRequirement()));
 });

// Other AI and repository registrations
builder.Services.AddHttpClient();
builder.Services.AddSingleton<GRC.WebAPI.Services.AI.FeatureExtractionService>();
builder.Services.AddScoped<GRC.WebAPI.Services.AI.AiAdvisorService>();
builder.Services.AddScoped<GRC.WebAPI.Services.AI.RiskProjectionService>();
builder.Services.AddScoped<GRC.WebAPI.Services.AI.ControlPredictionService>();
builder.Services.AddScoped<GRC.WebAPI.Services.AI.RiskAppetiteService>();
builder.Services.AddScoped<GRC.WebAPI.Services.AI.RiskProfileService>();
builder.Services.AddScoped<GRC.WebAPI.Services.AI.FindingSuggestionService>();
builder.Services.AddScoped<GRC.WebAPI.Services.AI.ComplianceMaturityService>();
builder.Services.AddScoped<GRC.WebAPI.Services.AI.UnitInsightService>();
builder.Services.AddScoped<GRC.WebAPI.Services.AI.CorrectionActionService>();
builder.Services.AddScoped<GRC.WebAPI.Services.AI.OpportunityService>();

// Register repository and export & learning tracker services
builder.Services.AddScoped<IModelAuditRepository, ModelAuditRepository>();
builder.Services.AddScoped<ModelExportService>();
builder.Services.AddScoped<LearningTrackerService>();

// Feedback repository and service
builder.Services.AddScoped<IFeedbackRepository, FeedbackRepository>();
builder.Services.AddScoped<GRC.WebAPI.Services.AI.FeedbackService>();

// Use Ollama by default; can be changed in DI
builder.Services.AddScoped<GRC.WebAPI.Services.AI.IAiModelGateway, GRC.WebAPI.Services.AI.OllamaGateway>();
builder.Services.AddScoped<GRC.WebAPI.Services.AI.OpenAiGateway>();

// Notification service — use fully-qualified interface so ambiguous global INotificationService is not picked
builder.Services.AddScoped<GRC.WebAPI.Services.INotificationService, GRC.WebAPI.Services.NotificationService>();
builder.Services.AddScoped<NotificationOrchestrator>();

// Register InMemoryNotificationStore
builder.Services.AddSingleton<GRC.WebAPI.Services.Notifications.INotificationStore, GRC.WebAPI.Services.Notifications.InMemoryNotificationStore>();

// SignalR for real-time notifications
builder.Services.AddSignalR();

// add SignalR IntegrationHub mapping and DI registration
// locate place after builder.Services.AddSignalR(); and add Registration

// Register IntegrationHub
builder.Services.AddSingleton<Microsoft.AspNetCore.SignalR.HubConnectionContext>();
builder.Services.AddScoped<GRC.WebAPI.Hubs.IntegrationHub>();

// Configure form options and large upload settings
builder.Services.Configure<Microsoft.AspNetCore.Http.Features.FormOptions>(options => {
 options.MultipartBodyLengthLimit =1024L *1024L *200; //200 MB
 options.ValueLengthLimit = int.MaxValue;
 options.MemoryBufferThreshold = int.MaxValue;
});

// CORS — use allow list from configuration (safe default)
var allowedOrigins = builder.Configuration.GetSection("Cors:AllowedOrigins").Get<string[]>() ?? new[] { "https://localhost:5001" };
builder.Services.AddCors(options =>
{
 options.AddPolicy("DefaultCors", policy =>
 {
 policy.WithOrigins(allowedOrigins)
 .AllowAnyMethod()
 .AllowAnyHeader()
 .AllowCredentials();
 });
});

builder.Services.AddIntegrationServices();

// Register email queue and worker
builder.Services.AddSingleton<GRC.WebAPI.Services.Notifications.IEmailQueue, GRC.WebAPI.Services.Notifications.InMemoryEmailQueue>();
builder.Services.AddHostedService<GRC.WebAPI.Services.Notifications.EmailSenderWorker>();

// Register RoleEmailMappingService for admin-managed role->email mappings
builder.Services.AddSingleton<GRC.WebAPI.Services.Notifications.RoleEmailMappingService>();

// Ensure notification store and email queue registrations exist (they were added earlier)
builder.Services.AddSingleton<GRC.WebAPI.Services.Notifications.INotificationStore, GRC.WebAPI.Services.Notifications.InMemoryNotificationStore>();
builder.Services.AddSingleton<GRC.WebAPI.Services.Notifications.IEmailQueue, GRC.WebAPI.Services.Notifications.InMemoryEmailQueue>();
builder.Services.AddHostedService<GRC.WebAPI.Services.Notifications.EmailSenderWorker>();

// register import scheduler background worker
builder.Services.AddHostedService<GRC.WebAPI.Services.Integration.ImportSchedulerWorker>();

// register maintenance worker for cleaning old uploaded files
builder.Services.AddHostedService<GRC.WebAPI.Services.Maintenance.FileCleanupWorker>();

// Build host with improved diagnostics on failure
WebApplication app;
try
{
 app = builder.Build();
}
catch (Exception ex)
{
 Console.WriteLine("Failed to build host. Exception details:");
 Console.WriteLine(ex.ToString());

 if (ex is AggregateException agg)
 {
 foreach (var ie in agg.Flatten().InnerExceptions)
 {
 Console.WriteLine("Inner exception:");
 Console.WriteLine(ie.ToString());
 }
 }
 else if (ex.InnerException != null)
 {
 Console.WriteLine("Inner exception:");
 Console.WriteLine(ex.InnerException.ToString());
 }

 Console.WriteLine("Ensure configuration (ConnectionStrings:DefaultConnection, Jwt:Key) are set for non-development environments.");
 Console.WriteLine("Tip: set ASPNETCORE_ENVIRONMENT=Development for local debugging to disable ValidateOnBuild.");
 Environment.Exit(1);
 throw;
}

// Attempt to launch Ollama installer if present on developer machine
// --- Ollama installer'ı sadece geliştirme ve konfig izinliyse çalıştır ---
var enableOllamaInstaller = builder.Configuration.GetValue<bool>("Dev:LaunchOllamaInstaller", false);

if (enableOllamaInstaller && app.Environment.IsDevelopment())
{
 var ollamaInstallerPath = "C:\\Users\\ahmetefe\\Desktop\\OllamaSetup.exe";
 try
 {
 OllamaInstallerHelper.LaunchInstallerIfExists(ollamaInstallerPath, app.Logger);
 }
 catch (Exception ex)
 {
 app.Logger?.LogWarning(ex, "Ollama installer launch failed (ignored during dev).");
 }
}

// Configure the HTTP request pipeline.
// Security and compression first
if (!app.Environment.IsDevelopment())
{
 app.UseHsts();

 // Enable response compression in non-development environments when configured
 app.UseResponseCompression();
}

app.UseHttpsRedirection();

// Optionally skip early middleware during local debug to avoid debugger/middleware conflicts
var skipEarlyMiddleware = Debugger.IsAttached || (app.Environment.IsDevelopment() && builder.Configuration.GetValue<bool>("Dev:DisableMiddlewareForDebug", true));
if (skipEarlyMiddleware)
{
 var dbgLogger = app.Services.GetService(typeof(ILogger<Program>)) as ILogger<Program>;
 dbgLogger?.LogInformation("Skipping SecurityHeaders and RateLimiting middleware because debugger is attached or Dev:DisableMiddlewareForDebug=true.");
}
else
{
 // Global security headers middleware (ensure runs early)
 app.UseMiddleware<GRC.WebAPI.Middleware.SecurityHeadersMiddleware>();

 // Rate limiting should be applied early to protect resources
 app.UseMiddleware<GRC.WebAPI.Middleware.RateLimitingMiddleware>();
}

app.UseRouting();

// Move authentication/authorization early to allow protecting static files and hubs
app.UseAuthentication();
app.UseAuthorization();

// Protect sensitive static SPA assets, swagger and assets in non-development environments.
// In Development, allow anonymous access to Swagger and static SPA resources so debugger and local dev workflows work.
app.Use(async (context, next) =>
{
 var path = context.Request.Path.Value ?? string.Empty;
 var isDev = app.Environment.IsDevelopment();

 // Paths we consider sensitive in production
 var sensitivePaths = new[]
 {
 "/",
 "/dashboard.html",
 "/index.html",
 "/offline.html",
 };

 bool isSensitiveStatic = sensitivePaths.Contains(path, StringComparer.OrdinalIgnoreCase)
 || path.StartsWith("/assets", StringComparison.OrdinalIgnoreCase);

 bool isSwaggerPath = path.StartsWith("/swagger", StringComparison.OrdinalIgnoreCase)
 || path.Equals("/swagger", StringComparison.OrdinalIgnoreCase)
 || path.Equals("/swagger/v1/swagger.json", StringComparison.OrdinalIgnoreCase);

 // If not development, require authentication for swagger, sensitive static files and assets
 if (!isDev && (isSensitiveStatic || isSwaggerPath) && !(context.User?.Identity?.IsAuthenticated ?? false))
 {
 context.Response.StatusCode = StatusCodes.Status401Unauthorized;
 return;
 }

 await next();
});

// Use the stricter CORS policy
app.UseCors("DefaultCors");

// Insert user embedding middleware before static files are served so HTML pages have embedded user
app.UseMiddleware<GRC.WebAPI.Middleware.UserEmbeddingMiddleware>();

// Enable Swagger UI only in Development by default (can be toggled via config if needed)
if (app.Environment.IsDevelopment())
{
 app.UseSwagger();
 app.UseSwaggerUI(c =>
 {
 c.SwaggerEndpoint("/swagger/v1/swagger.json", "GRC API v1");
 c.RoutePrefix = "swagger"; // serve UI at /swagger
 });
}

// Serve static files from wwwroot (dashboard pages) with cache headers
var defaultFilesOptions = new DefaultFilesOptions();
defaultFilesOptions.DefaultFileNames.Clear();
defaultFilesOptions.DefaultFileNames.Add("dashboard.html");
app.UseDefaultFiles(defaultFilesOptions);
app.UseStaticFiles(new StaticFileOptions
{
 OnPrepareResponse = ctx =>
 {
 var path = ctx.File.PhysicalPath ?? string.Empty;
 // Keep index-like files no-cache; others long-cache
 if (path.EndsWith("dashboard.html", StringComparison.OrdinalIgnoreCase) ||
 path.EndsWith("index.html", StringComparison.OrdinalIgnoreCase) ||
 path.EndsWith("offline.html", StringComparison.OrdinalIgnoreCase))
 {
 ctx.Context.Response.Headers["Cache-Control"] = "no-cache, no-store, must-revalidate";
 ctx.Context.Response.Headers["Pragma"] = "no-cache";
 ctx.Context.Response.Headers["Expires"] = "0";
 }
 else
 {
 ctx.Context.Response.Headers["Cache-Control"] = "public,max-age=31536000";
 }
 }
});

// Response caching after authentication (optional)
app.UseResponseCaching();

app.MapControllers();
app.MapHub<NotificationsHub>("/hubs/notifications");
app.MapHub<GRC.WebAPI.Hubs.IntegrationHub>("/hubs/integration");

// Make SPA fallback consistent with default file
app.MapFallbackToFile("dashboard.html");

// Run with detailed exception logging to surface inner DI errors
try
{
 app.Run();
}
catch (Exception ex)
{
 // Print full exception chain to console (Output Window in VS)
 Console.WriteLine("Host terminated with exception:");
 Console.WriteLine(ex.ToString());

 // Try to log via DI logger if available
 try
 {
 var logger = app.Services.GetService(typeof(ILogger<Program>)) as ILogger;
 if (logger != null)
 {
 logger.LogCritical(ex, "Host terminated with exception");
 }
 }
 catch
 {
 // ignore logger failures
 }

 // Re-throw so the process exit code reflects failure
 throw;

}

// Run identity seeder in development environment
if (app.Environment.IsDevelopment())
{
 using (var scope = app.Services.CreateScope())
 {
 var services = scope.ServiceProvider;
 var logger = services.GetService<ILogger<Program>>();
 try
 {
 // Seed identity roles and test users (development only)
 if (app.Environment.IsDevelopment())
 {
 using (var scope = app.Services.CreateScope())
 {
 var services = scope.ServiceProvider;
 var logger = services.GetService<ILogger<Program>>();
 try
 {
 // Seed identity roles and test users (development only)
 await DataSeeder.SeedAsync(services);
 // Apply pending migrations (safe in dev) and seed governance data
 try
 {
 var db = services.GetRequiredService<GRCDbContext>();
 await db.Database.MigrateAsync();
 await GRC.Infrastructure.Data.Seeds.SeedDataExtensions.SeedDataAsync(services);
 // ensure risk level lookup seeded
 GRC.Infrastructure.Data.Seeds.RiskLevelSeed.EnsureSeed(services);
 logger?.LogInformation("Governance seed completed.");
 }
 catch (Exception seedEx)
 {
 logger?.LogWarning(seedEx, "Governance seed failed (ignored in dev).");
 }
 logger?.LogInformation("Identity seed completed.");
 }
 catch (Exception ex)
 {
 logger?.LogError(ex, "An error occurred while seeding the identity database.");
 }
 }
 }

 // schedule backfill job once in dev to populate RiskLevelId
 try
 {
 var services = app.Services;
 var scope = services.CreateScope();
 var job = scope.ServiceProvider.GetRequiredService<GRC.Infrastructure.Data.Jobs.BackfillRiskLevelJob>();
 _ = Task.Run(async () => { await job.RunAsync(500); });
 }
 catch (Exception ex)
 {
 var l = app.Services.GetRequiredService<ILogger<Program>>();
 l.LogWarning(ex, "Failed to schedule backfill job in development.");
 }
}

// Ensure directories exist
var webroot = app.Environment.WebRootPath ?? Path.Combine(Directory.GetCurrentDirectory(), "wwwroot");
Directory.CreateDirectory(Path.Combine(webroot, "integration", "uploads"));
Directory.CreateDirectory(Path.Combine(webroot, "reports", "archives"));
Directory.CreateDirectory(Path.Combine(webroot, "riskappetite", "archives"));

// Testler için WebApplicationFactory'nin Program tipini bulabilmesi amacıyla
public partial class Program { }

// add application services
 builder.Services.AddApplicationServices();
+ // register model persistence with logging
+ builder.Services.AddSingleton<GRC.Application.Services.AI.IModelPersistence, GRC.Application.Services.AI.ModelRegistry>();

























































































