﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using GRC.Domain.Entities.RiskManagement;
using GRC.Domain.Common;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.Risk.Categories
{
 /// <summary>
 /// Technology-focused risk category capturing platform and innovation risks
 /// </summary>
 public class TechnologicRiskCategory : GRC.Domain.Entities.RiskManagement.RiskCategory
 {
 /// <summary>
 /// JSON payload describing vulnerabilities in tech stack (e.g. {"vulns": ["dep1","dep2"]})
 /// </summary>
 public string? TechStackVulnerabilities { get; set; }

 /// <summary>
 /// Rate at which new innovations are adopted in the environment (0-1)
 /// </summary>
 public double? InnovationAdoptionRate { get; set; }

 /// <summary>
 /// Calculated obsolescence score for the technology estate (0-100)
 /// </summary>
 public double? ObsolescenceScore { get; set; }

 /// <summary>
 /// (Optional) Related cyber/IT category for tighter integration
 /// </summary>
 public ITCyberRiskCategory? RelatedCyber { get; set; }

 public TechnologicRiskCategory() : base() { }

 /// <inheritdoc />
 );
 }

 /// <inheritdoc />
 

 /// <inheritdoc />
 public override async Task<List<string>> GetAIRecommendationsAsync()
 {
 var rec = new List<string>();
 var vulns = DeserializeVulnerabilities();
 if (vulns.Count >0)
 {
 rec.Add($"Detected {vulns.Count} stack vulnerabilities — prioritize patching and dependency updates.");
 }
 if ((ObsolescenceScore ??0) >70)
 {
 rec.Add("High obsolescence detected — plan migration/modernization roadmap.");
 }
 return await Task.FromResult(rec);
 }

 /// <summary>
 /// Evaluate obsolescence risk as a metric combining internal score and vuln density
 /// </summary>
 public double EvaluateTechObsolescence()
 {
 var vulns = DeserializeVulnerabilities().Count;
 var obs = ObsolescenceScore ??50.0;
 return Math.Min(100.0, obs + vulns *2.5);
 }

 /// <summary>
 /// Attempt to integrate findings with an IT/Cyber category — returns true if integration possible
 /// </summary>
 public async Task<bool> IntegrateWithCyber()
 {
 // If a related cyber category is present, simulate linking
 if (RelatedCyber != null)
 {
 // In real app: create references or publish events
 await Task.CompletedTask;
 return true;
 }
 return false;
 }

 private List<string> DeserializeVulnerabilities()
 {
 if (string.IsNullOrWhiteSpace(TechStackVulnerabilities)) return new List<string>();
 try
 {
 using var doc = JsonDocument.Parse(TechStackVulnerabilities);
 if (doc.RootElement.ValueKind == JsonValueKind.Object && doc.RootElement.TryGetProperty("vulns", out var v) && v.ValueKind == JsonValueKind.Array)
 {
 return v.EnumerateArray().Select(x => x.GetString() ?? string.Empty).Where(s => !string.IsNullOrEmpty(s)).ToList();
 }

 if (doc.RootElement.ValueKind == JsonValueKind.Array)
 {
 return doc.RootElement.EnumerateArray().Select(x => x.GetString() ?? string.Empty).Where(s => !string.IsNullOrEmpty(s)).ToList();
 }
 }
 catch { }
 return new List<string>();
 }

 private string DetermineLevel(decimal score)
 {
 return score switch
 {
 <3 => "Low",
 <6 => "Medium",
 <9 => "High",
 _ => "Critical"
 };
 }

 /// <inheritdoc />
 public override RiskCategoryOutput ExportData()
 {
 var outp = base.ExportData();
 outp.Metrics["Obsolescence"] = ObsolescenceScore ??0.0;
 outp.Metrics["VulnerabilityCount"] = DeserializeVulnerabilities().Count;
 outp.Metrics["InnovationAdoptionRate"] = InnovationAdoptionRate ??0.0;
 return outp;
 }
 }
}





