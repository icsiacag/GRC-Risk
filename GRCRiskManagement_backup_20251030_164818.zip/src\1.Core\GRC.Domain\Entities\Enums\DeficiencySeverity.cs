﻿namespace GRC.Domain.Entities.Enums
{
    public enum DeficiencySeverity
    {
        Low = 1,
        Medium = 2,
        High = 3,
        Critical = 4
    }
}


