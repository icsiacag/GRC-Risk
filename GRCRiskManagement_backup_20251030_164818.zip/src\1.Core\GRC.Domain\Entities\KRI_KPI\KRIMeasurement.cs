﻿using System;
using System.Collections.Generic;
using GRC.SharedKernel;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.KRI_KPI
{
    /// <summary>
    /// KRIMeasurement entity for GRC system
    /// Generated on: 2025-10-30 16:18:22
    /// </summary>
    public class KRIMeasurement : GRC.SharedKernel.Entities.BaseEntity
    {
        public Guid KRIId { get; set; }
        public DateTime MeasurementDate { get; set; }
        public decimal Value { get; set; }
        public ThresholdLevel Level { get; set; }
        public string Comments { get; set; }
        public string MeasuredBy { get; set; }
        
        // Navigation properties and domain logic can be added here
        
        /// <summary>
        /// Validates the entity state
        /// </summary>
        
        /// <summary>
        /// Domain event when entity is created
        /// </summary>
        public void OnCreated()
        {
            CreatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
        
        /// <summary>
        /// Domain event when entity is updated
        /// </summary>
        public void OnUpdated()
        {
            UpdatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
    }
}



