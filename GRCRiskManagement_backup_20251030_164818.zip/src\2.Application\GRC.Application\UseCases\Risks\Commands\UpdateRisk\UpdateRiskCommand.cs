using MediatR;

namespace GRC.Application.UseCases.Risks.Commands.UpdateRisk
{
    public class UpdateRiskCommand : IRequest<Unit>
    {
        public int Id { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public int Probability { get; set; }
        public int Impact { get; set; }
    }
}



