// ...existing code...
 public async Task<IEnumerable<RiskListItemDto>> Handle(GetRisksListQuery request, CancellationToken cancellationToken)
 {
 var risks = await _repo.GetAllWithCategoryAsync(cancellationToken);
 return risks.Select(r => new RiskListItemDto
 {
 Id = r.Id,
 Title = r.Title,
 Description = r.Description,
 RiskLevel = r.RiskLevel,
 Status = r.Status,
 Owner = r.Owner,
 CreatedAt = r.CreatedAt,
 CategoryType = r.Category != null ? EF.Property<string>(r.Category, "CategoryType") : string.Empty,
 CategoryMetadataJson = r.Category?.MetadataJson
 });
 }
