﻿using GRC.SharedKernel;
using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.Billing
{
    public class MembershipPlan : AuditableEntity<int>
    {
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public decimal Price { get; set; }
        public int DurationMonths { get; set; }
        public int MaxUsers { get; set; }
        public bool IsActive { get; set; }
    }
}




