using System;
using System.Collections.Generic;
using System.Linq;
using GRC.Infrastructure.Data.Content;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

namespace GRC.WebAPI.Controllers.v1
{
 [ApiController]
 [Route("api/v1/analytics")]
 public class AnalyticsController : ControllerBase
 {
 private readonly GRCDbContext _db;

 public AnalyticsController(GRCDbContext db)
 {
 _db = db;
 }

 [HttpGet("dashboards")]
 public ActionResult<IEnumerable<DashboardDto>> GetDashboards()
 {
 return Ok(new[] { new DashboardDto { Id = Guid.NewGuid(), Title = "Risk Overview", Description = "Key risk metrics" } });
 }

 [HttpGet("kpis")]
 public ActionResult<object> GetKpis()
 {
 var risks = _db.Risks.AsNoTracking();
 var total = risks.Count();

 // Use RiskLevelLookup to normalize
 var lookups = _db.Set<GRC.Infrastructure.Data.Entities.RiskLevelLookup>().AsNoTracking().ToList();
 int critical =0, high =0, medium =0, low =0;
 foreach (var r in risks)
 {
 var rl = r.RiskLevel ?? string.Empty;
 var found = lookups.FirstOrDefault(l => !string.IsNullOrEmpty(l.Keywords) && l.Keywords.Split(',').Any(k => rl.Contains(k, StringComparison.OrdinalIgnoreCase)));
 if (found != null)
 {
 switch (found.Label.ToLowerInvariant())
 {
 case "critical": critical++; break;
 case "high": high++; break;
 case "medium": medium++; break;
 case "low": low++; break;
 }
 }
 }
 var closed = risks.Count(r => r.Status != null && (EF.Functions.Like(r.Status, "%closed%") || EF.Functions.Like(r.Status, "%kapal�%")));
 var complianceRate = total ==0 ?100 : (int)Math.Round(100.0 * closed / total);

 return Ok(new
 {
 totalRisks = total,
 critical,
 high,
 medium,
 low,
 complianceRate
 });
 }

 [HttpGet("risktrends")]
 public ActionResult<IEnumerable<object>> GetRiskTrends([FromQuery] int months =6)
 {
 var cutoff = DateTime.UtcNow.AddMonths(-months +1);
 var q = _db.Risks.AsNoTracking()
 .Where(r => r.IdentifiedDate >= cutoff)
 .GroupBy(r => new { Year = r.IdentifiedDate.Year, Month = r.IdentifiedDate.Month })
 .Select(g => new { year = g.Key.Year, month = g.Key.Month, count = g.Count() })
 .OrderBy(x => x.year).ThenBy(x => x.month)
 .ToList();

 var result = new List<object>();
 for (var i = months -1; i >=0; i--)
 {
 var dt = DateTime.UtcNow.AddMonths(-i);
 var item = q.FirstOrDefault(x => x.year == dt.Year && x.month == dt.Month);
 var label = dt.ToString("MMM yyyy");
 result.Add(new { label, count = item?.count ??0 });
 }
 return Ok(result);
 }

 [HttpGet("breakdown")]
 public ActionResult<IEnumerable<object>> GetBreakdown()
 {
 var q = _db.Risks.AsNoTracking()
 .GroupBy(r => r.RiskLevel ?? "Unknown")
 .Select(g => new { level = g.Key, count = g.Count() })
 .OrderByDescending(x => x.count)
 .ToList();
 return Ok(q);
 }

 [HttpGet("maturity")]
 public ActionResult<object> GetMaturity()
 {
 // Try to compute a simple maturity indicator from AssessmentResults if available
 try
 {
 var assessments = _db.AssessmentResults.AsNoTracking().Where(a => a.Type != null).ToList();
 if (assessments.Count ==0)
 {
 return Ok(new { progress =80, level =4, label = "Quantitatively Managed" });
 }

 // if RawPayload contains numeric score, average them
 var scores = new List<double>();
 foreach (var a in assessments)
 {
 if (string.IsNullOrWhiteSpace(a.RawPayload)) continue;
 try
 {
 using var doc = JsonDocument.Parse(a.RawPayload);
 if (doc.RootElement.TryGetProperty("score", out var prop) && prop.ValueKind == JsonValueKind.Number)
 {
 scores.Add(prop.GetDouble());
 }
 }
 catch { }
 }

 if (scores.Count >0)
 {
 var avg = scores.Average();
 var progress = (int)Math.Round(avg);
 var level = Math.Clamp((int)Math.Ceiling(progress /20.0),1,5);
 var labels = new[] { "Initial", "Managed", "Defined", "Quantitatively Managed", "Optimizing" };
 return Ok(new { progress, level, label = labels[level -1] });
 }

 return Ok(new { progress =80, level =4, label = "Quantitatively Managed" });
 }
 catch
 {
 return Ok(new { progress =80, level =4, label = "Quantitatively Managed" });
 }
 }

 public class DashboardDto { public Guid Id { get; set; } public string Title { get; set; } public string Description { get; set; } }
 }
}
