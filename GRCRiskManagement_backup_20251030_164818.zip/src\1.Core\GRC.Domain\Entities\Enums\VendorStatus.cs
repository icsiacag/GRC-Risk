﻿namespace GRC.Domain.Entities.Enums
{
    public enum VendorStatus
    {
        Active = 1,
        Inactive = 2,
        UnderReview = 3,
        Suspended = 4
    }
}


