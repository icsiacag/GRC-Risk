﻿using System;
using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.Risk.Categories
{
 public class StrategicRiskCategory : GRC.Domain.Entities.RiskManagement.RiskCategory
 {
 public string? StrategicObjectives { get; set; }
 public StrategicRiskCategory() : base() { }
 public StrategicRiskCategory(string code, string name, string description) : base() { Code = code; Name = name; Description = description; }
 }
}




