using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GRC.Infrastructure.Data.Migrations
{
 public partial class RiskCategory_TPH_Expanded : Migration
 {
 protected override void Up(MigrationBuilder migrationBuilder)
 {
 migrationBuilder.AddColumn<string>(
 name: "Discriminator",
 table: "RiskCategories",
 type: "nvarchar(50)",
 nullable: true);

 // add new specialized columns
 migrationBuilder.AddColumn<string>(name: "ImpactDefaults", table: "RiskCategories", type: "nvarchar(max)", nullable: true);
 migrationBuilder.AddColumn<string>(name: "ProbabilityDefaults", table: "RiskCategories", type: "nvarchar(max)", nullable: true);
 migrationBuilder.AddColumn<string>(name: "ProcessLinks", table: "RiskCategories", type: "nvarchar(max)", nullable: true);
 migrationBuilder.AddColumn<string>(name: "CurrencyExposures", table: "RiskCategories", type: "nvarchar(max)", nullable: true);
 migrationBuilder.AddColumn<string>(name: "ObjectiveLinks", table: "RiskCategories", type: "nvarchar(max)", nullable: true);
 migrationBuilder.AddColumn<string>(name: "LongTermHorizons", table: "RiskCategories", type: "nvarchar(max)", nullable: true);
 migrationBuilder.AddColumn<string>(name: "MilestoneDependencies", table: "RiskCategories", type: "nvarchar(max)", nullable: true);
 migrationBuilder.AddColumn<decimal>(name: "BudgetVariances", table: "RiskCategories", type: "decimal(18,2)", nullable: true);
 migrationBuilder.AddColumn<string>(name: "TechStackVulnerabilities", table: "RiskCategories", type: "nvarchar(max)", nullable: true);
 migrationBuilder.AddColumn<double>(name: "InnovationAdoptionRate", table: "RiskCategories", type: "float", nullable: true);
 migrationBuilder.AddColumn<string>(name: "AssetProtectionLevels", table: "RiskCategories", type: "nvarchar(50)", maxLength:50, nullable: true);
 migrationBuilder.AddColumn<string>(name: "ThreatVectors", table: "RiskCategories", type: "nvarchar(max)", nullable: true);
 migrationBuilder.AddColumn<string>(name: "ESGPillars", table: "RiskCategories", type: "nvarchar(max)", nullable: true);
 migrationBuilder.AddColumn<string>(name: "SustainabilityReportingStandards", table: "RiskCategories", type: "nvarchar(max)", nullable: true);
 migrationBuilder.AddColumn<double>(name: "TalentRetentionMetrics", table: "RiskCategories", type: "float", nullable: true);
 migrationBuilder.AddColumn<string>(name: "DiversityIndices", table: "RiskCategories", type: "nvarchar(max)", nullable: true);
 migrationBuilder.AddColumn<string>(name: "SupplierDependencies", table: "RiskCategories", type: "nvarchar(max)", nullable: true);
 migrationBuilder.AddColumn<string>(name: "DisruptionScenarios", table: "RiskCategories", type: "nvarchar(max)", nullable: true);
 migrationBuilder.AddColumn<string>(name: "JurisdictionLaws", table: "RiskCategories", type: "nvarchar(max)", nullable: true);
 migrationBuilder.AddColumn<decimal>(name: "PenaltyEstimates", table: "RiskCategories", type: "decimal(18,2)", nullable: true);
 migrationBuilder.AddColumn<string>(name: "CountryRiskScores", table: "RiskCategories", type: "nvarchar(max)", nullable: true);
 migrationBuilder.AddColumn<bool>(name: "TradeBarrierFlags", table: "RiskCategories", type: "bit", nullable: true);
 migrationBuilder.AddColumn<string>(name: "PatentExposures", table: "RiskCategories", type: "nvarchar(max)", nullable: true);
 migrationBuilder.AddColumn<double>(name: "TechAdoptionRisks", table: "RiskCategories", type: "float", nullable: true);

 migrationBuilder.CreateIndex(name: "IX_RiskCategories_Discriminator", table: "RiskCategories", column: "Discriminator");
 }

 protected override void Down(MigrationBuilder migrationBuilder)
 {
 migrationBuilder.DropIndex(name: "IX_RiskCategories_Discriminator", table: "RiskCategories");
 migrationBuilder.DropColumn(name: "Discriminator", table: "RiskCategories");
 // drop specialized columns
 migrationBuilder.DropColumn(name: "ImpactDefaults", table: "RiskCategories");
 migrationBuilder.DropColumn(name: "ProbabilityDefaults", table: "RiskCategories");
 migrationBuilder.DropColumn(name: "ProcessLinks", table: "RiskCategories");
 migrationBuilder.DropColumn(name: "CurrencyExposures", table: "RiskCategories");
 migrationBuilder.DropColumn(name: "ObjectiveLinks", table: "RiskCategories");
 migrationBuilder.DropColumn(name: "LongTermHorizons", table: "RiskCategories");
 migrationBuilder.DropColumn(name: "MilestoneDependencies", table: "RiskCategories");
 migrationBuilder.DropColumn(name: "BudgetVariances", table: "RiskCategories");
 migrationBuilder.DropColumn(name: "TechStackVulnerabilities", table: "RiskCategories");
 migrationBuilder.DropColumn(name: "InnovationAdoptionRate", table: "RiskCategories");
 migrationBuilder.DropColumn(name: "AssetProtectionLevels", table: "RiskCategories");
 migrationBuilder.DropColumn(name: "ThreatVectors", table: "RiskCategories");
 migrationBuilder.DropColumn(name: "ESGPillars", table: "RiskCategories");
 migrationBuilder.DropColumn(name: "SustainabilityReportingStandards", table: "RiskCategories");
 migrationBuilder.DropColumn(name: "TalentRetentionMetrics", table: "RiskCategories");
 migrationBuilder.DropColumn(name: "DiversityIndices", table: "RiskCategories");
 migrationBuilder.DropColumn(name: "SupplierDependencies", table: "RiskCategories");
 migrationBuilder.DropColumn(name: "DisruptionScenarios", table: "RiskCategories");
 migrationBuilder.DropColumn(name: "JurisdictionLaws", table: "RiskCategories");
 migrationBuilder.DropColumn(name: "PenaltyEstimates", table: "RiskCategories");
 migrationBuilder.DropColumn(name: "CountryRiskScores", table: "RiskCategories");
 migrationBuilder.DropColumn(name: "TradeBarrierFlags", table: "RiskCategories");
 migrationBuilder.DropColumn(name: "PatentExposures", table: "RiskCategories");
 migrationBuilder.DropColumn(name: "TechAdoptionRisks", table: "RiskCategories");
 }
 }
}
