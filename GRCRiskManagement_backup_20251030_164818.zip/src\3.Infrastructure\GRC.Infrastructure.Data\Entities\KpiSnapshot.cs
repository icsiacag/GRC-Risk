using System;

namespace GRC.Infrastructure.Data.Entities
{
 public class KpiSnapshot
 {
 public int Id { get; set; }
 public DateTime SnapshotAt { get; set; }
 public int TotalRisks { get; set; }
 public int CriticalCount { get; set; }
 public int HighCount { get; set; }
 public int MediumCount { get; set; }
 public int LowCount { get; set; }
 public int ComplianceRate { get; set; }
 public string JsonPayload { get; set; } = "{}";
 }
}
