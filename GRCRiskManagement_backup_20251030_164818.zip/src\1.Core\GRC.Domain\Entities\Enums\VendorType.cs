﻿namespace GRC.Domain.Entities.Enums
{
    public enum VendorType
    {
        Supplier = 1,
        ServiceProvider = 2,
        Contractor = 3,
        Partner = 4
    }
}


