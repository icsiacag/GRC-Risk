﻿using GRC.SharedKernel;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.AI
{
    public class Feedback : GRC.SharedKernel.Entities.EntityBase
    {
        public string EntityType { get; set; } = string.Empty;
        public int EntityId { get; set; }
        public string FeedbackText { get; set; } = string.Empty;
        public int Rating { get; set; }
        public string UserId { get; set; } = string.Empty;
        public bool IsUseful { get; set; }
    }
}




