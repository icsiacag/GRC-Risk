using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace GRC.Infrastructure.Data.Repositories
{
 public class KpiSnapshotRepository
 {
 private readonly Content.GRCDbContext _db;
 public KpiSnapshotRepository(Content.GRCDbContext db) { _db = db; }
 public async Task InsertSnapshotAsync(GRC.Infrastructure.Data.Entities.KpiSnapshot snapshot)
 {
 _db.Set<GRC.Infrastructure.Data.Entities.KpiSnapshot>().Add(snapshot);
 await _db.SaveChangesAsync();
 }
 public async Task<GRC.Infrastructure.Data.Entities.KpiSnapshot?> GetLatestAsync()
 {
 return await _db.Set<GRC.Infrastructure.Data.Entities.KpiSnapshot>().OrderByDescending(x => x.SnapshotAt).FirstOrDefaultAsync();
 }
 }
}
