using MediatR;

namespace GRC.Application.UseCases.Risks.Commands.CreateRisk
{
    public class CreateRiskCommand : IRequest<Guid>
    {
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public int RiskCategoryId { get; set; }
        public string Type { get; set; } = string.Empty;
        public string OwnerId { get; set; } = string.Empty;
        public string LikelihoodLevel { get; set; } = string.Empty;
        public string ImpactLevel { get; set; } = string.Empty;
        public string Department { get; set; } = string.Empty;
        public string Process { get; set; } = string.Empty;
    }
}
