﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using GRC.Domain.Entities.RiskManagement;
using GRC.Domain.Common;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.Risk.Categories
{
    public class InnovationRiskCategory : GRC.Domain.Entities.RiskManagement.RiskCategory
    {
        public string? PatentExposures { get; set; }
        public double? TechAdoptionRisks { get; set; }

        public InnovationRiskCategory() : base() { }

        );
        }

        

        public override async Task<List<string>> GetAIRecommendationsAsync()
        {
            var rec = new List<string>();
            rec.Add("Evaluate ROI for new innovations and prioritize pilots with measurable outcomes.");
            return await Task.FromResult(rec);
        }

        private List<string> DeserializeList(string? json)
        {
            if (string.IsNullOrWhiteSpace(json)) return new();
            try { return JsonSerializer.Deserialize<List<string>>(json) ?? new(); } catch { return new(); }
        }

        private string DetermineLevel(decimal score)
        {
            return score switch
            {
                < 3 => "Low",
                < 6 => "Medium",
                < 9 => "High",
                _ => "Critical"
            };
        }

        public override RiskCategoryOutput ExportData()
        {
            var o = base.ExportData();
            o.Metrics["PatentCount"] = DeserializeList(PatentExposures).Count;
            o.Metrics["TechAdoptionRisks"] = TechAdoptionRisks ?? 0.0;
            return o;
        }
    }
}





