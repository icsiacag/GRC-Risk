﻿using GRC.SharedKernel;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.AI
{
    public class ModelAudit : GRC.SharedKernel.Entities.EntityBase
    {
        public string ModelName { get; set; } = string.Empty;
        public string Action { get; set; } = string.Empty;
        public string RequestJson { get; set; } = string.Empty;
        public string ResponseJson { get; set; } = string.Empty;
    }
}



