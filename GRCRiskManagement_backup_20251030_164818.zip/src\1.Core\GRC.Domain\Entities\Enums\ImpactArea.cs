﻿namespace GRC.Domain.Entities.Enums
{
    public enum ImpactArea
    {
        Technical = 1,
        Business = 2,
        Operational = 3,
        Financial = 4,
        Compliance = 5
    }
}


