﻿using System;
using System.Collections.Generic;
using GRC.SharedKernel;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.IncidentManagement
{
    /// <summary>
    /// RootCause entity for GRC system
    /// Generated on: 2025-10-30 16:18:22
    /// </summary>
    public class RootCause : GRC.SharedKernel.Entities.BaseEntity
    {
        public Guid IncidentId { get; set; }
        public string Description { get; set; }
        public RootCauseCategory Category { get; set; }
        public string CorrectiveAction { get; set; }
        public DateTime IdentifiedDate { get; set; }
        public string IdentifiedBy { get; set; }
        public bool IsVerified { get; set; }
        
        // Navigation properties and domain logic can be added here
        
        /// <summary>
        /// Validates the entity state
        /// </summary>
        
        /// <summary>
        /// Domain event when entity is created
        /// </summary>
        public void OnCreated()
        {
            CreatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
        
        /// <summary>
        /// Domain event when entity is updated
        /// </summary>
        public void OnUpdated()
        {
            UpdatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
    }
}



