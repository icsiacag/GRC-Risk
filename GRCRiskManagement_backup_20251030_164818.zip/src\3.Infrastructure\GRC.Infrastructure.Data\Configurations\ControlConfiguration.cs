﻿using GRC.Domain.Entities.Controls;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GRC.Infrastructure.Data.Configurations
{
 /// <summary>
 /// EF Core configuration for the Control aggregate root.
 /// Modernized: added indexes, shadow rowversion for concurrency, comments and explicit cascade behaviour for test records.
 /// </summary>
 public class ControlConfiguration : IEntityTypeConfiguration<Control>
 {
 public void Configure(EntityTypeBuilder<Control> builder)
 {
 builder.ToTable("Controls");

 builder.HasKey(c => c.Id);

 builder.Property(c => c.ControlCode)
 .HasMaxLength(100)
 .IsRequired()
 .HasComment("Unique control code for referencing the control");

 builder.Property(c => c.Name)
 .HasMaxLength(500)
 .IsRequired();

 builder.Property(c => c.Description)
 .HasColumnType("nvarchar(max)")
 .HasComment("Free text description of the control");

 builder.Property(c => c.ControlType)
 .HasMaxLength(100)
 .HasComment("Type of control, e.g. Preventive, Detective, Corrective");

 builder.Property(c => c.Category)
 .HasMaxLength(100)
 .HasComment("Logical category for grouping controls");

 builder.Property(c => c.Frequency)
 .HasMaxLength(50)
 .HasComment("Execution frequency (Daily/Weekly/Monthly/Quarterly)")

 .HasComment("Execution frequency (Daily/Weekly/Monthly/Quarterly)");

 builder.Property(c => c.Owner)
 .HasMaxLength(200)
 .HasComment("Owner or responsible team for the control");

 // Shadow concurrency token to support optimistic concurrency without modifying domain class
 builder.Property<byte[]>("RowVersion").IsRowVersion().HasColumnName("RowVersion");

 // Indexes to support common queries / filters
 builder.HasIndex(c => c.ControlCode).HasDatabaseName("IX_Controls_ControlCode");
 builder.HasIndex(c => c.Owner).HasDatabaseName("IX_Controls_Owner");
 builder.HasIndex(c => c.ControlType).HasDatabaseName("IX_Controls_ControlType");
 builder.HasIndex(c => c.Frequency).HasDatabaseName("IX_Controls_Frequency");

 // Relationship: Control -> ControlUnit (optional scope: branch, delegation, head office unit, company)
 builder.HasOne(c => c.ControlUnit)
 .WithMany()
 .HasForeignKey(c => c.ControlUnitId)
 .OnDelete(DeleteBehavior.SetNull)
 .HasConstraintName("FK_Controls_ControlUnit");

 // Relationship: Control -> Risk
 builder.HasOne(c => c.Risk)
 .WithMany(r => r.Controls)
 .HasForeignKey(c => c.RiskId)
 .OnDelete(DeleteBehavior.Restrict)
 .HasConstraintName("FK_Controls_Risks");

 // Relationship: Control -> TestRecords (cascade delete so test history is removed when control is deleted)
 builder.HasMany(c => c.TestRecords)
 .WithOne()
 .HasForeignKey(tr => tr.ControlId)
 .OnDelete(DeleteBehavior.Cascade)
 .HasConstraintName("FK_ControlTestRecords_Control");

 // Optional: add a compact JSON summary column (shadow) to speed up UI list rendering (populated by application)
 builder.Property<string>("SummaryJson").HasColumnType("nvarchar(max)").HasComment("Serialized UI summary for fast retrieval");
 // Map ActionType enum as string for readability
 builder.Property(c => c.ActionType).HasConversion<string>().HasMaxLength(200).HasComment("Primary action type for the control");

 // Table comment
 builder.HasComment("Controls table: governance controls and their metadata");
 }
 }
}









