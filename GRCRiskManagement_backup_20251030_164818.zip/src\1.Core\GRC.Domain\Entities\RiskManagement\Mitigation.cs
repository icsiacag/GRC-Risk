﻿using GRC.SharedKernel.Entities;

namespace GRC.Domain.Entities.RiskManagement
{
    public class Mitigation : GRC.SharedKernel.Entities.BaseEntity
    {
        public int RiskId { get; set; }
        public string Strategy { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string Owner { get; set; } = string.Empty;
        public DateTime TargetDate { get; set; }
        public string Status { get; set; } = string.Empty;
        
        // Navigation
        public virtual Risk? Risk { get; set; }
    }
}
