using System;
namespace GRC.SharedKernel
{
    public abstract class EntityBase
    {
        public int Id { get; protected set; }
        public DateTime CreatedAt { get; protected set; } = DateTime.UtcNow;
        public string CreatedBy { get; protected set; } = string.Empty;
        public DateTime? UpdatedAt { get; protected set; }
        public string? UpdatedBy { get; protected set; }

        protected EntityBase() { }

        protected EntityBase(string createdBy)
        {
            CreatedBy = createdBy ?? string.Empty;
        }

        public void UpdateAuditInfo(string updatedBy)
        {
            UpdatedAt = DateTime.UtcNow;
            UpdatedBy = updatedBy;
        }

        // Method to set CreatedBy after construction
        public void SetCreatedBy(string createdBy)
        {
            CreatedBy = createdBy ?? string.Empty;
            CreatedAt = DateTime.UtcNow;
        }
    }
}



