using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

namespace GRC.Infrastructure.Data.Jobs
{
 public class BackfillRiskLevelJob
 {
 private readonly IServiceProvider _services;
 private readonly ILogger<BackfillRiskLevelJob> _logger;

 public BackfillRiskLevelJob(IServiceProvider services, ILogger<BackfillRiskLevelJob> logger)
 {
 _services = services;
 _logger = logger;
 }

 public async Task RunAsync(int batchSize =1000)
 {
 using var scope = _services.CreateScope();
 var db = scope.ServiceProvider.GetRequiredService<Content.GRCDbContext>();
 var lookups = await db.Set<GRC.Infrastructure.Data.Entities.RiskLevelLookup>().AsNoTracking().ToListAsync();
 if (!lookups.Any())
 {
 _logger.LogWarning("No RiskLevelLookup rows found; aborting backfill");
 return;
 }

 var total = await db.Risks.CountAsync(r => r.RiskLevelId == null && !string.IsNullOrEmpty(r.RiskLevel));
 _logger.LogInformation("Backfill starting. Total candidates: {Total}", total);
 var processed =0;
 while (true)
 {
 var batch = await db.Risks.Where(r => r.RiskLevelId == null && !string.IsNullOrEmpty(r.RiskLevel)).Take(batchSize).ToListAsync();
 if (!batch.Any()) break;
 foreach (var r in batch)
 {
 var text = r.RiskLevel ?? string.Empty;
 var match = lookups.FirstOrDefault(l => !string.IsNullOrEmpty(l.Keywords) && l.Keywords.Split(',', StringSplitOptions.RemoveEmptyEntries).Any(k => text.Contains(k, StringComparison.OrdinalIgnoreCase)));
 if (match != null) r.RiskLevelId = match.Id;
 }
 await db.SaveChangesAsync();
 processed += batch.Count;
 _logger.LogInformation("Backfilled {Processed}/{Total}", processed, total);
 }
 _logger.LogInformation("Backfill completed. Processed: {Processed}", processed);
 }
 }
}
