using System.Threading.Tasks;
using GRC.Domain.Entities.Billing;

namespace GRC.Infrastructure.Identity.Services
{
 public interface IUserSubscriptionService
 {
 Task<UserSubscription?> GetActiveSubscriptionAsync(string userId);
 Task<UserSubscription> CreateSubscriptionAsync(string userId, int planId, int durationMonths);
 Task<bool> CancelSubscriptionAsync(int subscriptionId, string userId);
 }
}
