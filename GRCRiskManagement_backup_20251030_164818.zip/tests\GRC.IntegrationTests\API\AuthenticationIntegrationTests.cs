using Xunit;
using Microsoft.AspNetCore.Mvc.Testing;
using System.Net;
using System.Net.Http.Json;

namespace GRC.IntegrationTests.API;

public class AuthenticationIntegrationTests : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly WebApplicationFactory<Program> _factory;
    private readonly HttpClient _client;

    public AuthenticationIntegrationTests(WebApplicationFactory<Program> factory)
    {
        _factory = factory;
        _client = _factory.CreateClient();
    }

    [Fact]
    public async Task Login_ShouldReturnToken_ForValidCredentials()
    {
        // Login integration test
        var response = await _client.GetAsync("/api/v1/auth/test");
        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task Login_ShouldReturnUnauthorized_ForInvalidCredentials()
    {
        // Invalid login integration test
        var response = await _client.GetAsync("/api/v1/auth/test");
        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }
}


