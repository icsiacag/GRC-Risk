﻿using Microsoft.EntityFrameworkCore;
using System.Linq;
using Microsoft.AspNetCore.Identity;
using GRC.Infrastructure.Identity.Entities;

namespace GRC.Infrastructure.Identity.Services
{
    public class MfaService
    {
        private readonly UserManager<ApplicationUser> _userManager;

        public MfaService(UserManager<ApplicationUser> userManager)
        {
            this._userManager = userManager;
        }

        // MFA metodlarını buraya ekleyin
        public async Task<bool> IsMfaEnabledAsync(ApplicationUser user)
        {
            return await this._userManager.GetTwoFactorEnabledAsync(user);
        }
    }
}
