﻿using System;
using System.Collections.Generic;
using GRC.SharedKernel;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.IncidentManagement
{
    /// <summary>
    /// Incident entity for GRC system
    /// Generated on: 2025-10-30 16:18:22
    /// </summary>
    public class Incident : GRC.SharedKernel.Entities.BaseEntity
    {
        public string IncidentNumber { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public IncidentType Type { get; set; }
        public IncidentSeverity Severity { get; set; }
        public IncidentStatus Status { get; set; }
        public DateTime ReportedDate { get; set; }
        public string ReportedBy { get; set; }
        public DateTime? DetectedDate { get; set; }
        public DateTime? ResolvedDate { get; set; }
        public string AssignedTo { get; set; }
        public decimal? EstimatedImpact { get; set; }
        public List<IncidentResponse> Responses { get; set; }
        public List<RootCause> RootCauses { get; set; }
        
        // Navigation properties and domain logic can be added here
        
        /// <summary>
        /// Validates the entity state
        /// </summary>
        
        /// <summary>
        /// Domain event when entity is created
        /// </summary>
        public void OnCreated()
        {
            CreatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
        
        /// <summary>
        /// Domain event when entity is updated
        /// </summary>
        public void OnUpdated()
        {
            UpdatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
    }
}



