﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GRC.Domain.Entities.VendorRiskManagement;

using GRC.Domain.Interfaces;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Interfaces
{
    /// <summary>
    /// Repository interface for VendorAssessment
    /// </summary>
    public interface IVendorAssessmentRepository : IGenericRepository<VendorAssessment>
    {
        Task<IEnumerable<VendorAssessment>> GetActiveAsync();
        Task<VendorAssessment> GetByCodeAsync(string code);
        Task<IEnumerable<VendorAssessment>> SearchAsync(string searchTerm);
        Task<bool> ExistsAsync(Guid id);
    }
}




