﻿namespace GRC.Application.Contracts.DTOs;

public class RiskAssessmentScore
{
    public decimal Score { get; set; }
    public string Level { get; set; } = string.Empty;
    public int Likelihood { get; set; }
    public int Impact { get; set; }
}


