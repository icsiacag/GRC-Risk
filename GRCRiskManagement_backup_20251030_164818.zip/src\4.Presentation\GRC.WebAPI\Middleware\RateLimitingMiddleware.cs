using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;

namespace GRC.WebAPI.Middleware
{
    public class RateLimitingMiddleware
    {
        private readonly RequestDelegate _next;

        public RateLimitingMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            // Basit rate limiting implementasyonu
            await _next(context);
        }
    }
}


