﻿namespace GRC.SharedKernel
{
    public abstract class AuditableEntity<TId> : EntityBase
    {
        public TId Id { get; protected set; } = default!;
        public string? LastModifiedBy { get; set; }
        public DateTime? LastModifiedAt { get; set; }
    }

    public abstract class AuditableEntity : AuditableEntity<int>
    {
    }
}
