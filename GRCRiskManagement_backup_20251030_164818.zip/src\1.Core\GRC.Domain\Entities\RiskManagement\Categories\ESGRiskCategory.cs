﻿using System;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.RiskManagement.Categories
{
 public class ESGRiskCategory : RiskCategory
 {
 public bool EnvironmentalFocus { get; set; }
 public bool SocialFocus { get; set; }
 public bool GovernanceFocus { get; set; }

 public ESGRiskCategory() : base() { }
 public ESGRiskCategory(string name, string description, string color) : base(name, description, color) { }
 }
}



