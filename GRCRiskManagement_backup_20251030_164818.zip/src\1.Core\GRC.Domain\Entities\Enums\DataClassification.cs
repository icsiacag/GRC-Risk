﻿namespace GRC.Domain.Entities.Enums
{
    public enum DataClassification
    {
        Public = 1,
        Internal = 2,
        Confidential = 3,
        Restricted = 4
    }
}


