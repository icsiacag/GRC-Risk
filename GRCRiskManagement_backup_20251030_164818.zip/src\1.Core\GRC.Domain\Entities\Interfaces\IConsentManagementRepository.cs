﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GRC.Domain.Entities.DataPrivacy;

using GRC.Domain.Interfaces;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Interfaces
{
    /// <summary>
    /// Repository interface for ConsentManagement
    /// </summary>
    public interface IConsentManagementRepository : IGenericRepository<ConsentManagement>
    {
        Task<IEnumerable<ConsentManagement>> GetActiveAsync();
        Task<ConsentManagement> GetByCodeAsync(string code);
        Task<IEnumerable<ConsentManagement>> SearchAsync(string searchTerm);
        Task<bool> ExistsAsync(Guid id);
    }
}




