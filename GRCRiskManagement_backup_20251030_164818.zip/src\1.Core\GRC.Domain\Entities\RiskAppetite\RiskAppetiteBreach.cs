﻿using System;
using System.Collections.Generic;
using GRC.SharedKernel;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.RiskAppetite
{
    /// <summary>
    /// RiskAppetiteBreach entity for GRC system
    /// Generated on: 2025-10-30 16:18:22
    /// </summary>
    public class RiskAppetiteBreach : GRC.SharedKernel.Entities.BaseEntity
    {
        public Guid RiskAppetiteId { get; set; }
        public DateTime BreachDate { get; set; }
        public string BreachDescription { get; set; }
        public decimal ActualValue { get; set; }
        public decimal ThresholdValue { get; set; }
        public BreachSeverity Severity { get; set; }
        public string Response { get; set; }
        public DateTime? ResolutionDate { get; set; }
        
        // Navigation properties and domain logic can be added here
        
        /// <summary>
        /// Validates the entity state
        /// </summary>
        
        /// <summary>
        /// Domain event when entity is created
        /// </summary>
        public void OnCreated()
        {
            CreatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
        
        /// <summary>
        /// Domain event when entity is updated
        /// </summary>
        public void OnUpdated()
        {
            UpdatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
    }
}



