using System;
using System.Collections.Generic;

namespace GRC.WebAPI.DTOs
{
 public class GovernanceNodeDto
 {
 public Guid Id { get; set; }
 public string Name { get; set; } = string.Empty;
 public string Type { get; set; } = string.Empty;
 public List<GovernanceNodeDto> Children { get; set; } = new List<GovernanceNodeDto>();
 }
}
