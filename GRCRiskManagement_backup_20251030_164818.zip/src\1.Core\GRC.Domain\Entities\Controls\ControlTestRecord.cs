﻿using GRC.SharedKernel;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.Controls
{
 public class ControlTestRecord : AuditableEntity<int>
 {
 public int ControlId { get; set; }
 public string PerformedBy { get; set; } = string.Empty;
 public DateTime PerformedAt { get; set; }
 public string Result { get; set; } = string.Empty; // e.g., Passed, Failed, Partial
 public string Notes { get; set; } = string.Empty;
 public string Frequency { get; set; } = string.Empty; // e.g., Daily, Weekly, Monthly, Quarterly
 }
}



