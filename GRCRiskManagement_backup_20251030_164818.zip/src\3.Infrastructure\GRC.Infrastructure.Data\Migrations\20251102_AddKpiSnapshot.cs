using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GRC.Infrastructure.Data.Migrations
{
 public partial class AddKpiSnapshot : Migration
 {
 protected override void Up(MigrationBuilder migrationBuilder)
 {
 migrationBuilder.CreateTable(
 name: "KpiSnapshots",
 columns: table => new
 {
 Id = table.Column<int>(type: "int", nullable: false)
 .Annotation("SqlServer:Identity", "1,1"),
 SnapshotAt = table.Column<DateTime>(type: "datetime2", nullable: false),
 TotalRisks = table.Column<int>(type: "int", nullable: false),
 CriticalCount = table.Column<int>(type: "int", nullable: false),
 HighCount = table.Column<int>(type: "int", nullable: false),
 MediumCount = table.Column<int>(type: "int", nullable: false),
 LowCount = table.Column<int>(type: "int", nullable: false),
 ComplianceRate = table.Column<int>(type: "int", nullable: false),
 JsonPayload = table.Column<string>(type: "nvarchar(max)", nullable: true)
 },
 constraints: table =>
 {
 table.PrimaryKey("PK_KpiSnapshots", x => x.Id);
 });

 migrationBuilder.CreateIndex(
 name: "IX_KpiSnapshots_SnapshotAt",
 table: "KpiSnapshots",
 column: "SnapshotAt");
 }

 protected override void Down(MigrationBuilder migrationBuilder)
 {
 migrationBuilder.DropTable(
 name: "KpiSnapshots");
 }
 }
}
