﻿using System;
using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.Risk.Categories
{
 public class ProgrammaticProjectRiskCategory : GRC.Domain.Entities.RiskManagement.RiskCategory
 {
 public string? MilestoneDependencies { get; set; }
 public decimal? BudgetVariances { get; set; }
 public ProgrammaticProjectRiskCategory() : base() { }
 }
}




