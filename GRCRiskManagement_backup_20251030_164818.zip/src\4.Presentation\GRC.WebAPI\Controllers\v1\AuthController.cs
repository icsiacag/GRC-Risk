using Microsoft.AspNetCore.Mvc; // Bu sat�r� dosyan�n ba��na ekleyin

namespace GRC.WebAPI.Controllers.v1;

[ApiController]
[Route("api/v1/[controller]")]
public class AuthController : ControllerBase
{
    // ...
}

