﻿namespace GRC.Domain.Entities.Enums
{
    public enum RiskLevel
    {
        VeryLow = 1,
        Low = 2,
        Medium = 3,
        High = 4,
        VeryHigh = 5,
        Critical = 6
    }
}


