﻿using System;
using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.Risk.Categories
{
 public class ESGRiskCategory : GRC.Domain.Entities.RiskManagement.RiskCategory
 {
 public string? ESGPillars { get; set; }
 public string? SustainabilityReportingStandards { get; set; }
 public ESGRiskCategory() : base() { }
 }
}




