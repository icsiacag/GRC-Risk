﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using GRC.Infrastructure.Data.Content;
using GRC.Infrastructure.Data.Entities;

namespace GRC.Infrastructure.Data.Seeds
{
    public static class SeedDataExtensions
    {
        public static async Task SeedDataAsync(this IServiceProvider serviceProvider)
        {
            using var scope = serviceProvider.CreateScope();
            var context = scope.ServiceProvider.GetRequiredService<GRCDbContext>();
            
            // Burada seed verileri ekleyebilirsiniz
            // Örnek: await SeedUsersAsync(context);
            await context.EnsureGovernanceSeedAsync();
            await ControlUnitSeed.EnsureSeedAsync(serviceProvider);
            await context.SaveChangesAsync();
        }
        
        // Örnek seed metodu
        private static async Task SeedUsersAsync(GRCDbContext context)
        {
            // Kullanıcı seed işlemleri buraya gelecek
            await Task.CompletedTask;
        }
        
        public static async Task EnsureGovernanceSeedAsync(this GRCDbContext db)
        {
            // if any governance unit exists, do not duplicate
            var existingNames = await db.GovernanceUnits.Select(g => g.Name).ToListAsync();
            
            // create ids for main nodes
            var assemblyId = Guid.NewGuid();
            var boardId = Guid.NewGuid();
            var committeeId = Guid.NewGuid();
            
            var nodes = new List<GovernanceUnit>();
            
            void AddIfMissing(GovernanceUnit u)
            {
                if (existingNames.Contains(u.Name)) return;
                nodes.Add(u);
            }
            
            // root and top-level
            AddIfMissing(new GovernanceUnit { Id = assemblyId, Name = "Türk Kızılay Genel Kurulu", Type = "assembly", SortOrder =1, ParentId = null });
            AddIfMissing(new GovernanceUnit { Id = boardId, Name = "Yönetim Kurulu ve Genel Başkanlık", Type = "board", SortOrder =2, ParentId = assemblyId });
            AddIfMissing(new GovernanceUnit { Id = committeeId, Name = "Denetim Kurulu", Type = "committee", SortOrder =3, ParentId = assemblyId });
            
            // General management and central offices
            var genelMudurId = Guid.NewGuid();
            AddIfMissing(new GovernanceUnit { Id = genelMudurId, Name = "Türk Kızılay Genel Müdürlüğü", Type = "management", SortOrder =4, ParentId = boardId });
            
            // departments under Genel Müdürlük (examples matching image)
            var destekId = Guid.NewGuid(); AddIfMissing(new GovernanceUnit { Id = destekId, Name = "Destek Hizmetleri Genel Müdürlüğü", Type = "department", SortOrder =10, ParentId = genelMudurId });
            var afetId = Guid.NewGuid(); AddIfMissing(new GovernanceUnit { Id = afetId, Name = "Afet Yönetimi ve İklim Değişikliği Genel Müdürlüğü", Type = "department", SortOrder =11, ParentId = genelMudurId });
            var toplumsalId = Guid.NewGuid(); AddIfMissing(new GovernanceUnit { Id = toplumsalId, Name = "Toplumsal Hizmetler Genel Müdürlüğü", Type = "department", SortOrder =12, ParentId = genelMudurId });
            var finansId = Guid.NewGuid(); AddIfMissing(new GovernanceUnit { Id = finansId, Name = "Finans ve Mali İşler Genel Müdürlüğü", Type = "department", SortOrder =13, ParentId = genelMudurId });
            var iletisimId = Guid.NewGuid(); AddIfMissing(new GovernanceUnit { Id = iletisimId, Name = "İletişim ve Bağış Yönetimi Genel Müdürlüğü", Type = "department", SortOrder =14, ParentId = genelMudurId });
            var uluslarId = Guid.NewGuid(); AddIfMissing(new GovernanceUnit { Id = uluslarId, Name = "Uluslararası İşler ve Göç Hizmetleri Genel Müdürlüğü", Type = "department", SortOrder =15, ParentId = genelMudurId });
            var kanId = Guid.NewGuid(); AddIfMissing(new GovernanceUnit { Id = kanId, Name = "Kan Hizmetleri Genel Müdürlüğü", Type = "department", SortOrder =16, ParentId = genelMudurId });
            var yonetimOfisiId = Guid.NewGuid(); AddIfMissing(new GovernanceUnit { Id = yonetimOfisiId, Name = "Yönetişim Ofisi Genel Müdürlüğü", Type = "department", SortOrder =17, ParentId = genelMudurId });
            var tasinmazId = Guid.NewGuid(); AddIfMissing(new GovernanceUnit { Id = tasinmazId, Name = "Taşınmaz Yönetimi Genel Müdürlüğü", Type = "department", SortOrder =18, ParentId = genelMudurId });
            
            // add typical sub-units (as seen on the image): under Afet Yönetimi
            AddIfMissing(new GovernanceUnit { Id = Guid.NewGuid(), Name = "Afet Müdahale Birimi", Type = "unit", SortOrder =21, ParentId = afetId });
            AddIfMissing(new GovernanceUnit { Id = Guid.NewGuid(), Name = "İklim Değişikliği ve Risk Yönetimi Birimi", Type = "unit", SortOrder =22, ParentId = afetId });
            AddIfMissing(new GovernanceUnit { Id = Guid.NewGuid(), Name = "Lojistik ve Tedarik Birimi", Type = "unit", SortOrder =23, ParentId = destekId });
            AddIfMissing(new GovernanceUnit { Id = Guid.NewGuid(), Name = "İnsan Kaynakları Birimi", Type = "unit", SortOrder =24, ParentId = destekId });
            
            // Toplumsal hizmetler sub-units
            AddIfMissing(new GovernanceUnit { Id = Guid.NewGuid(), Name = "Sosyal Yardım Birimi", Type = "unit", SortOrder =31, ParentId = toplumsalId });
            AddIfMissing(new GovernanceUnit { Id = Guid.NewGuid(), Name = "Kadın ve Çocuk Destek Birimi", Type = "unit", SortOrder =32, ParentId = toplumsalId });
            
            // Finans sub-units
            AddIfMissing(new GovernanceUnit { Id = Guid.NewGuid(), Name = "Muhasebe ve Raporlama Birimi", Type = "unit", SortOrder =41, ParentId = finansId });
            AddIfMissing(new GovernanceUnit { Id = Guid.NewGuid(), Name = "Bütçe ve Planlama Birimi", Type = "unit", SortOrder =42, ParentId = finansId });
            
            // İletişim sub-units
            AddIfMissing(new GovernanceUnit { Id = Guid.NewGuid(), Name = "Bağış Kampanyaları ve İletişim Birimi", Type = "unit", SortOrder =51, ParentId = iletisimId });
            AddIfMissing(new GovernanceUnit { Id = Guid.NewGuid(), Name = "Kurumsal İletişim Birimi", Type = "unit", SortOrder =52, ParentId = iletisimId });
            
            // Kan Hizmetleri sub-units
            AddIfMissing(new GovernanceUnit { Id = Guid.NewGuid(), Name = "Kan Bağışı Organizasyon Birimi", Type = "unit", SortOrder =61, ParentId = kanId });
            AddIfMissing(new GovernanceUnit { Id = Guid.NewGuid(), Name = "Bölge Kan Merkezleri Koordinasyon Birimi", Type = "unit", SortOrder =62, ParentId = kanId });
            
            // Taşınmaz sub-units
            AddIfMissing(new GovernanceUnit { Id = Guid.NewGuid(), Name = "Emlak Yönetimi Birimi", Type = "unit", SortOrder =71, ParentId = tasinmazId });
            
            // Governance office sub-units
            AddIfMissing(new GovernanceUnit { Id = Guid.NewGuid(), Name = "Hukuk Müşavirliği", Type = "unit", SortOrder =81, ParentId = yonetimOfisiId });
            AddIfMissing(new GovernanceUnit { Id = Guid.NewGuid(), Name = "İç Denetim ve Uyum Birimi", Type = "unit", SortOrder =82, ParentId = yonetimOfisiId });
            
            if (nodes.Any())
            {
                await db.GovernanceUnits.AddRangeAsync(nodes);
                await db.SaveChangesAsync();
            }
        }
    }
}


