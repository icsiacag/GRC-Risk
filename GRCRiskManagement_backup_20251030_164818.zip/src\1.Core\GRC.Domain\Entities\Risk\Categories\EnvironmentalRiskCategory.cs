﻿using System;
using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.Risk.Categories
{
 public class EnvironmentalRiskCategory : GRC.Domain.Entities.RiskManagement.RiskCategory
 {
 public string? EnvironmentalFocus { get; set; }
 public EnvironmentalRiskCategory() : base() { }
 }
}




