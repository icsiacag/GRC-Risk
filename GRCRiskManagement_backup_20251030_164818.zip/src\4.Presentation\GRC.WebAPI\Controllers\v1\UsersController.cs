using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using GRC.Infrastructure.Identity.Services;

namespace GRC.WebAPI.Controllers.v1
{
 [ApiController]
 [Route("api/v1/users")]
 public class UsersController : ControllerBase
 {
 private readonly UserManager<IdentityUser> _userManager;
 private readonly IUserSubscriptionService _subscriptionService;

 public UsersController(UserManager<IdentityUser> userManager, IUserSubscriptionService subscriptionService)
 {
 _userManager = userManager;
 _subscriptionService = subscriptionService;
 }

 [HttpGet("me")]
 [Authorize]
 public async Task<IActionResult> Me()
 {
 var user = await _userManager.GetUserAsync(User);
 if (user == null)
 return Unauthorized();

 var roles = await _userManager.GetRolesAsync(user);
 var fullName = user.UserName ?? string.Empty;
 var nameClaim = User?.FindFirst(System.Security.Claims.ClaimTypes.Name)?.Value;
 if (!string.IsNullOrEmpty(nameClaim)) fullName = nameClaim;

 var sub = await _subscriptionService.GetActiveSubscriptionAsync(user.Id);

 return Ok(new { id = user.Id, email = user.Email, fullName, roles, subscription = sub });
 }
 }
}
