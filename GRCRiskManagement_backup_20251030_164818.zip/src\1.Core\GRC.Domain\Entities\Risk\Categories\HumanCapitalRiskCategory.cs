﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using GRC.Domain.Entities.RiskManagement;
using GRC.Domain.Common;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.Risk.Categories
{
 /// <summary>
 /// Human capital risks: talent, retention and workforce issues
 /// </summary>
 public class HumanCapitalRiskCategory : GRC.Domain.Entities.RiskManagement.RiskCategory
 {
 public double? TalentRetentionMetrics { get; set; }
 public string? DiversityIndices { get; set; } // JSON

 // LinkedProcesses type fallback to object if Process class not available
 public List<object> LinkedProcesses { get; set; } = new();

 public HumanCapitalRiskCategory() : base() { }

 );
 }

 

 public override async Task<List<string>> GetAIRecommendationsAsync()
 {
 var rec = new List<string>();
 var divers = DeserializeDiversity();
 if (divers.Count ==0) rec.Add("No diversity indices found — consider survey.");
 rec.Add("Consider targeted retention programs for critical roles.");
 return await Task.FromResult(rec);
 }

 private Dictionary<string, double> DeserializeDiversity()
 {
 if (string.IsNullOrWhiteSpace(DiversityIndices)) return new();
 try
 {
 return JsonSerializer.Deserialize<Dictionary<string, double>>(DiversityIndices) ?? new();
 }
 catch { return new(); }
 }

 private string DetermineLevel(decimal score)
 {
 return score switch
 {
 <3 => "Low",
 <6 => "Medium",
 <9 => "High",
 _ => "Critical"
 };
 }

 public override RiskCategoryOutput ExportData()
 {
 var o = base.ExportData();
 o.Metrics["TalentRetention"] = TalentRetentionMetrics ??0.0;
 o.Metrics["DiversityCount"] = DeserializeDiversity().Count;
 return o;
 }
 }
}





