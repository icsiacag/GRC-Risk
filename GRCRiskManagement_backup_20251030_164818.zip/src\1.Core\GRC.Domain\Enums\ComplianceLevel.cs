﻿namespace GRC.Domain.Enums
{
    public enum ComplianceLevel
    {
        NonCompliant = 0,
        PartiallyCompliant = 1,
        SubstantiallyCompliant = 2,
        FullyCompliant = 3
    }
}
