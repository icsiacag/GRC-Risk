﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GRC.Domain.Entities.ChangeManagement;

using GRC.Domain.Interfaces;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Interfaces
{
    /// <summary>
    /// Repository interface for ChangeImpact
    /// </summary>
    public interface IChangeImpactRepository : IGenericRepository<ChangeImpact>
    {
        Task<IEnumerable<ChangeImpact>> GetActiveAsync();
        Task<ChangeImpact> GetByCodeAsync(string code);
        Task<IEnumerable<ChangeImpact>> SearchAsync(string searchTerm);
        Task<bool> ExistsAsync(Guid id);
    }
}




