﻿using System;
using System.Collections.Generic;
using GRC.SharedKernel;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.PolicyManagement
{
    /// <summary>
    /// PolicyApproval entity for GRC system
    /// Generated on: 2025-10-30 16:18:22
    /// </summary>
    public class PolicyApproval : GRC.SharedKernel.Entities.BaseEntity
    {
        public Guid PolicyId { get; set; }
        public string ApproverName { get; set; }
        public string ApproverRole { get; set; }
        public ApprovalStatus Status { get; set; }
        public DateTime? ApprovalDate { get; set; }
        public string Comments { get; set; }
        
        // Navigation properties and domain logic can be added here
        
        /// <summary>
        /// Validates the entity state
        /// </summary>
        
        /// <summary>
        /// Domain event when entity is created
        /// </summary>
        public void OnCreated()
        {
            CreatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
        
        /// <summary>
        /// Domain event when entity is updated
        /// </summary>
        public void OnUpdated()
        {
            UpdatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
    }
}



