﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GRC.Domain.Entities.DataPrivacy;

using GRC.Domain.Interfaces;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Interfaces
{
    /// <summary>
    /// Repository interface for PrivacyImpactAssessment
    /// </summary>
    public interface IPrivacyImpactAssessmentRepository : IGenericRepository<PrivacyImpactAssessment>
    {
        Task<IEnumerable<PrivacyImpactAssessment>> GetActiveAsync();
        Task<PrivacyImpactAssessment> GetByCodeAsync(string code);
        Task<IEnumerable<PrivacyImpactAssessment>> SearchAsync(string searchTerm);
        Task<bool> ExistsAsync(Guid id);
    }
}




