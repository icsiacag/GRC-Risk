﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GRC.Domain.Entities.KRI_KPI;

using GRC.Domain.Interfaces;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Interfaces
{
    /// <summary>
    /// Repository interface for KPIMeasurement
    /// </summary>
    public interface IKPIMeasurementRepository : IGenericRepository<KPIMeasurement>
    {
        Task<IEnumerable<KPIMeasurement>> GetActiveAsync();
        Task<KPIMeasurement> GetByCodeAsync(string code);
        Task<IEnumerable<KPIMeasurement>> SearchAsync(string searchTerm);
        Task<bool> ExistsAsync(Guid id);
    }
}




