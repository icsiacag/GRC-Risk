﻿namespace GRC.Application.Contracts.DTOs.Risks
{
    public class RiskListItemDto
    {
        public int Id { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string RiskLevel { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty;
        public string Owner { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
        public string CategoryType { get; set; } = string.Empty;
        public string? CategoryMetadataJson { get; set; }
    }
}

