﻿namespace GRC.Domain.Entities.Enums
{
    public enum ChangeStatus
    {
        Submitted = 1,
        UnderReview = 2,
        Approved = 3,
        InProgress = 4,
        Completed = 5,
        Rejected = 6
    }
}


