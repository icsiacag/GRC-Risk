using Microsoft.Extensions.DependencyInjection;
using System;

namespace GRC.Infrastructure.Data
{
 public static class DependencyInjection
 {
 public static IServiceCollection AddInfrastructureData(this IServiceCollection services)
 {
 // existing registrations
 // ...

 // register backfill job
 services.AddScoped<GRC.Infrastructure.Data.Jobs.BackfillRiskLevelJob>();
 // register snapshot repo
 services.AddScoped<GRC.Infrastructure.Data.Repositories.KpiSnapshotRepository>();
 // register snapshot worker
 services.AddHostedService<GRC.Infrastructure.Data.Workers.KpiSnapshotWorker>();
 // register repositories
 services.AddScoped<GRC.Infrastructure.Data.Repositories.RiskCategoryRepository>();
 services.AddScoped<GRC.Infrastructure.Data.Repositories.IRiskCategoryRepository, GRC.Infrastructure.Data.Repositories.RiskCategoryRepository>();

 return services;
 }
 }
}
