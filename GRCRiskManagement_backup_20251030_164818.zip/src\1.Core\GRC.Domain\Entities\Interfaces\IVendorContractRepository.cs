﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GRC.Domain.Entities.VendorRiskManagement;

using GRC.Domain.Interfaces;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Interfaces
{
    /// <summary>
    /// Repository interface for VendorContract
    /// </summary>
    public interface IVendorContractRepository : IGenericRepository<VendorContract>
    {
        Task<IEnumerable<VendorContract>> GetActiveAsync();
        Task<VendorContract> GetByCodeAsync(string code);
        Task<IEnumerable<VendorContract>> SearchAsync(string searchTerm);
        Task<bool> ExistsAsync(Guid id);
    }
}




