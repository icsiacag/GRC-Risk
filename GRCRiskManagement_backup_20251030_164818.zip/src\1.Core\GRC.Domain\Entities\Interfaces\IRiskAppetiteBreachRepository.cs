﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GRC.Domain.Entities.RiskAppetite;

using GRC.Domain.Interfaces;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Interfaces
{
    /// <summary>
    /// Repository interface for RiskAppetiteBreach
    /// </summary>
    public interface IRiskAppetiteBreachRepository : IGenericRepository<RiskAppetiteBreach>
    {
        Task<IEnumerable<RiskAppetiteBreach>> GetActiveAsync();
        Task<RiskAppetiteBreach> GetByCodeAsync(string code);
        Task<IEnumerable<RiskAppetiteBreach>> SearchAsync(string searchTerm);
        Task<bool> ExistsAsync(Guid id);
    }
}




