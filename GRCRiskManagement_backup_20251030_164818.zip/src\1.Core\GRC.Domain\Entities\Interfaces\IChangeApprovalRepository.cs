﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GRC.Domain.Entities.ChangeManagement;

using GRC.Domain.Interfaces;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Interfaces
{
    /// <summary>
    /// Repository interface for ChangeApproval
    /// </summary>
    public interface IChangeApprovalRepository : IGenericRepository<ChangeApproval>
    {
        Task<IEnumerable<ChangeApproval>> GetActiveAsync();
        Task<ChangeApproval> GetByCodeAsync(string code);
        Task<IEnumerable<ChangeApproval>> SearchAsync(string searchTerm);
        Task<bool> ExistsAsync(Guid id);
    }
}




