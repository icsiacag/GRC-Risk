using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;

namespace GRC.WebAPI.Controllers.v1
{
 [ApiController]
 [Route("api/v1/scenarios")]
 public class ScenarioController : ControllerBase
 {
 private static readonly List<ScenarioDto> Scenarios = new List<ScenarioDto>
 {
 new ScenarioDto{ Id = Guid.NewGuid(), Name = "Ransomware Attack", CreatedAt = DateTime.UtcNow, Description = "Simulate ransomware impact against critical services" }
 };

 [HttpGet]
 public ActionResult<IEnumerable<ScenarioDto>> GetAll() => Ok(Scenarios);

 [HttpGet("{id}")]
 public ActionResult<ScenarioDto> Get(Guid id)
 {
 var s = Scenarios.Find(x => x.Id == id);
 if (s == null) return NotFound();
 return Ok(s);
 }

 [HttpPost]
 public ActionResult<ScenarioDto> Create([FromBody] ScenarioCreateDto dto)
 {
 var s = new ScenarioDto{ Id = Guid.NewGuid(), Name = dto.Name, Description = dto.Description, CreatedAt = DateTime.UtcNow };
 Scenarios.Add(s);
 return CreatedAtAction(nameof(Get), new { id = s.Id }, s);
 }

 [HttpPost("{id}/run")]
 public IActionResult Run(Guid id)
 {
 // Start a simulation run (placeholder)
 var s = Scenarios.Find(x=>x.Id==id); if(s==null) return NotFound();
 return Accepted(new { runId = Guid.NewGuid(), status = "started" });
 }

 public class ScenarioDto { public Guid Id { get; set; } public string Name { get; set; } public string Description { get; set; } public DateTime CreatedAt { get; set; } }
 public class ScenarioCreateDto { public string Name { get; set; } public string Description { get; set; } }
 }
}
