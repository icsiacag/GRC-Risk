﻿using GRC.SharedKernel;
using GRC.SharedKernel.Interfaces;
using GRC.Domain.Entities.Controls;
using System.Collections.Generic;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.RiskManagement
{
    public class Risk : AuditableEntity<int>, GRC.SharedKernel.Interfaces.IAggregateRoot
    {
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public int CategoryId { get; set; }
        public string Likelihood { get; set; } = string.Empty;
        public string Impact { get; set; } = string.Empty;
        public string RiskLevel { get; set; } = string.Empty;
        // Normalized risk level reference (nullable until backfill completes)
        public int? RiskLevelId { get; set; }
        public string Treatment { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty;
        public DateTime IdentifiedDate { get; set; }
        public DateTime? TreatmentDueDate { get; set; }
        public string Owner { get; set; } = string.Empty;

        // Navigation properties
        public RiskCategory? Category { get; set; }
        public ICollection<Control> Controls { get; set; } = new List<Control>();
    }
}





