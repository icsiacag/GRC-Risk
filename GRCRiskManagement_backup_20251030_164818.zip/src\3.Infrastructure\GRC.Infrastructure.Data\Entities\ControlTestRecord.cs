using System;

namespace GRC.Infrastructure.Data.Entities
{
 public class ControlTestRecord
 {
 public int Id { get; set; }
 public int ControlId { get; set; }
 public string PerformedBy { get; set; } = string.Empty;
 public DateTime PerformedAt { get; set; }
 public string Result { get; set; } = string.Empty;
 public string Notes { get; set; } = string.Empty;
 public string Frequency { get; set; } = string.Empty;
 }
}
