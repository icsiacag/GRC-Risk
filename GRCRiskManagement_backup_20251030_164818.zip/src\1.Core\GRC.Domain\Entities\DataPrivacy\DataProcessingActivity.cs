﻿using System;
using System.Collections.Generic;
using GRC.SharedKernel;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.DataPrivacy
{
    /// <summary>
    /// DataProcessingActivity entity for GRC system
    /// Generated on: 2025-10-30 16:18:22
    /// </summary>
    public class DataProcessingActivity : GRC.SharedKernel.Entities.BaseEntity
    {
        public Guid DataAssetId { get; set; }
        public string ActivityName { get; set; }
        public ProcessingPurpose Purpose { get; set; }
        public LegalBasis LegalBasis { get; set; }
        public string DataSubjects { get; set; }
        public string DataCategories { get; set; }
        public string Recipients { get; set; }
        public bool InvolvesTransfer { get; set; }
        public string TransferMechanism { get; set; }
        
        // Navigation properties and domain logic can be added here
        
        /// <summary>
        /// Validates the entity state
        /// </summary>
        
        /// <summary>
        /// Domain event when entity is created
        /// </summary>
        public void OnCreated()
        {
            CreatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
        
        /// <summary>
        /// Domain event when entity is updated
        /// </summary>
        public void OnUpdated()
        {
            UpdatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
    }
}



