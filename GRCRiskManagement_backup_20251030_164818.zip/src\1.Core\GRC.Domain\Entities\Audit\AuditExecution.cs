﻿using GRC.SharedKernel;
using GRC.Domain.Common;
using System;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.Audit
{
    public class AuditExecution : AuditableEntity<int>
    {
        public int AuditPlanId { get; set; }
        public DateTime ExecutionDate { get; set; }
        public string Findings { get; set; }
        public string Recommendations { get; set; }
        public string Status { get; set; }
        public string Auditor { get; set; }
        public decimal Score { get; set; }
    }
}






