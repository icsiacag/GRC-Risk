﻿namespace GRC.Domain.Entities.Enums
{
    public enum ToleranceType
    {
        Quantitative = 1,
        Qualitative = 2,
        Hybrid = 3
    }
}


