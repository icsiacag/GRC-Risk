﻿using GRC.SharedKernel.Entities;

namespace GRC.Domain.Entities.RiskManagement
{
    public abstract class RiskCategory : AuditableEntity<int>
    {
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string Code { get; set; } = string.Empty;
        public bool IsActive { get; set; } = true;
        public int DisplayOrder { get; set; }
        
        // Category-specific properties (can be overridden by derived classes)
        public virtual string? ESGPillars { get; set; }
        public virtual string? SustainabilityReportingStandards { get; set; }
        public virtual string? CurrencyExposures { get; set; }
        public virtual Dictionary<string, decimal>? CountryRiskScores { get; set; }
        public virtual List<string>? TradeBarrierFlags { get; set; }
        public virtual List<string>? TalentRetentionMetrics { get; set; }
        public virtual Dictionary<string, double>? DiversityIndices { get; set; }
        public virtual List<string>? PatentExposures { get; set; }
        public virtual Dictionary<string, int>? TechAdoptionRisks { get; set; }
        public virtual List<string>? JurisdictionLaws { get; set; }
        public virtual Dictionary<string, decimal>? PenaltyEstimates { get; set; }
        public virtual List<string>? MilestoneDependencies { get; set; }
        public virtual Dictionary<string, decimal>? BudgetVariances { get; set; }
        public virtual Dictionary<string, string>? AssetProtectionLevels { get; set; }
        public virtual List<string>? ThreatVectors { get; set; }
        public virtual List<string>? SupplierDependencies { get; set; }
        public virtual Dictionary<string, string>? DisruptionScenarios { get; set; }
        public virtual List<string>? TechStackVulnerabilities { get; set; }
        public virtual Dictionary<string, double>? InnovationAdoptionRate { get; set; }
        
        // Navigation properties
        public virtual ICollection<Risk> Risks { get; set; } = new List<Risk>();
        
        // Abstract methods that each category SHOULD implement
        // Made virtual with default implementation to avoid forcing all categories
        public virtual Task<decimal> CalculateRiskScoreAsync(Risk risk)
        {
            // Default implementation
            return Task.FromResult(0m);
        }
        
        public virtual Task<bool> ValidateCategoryRiskAsync(Risk risk)
        {
            // Default implementation
            return Task.FromResult(true);
        }
        
        public virtual Task<string> GetAIRecommendationsAsync()
        {
            // Default implementation
            return Task.FromResult("No AI recommendations available.");
        }
        
        public virtual string ExportData()
        {
            // Default implementation
            return $"Category: {Name}, Code: {Code}";
        }
        
        // Common validation logic
        public virtual bool IsValidForCategory(Risk risk)
        {
            return risk != null && risk.CategoryId == this.Id;
        }
    }
}
