﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GRC.Domain.Entities.KRI_KPI;

using GRC.Domain.Interfaces;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Interfaces
{
    /// <summary>
    /// Repository interface for KRIMeasurement
    /// </summary>
    public interface IKRIMeasurementRepository : IGenericRepository<KRIMeasurement>
    {
        Task<IEnumerable<KRIMeasurement>> GetActiveAsync();
        Task<KRIMeasurement> GetByCodeAsync(string code);
        Task<IEnumerable<KRIMeasurement>> SearchAsync(string searchTerm);
        Task<bool> ExistsAsync(Guid id);
    }
}




