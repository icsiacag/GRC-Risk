﻿using System;
using System.Collections.Generic;
using GRC.SharedKernel;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.DataPrivacy
{
    /// <summary>
    /// DataAsset entity for GRC system
    /// Generated on: 2025-10-30 16:18:22
    /// </summary>
    public class DataAsset : GRC.SharedKernel.Entities.BaseEntity
    {
        public string AssetName { get; set; }
        public string Description { get; set; }
        public DataClassification Classification { get; set; }
        public string Owner { get; set; }
        public string Location { get; set; }
        public DataType Type { get; set; }
        public bool ContainsPII { get; set; }
        public bool ContainsSensitiveData { get; set; }
        public string ProcessingPurpose { get; set; }
        public RetentionPeriod RetentionPeriod { get; set; }
        public List<DataProcessingActivity> ProcessingActivities { get; set; }
        
        // Navigation properties and domain logic can be added here
        
        /// <summary>
        /// Validates the entity state
        /// </summary>
        
        /// <summary>
        /// Domain event when entity is created
        /// </summary>
        public void OnCreated()
        {
            CreatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
        
        /// <summary>
        /// Domain event when entity is updated
        /// </summary>
        public void OnUpdated()
        {
            UpdatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
    }
}



