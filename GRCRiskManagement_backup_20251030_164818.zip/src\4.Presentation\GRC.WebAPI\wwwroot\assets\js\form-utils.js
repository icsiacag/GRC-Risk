// Reusable client-side form utilities for validation and submission
window.GRC = window.GRC || {};
GRC.validateForm = function(form) {
 var valid = true;
 var elements = Array.from(form.querySelectorAll('[data-required]'));
 elements.forEach(function(el){
 var val = (el.value || '').toString().trim();
 var container = el.closest('.form-field') || el.parentElement;
 var err = container.querySelector('.field-error');
 if(!err){ err = document.createElement('div'); err.className='field-error'; err.style.color='#d32f2f'; err.style.fontSize='12px'; err.style.marginTop='6px'; container.appendChild(err); }
 if(!val){ err.textContent = el.getAttribute('data-required-msg') || 'This field is required'; valid = false; }
 else { err.textContent = ''; }
 });
 return valid;
};

GRC.postJson = async function(url, payload){
 const resp = await fetch(url, { method: 'POST', credentials: 'same-origin', headers: {'Content-Type':'application/json'}, body: JSON.stringify(payload) });
 return resp;
};

GRC.showToast = function(message, type){
 var container = document.getElementById('grcToastContainer'); if(!container){ container = document.createElement('div'); container.id='grcToastContainer'; container.className='grc-toast-container'; document.body.appendChild(container); }
 var card = document.createElement('div'); card.className='grc-toast'; card.style.borderLeft = '4px solid '+(type==='error'? '#d32f2f' : '#1a237e');
 var p = document.createElement('p'); p.textContent = message; card.appendChild(p); container.appendChild(card);
 setTimeout(function(){ card.style.opacity='0'; setTimeout(()=>card.remove(),400); },5000);
};

GRC.fetchJson = async function(url, opts){
 opts = opts || {};
 opts.credentials = opts.credentials || 'same-origin';
 opts.headers = opts.headers || {};
 opts.headers['Content-Type'] = opts.headers['Content-Type'] || 'application/json';
 const r = await fetch(url, opts);
 if(!r.ok) throw new Error('Request failed');
 return await r.json();
};

GRC.getCategories = async function(){
 return await GRC.fetchJson('/api/v1/categories');
};

// Utility: escape HTML
GRC.escapeHtml = function(s){
 if (s == null) return '';
 return String(s).replace(/[&<>"]/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]||c; });
};

// Renderer registry for custom structured renderers per key
GRC.structuredRenderers = {};
GRC.registerStructuredRenderer = function(key, fn){
 GRC.structuredRenderers[key.toLowerCase()] = fn;
};

// Template renderer registry for richer templating helpers
GRC.templateRenderers = {};
GRC.registerTemplate = function(key, fn){
 // fn(container, data) should render into container (DOM node) or return an HTML string/node
 GRC.templateRenderers[key.toLowerCase()] = fn;
};

GRC.renderTemplate = function(container, key, data){
 container = (typeof container === 'string') ? document.querySelector(container) : container;
 if(!container) return;
 container.innerHTML = '';
 var k = (key||'').toLowerCase();
 var t = GRC.templateRenderers[k];
 if (!t){ return null; }
 try{
 var result = t(container, data);
 if (typeof result === 'string') { container.innerHTML = result; }
 else if (result instanceof Node) { container.appendChild(result); }
 // if fn already mutated container, nothing more to do
 }catch(e){ console.warn('Template renderer error for key', key, e); }
};

// Render structured JS value (object/array) into DOM node inside container
// keyName (optional) allows renderer selection
GRC.renderStructuredValue = function(container, value, keyName){
 container = (typeof container === 'string') ? document.querySelector(container) : container;
 if(!container) return;
 container.innerHTML = '';

 // first try template renderer by keyName
 if (keyName && GRC.templateRenderers[keyName.toLowerCase()]){
 try{ GRC.renderTemplate(container, keyName, value); return; }catch(e){ console.warn('Template render failed', e); }
 }

 function defaultRender(v){
 if (v === null || v === undefined) { var span = document.createElement('span'); span.className='text-muted'; span.textContent = '�'; return span; }
 if (Array.isArray(v)){
 var ul = document.createElement('ul'); ul.style.paddingLeft='18px';
 v.forEach(function(item){ var li = document.createElement('li'); var child = defaultRender(item); li.appendChild(child); ul.appendChild(li); });
 return ul;
 }
 if (typeof v === 'object'){
 var table = document.createElement('table'); table.className='structured-table'; table.style.width='100%'; table.style.borderCollapse='collapse';
 Object.keys(v).forEach(function(k){ var tr = document.createElement('tr'); var tdk = document.createElement('td'); tdk.style.width='30%'; tdk.style.verticalAlign='top'; tdk.style.padding='6px'; tdk.style.fontWeight='600'; tdk.textContent = k; var tdv = document.createElement('td'); tdv.style.padding='6px'; var child = defaultRender(v[k]); tdv.appendChild(child); tr.appendChild(tdk); tr.appendChild(tdv); table.appendChild(tr); });
 return table;
 }
 var span = document.createElement('span'); span.textContent = String(v); return span;
 }

 // If specific structured renderer registered for keyName, use it
 if (keyName && GRC.structuredRenderers[keyName.toLowerCase()]){
 try{ GRC.structuredRenderers[keyName.toLowerCase()](container, value); return; }catch(e){ console.warn('Structured renderer failed for', keyName, e); }
 }

 // If value is object, try per-property template/renderers
 if (value && typeof value === 'object' && !Array.isArray(value)){
 var wrapper = document.createElement('div');
 Object.keys(value).forEach(function(k){ var section = document.createElement('div'); var title = document.createElement('div'); title.style.fontWeight='700'; title.style.marginTop='8px'; title.textContent = k; section.appendChild(title);
 var v = value[k]; // try template first for this property
 if (GRC.templateRenderers[k.toLowerCase()]){
 try{ GRC.renderTemplate(section, k, v); }
 catch(e){ section.appendChild(defaultRender(v)); }
 }
 else if (GRC.structuredRenderers[k.toLowerCase()]){
 try{ GRC.structuredRenderers[k.toLowerCase()](section, v); }
 catch(e){ section.appendChild(defaultRender(v)); }
 }
 else { section.appendChild(defaultRender(v)); }
 wrapper.appendChild(section);
 });
 container.appendChild(wrapper); return;
 }

 // fallback to default
 container.appendChild(defaultRender(value));
};

// Validation helpers for templates
GRC.validateMilestones = function(arr){
 if(!Array.isArray(arr)) return false;
 for(let i=0;i<arr.length;i++){
 const m = arr[i];
 if(!m) return false;
 if(!m.name || !m.plannedDate) return false;
 }
 return true;
};

GRC.validateSuppliers = function(arr){
 if(!Array.isArray(arr)) return false;
 for(let i=0;i<arr.length;i++){
 const s = arr[i];
 if(!s) return false;
 if(!s.name) return false;
 }
 return true;
};

// Add edit-capable templates: milestones and suppliers
GRC.registerTemplate('milestonedependencies', function(container, value){
 container = (typeof container === 'string') ? document.querySelector(container) : container;
 if(!container) return;
 container.innerHTML = '';
 const rows = Array.isArray(value) ? value : (value ? [value] : []);
 const table = document.createElement('table'); table.style.width='100%'; table.style.borderCollapse='collapse'; table.className='editable-table';
 const header = document.createElement('tr'); ['Name','Planned Date','Actual Date','Is Critical','Actions'].forEach(h=>{ const th=document.createElement('th'); th.style.textAlign='left'; th.style.padding='6px'; th.textContent=h; header.appendChild(th); }); table.appendChild(header);
 function renderRows(){
 // clear data rows
 Array.from(table.querySelectorAll('.data-row')).forEach(n=>n.remove());
 rows.forEach((m, idx)=>{
 const tr = document.createElement('tr'); tr.className='data-row';
 function td(el){ const c=document.createElement('td'); c.style.padding='6px'; c.appendChild(el); return c; }
 const nameInp = document.createElement('input'); nameInp.type='text'; nameInp.value = m.name || m.Name || '';
 nameInp.addEventListener('input', ()=>{ rows[idx].name = nameInp.value; });
 const plannedInp = document.createElement('input'); plannedInp.type='date'; plannedInp.value = m.plannedDate ? (new Date(m.plannedDate)).toISOString().slice(0,10) : '';
 plannedInp.addEventListener('change', ()=>{ rows[idx].plannedDate = plannedInp.value; });
 const actualInp = document.createElement('input'); actualInp.type='date'; actualInp.value = m.actualDate ? (new Date(m.actualDate)).toISOString().slice(0,10) : '';
 actualInp.addEventListener('change', ()=>{ rows[idx].actualDate = actualInp.value; });
 const criticalChk = document.createElement('input'); criticalChk.type='checkbox'; criticalChk.checked = m.isCritical || m.IsCritical || false;
 criticalChk.addEventListener('change', ()=>{ rows[idx].isCritical = criticalChk.checked; });
 const delBtn = document.createElement('button'); delBtn.type='button'; delBtn.className='mini-btn'; delBtn.textContent='Remove'; delBtn.addEventListener('click', ()=>{ rows.splice(idx,1); renderRows(); });
 tr.appendChild(td(nameInp)); tr.appendChild(td(plannedInp)); tr.appendChild(td(actualInp)); tr.appendChild(td(criticalChk)); tr.appendChild(td(delBtn)); table.appendChild(tr);
 });
 }
 renderRows();
 const addRow = document.createElement('button'); addRow.type='button'; addRow.className='mini-btn'; addRow.textContent='Add Milestone'; addRow.addEventListener('click', ()=>{ rows.push({ name:'', plannedDate:'', actualDate:null, isCritical:false }); renderRows(); });
 container.appendChild(table); container.appendChild(addRow);
 // expose rows reference on container for external serialization
 container._rows = rows;
});

GRC.registerTemplate('supplierdependencies', function(container, value){
 container = (typeof container === 'string') ? document.querySelector(container) : container;
 if(!container) return;
 container.innerHTML = '';
 const rows = Array.isArray(value) ? value : (value ? [value] : []);
 const table = document.createElement('table'); table.style.width='100%'; table.style.borderCollapse='collapse'; table.className='editable-table';
 const header = document.createElement('tr'); ['Supplier','Risk Rating','Notes','Actions'].forEach(h=>{ const th=document.createElement('th'); th.style.textAlign='left'; th.style.padding='6px'; th.textContent=h; header.appendChild(th); }); table.appendChild(header);
 function renderRows(){
 Array.from(table.querySelectorAll('.data-row')).forEach(n=>n.remove());
 rows.forEach((s, idx)=>{
 const tr = document.createElement('tr'); tr.className='data-row';
 function td(el){ const c=document.createElement('td'); c.style.padding='6px'; c.appendChild(el); return c; }
 const nameInp = document.createElement('input'); nameInp.type='text'; nameInp.value = s.name || s.Name || '';
 nameInp.addEventListener('input', ()=>{ rows[idx].name = nameInp.value; });
 const ratingInp = document.createElement('input'); ratingInp.type='number'; ratingInp.min='0'; ratingInp.max='10'; ratingInp.step='0.1'; ratingInp.value = s.riskRating || s.RiskRating || '';
 ratingInp.addEventListener('input', ()=>{ rows[idx].riskRating = ratingInp.value ? parseFloat(ratingInp.value) : null; });
 const notesInp = document.createElement('input'); notesInp.type='text'; notesInp.value = s.notes || s.Notes || '';
 notesInp.addEventListener('input', ()=>{ rows[idx].notes = notesInp.value; });
 const delBtn = document.createElement('button'); delBtn.type='button'; delBtn.className='mini-btn'; delBtn.textContent='Remove'; delBtn.addEventListener('click', ()=>{ rows.splice(idx,1); renderRows(); });
 tr.appendChild(td(nameInp)); tr.appendChild(td(ratingInp)); tr.appendChild(td(notesInp)); tr.appendChild(td(delBtn)); table.appendChild(tr);
 });
 }
 renderRows();
 const addRow = document.createElement('button'); addRow.type='button'; addRow.className='mini-btn'; addRow.textContent='Add Supplier'; addRow.addEventListener('click', ()=>{ rows.push({ name:'', riskRating:null, notes:'' }); renderRows(); });
 container.appendChild(table); container.appendChild(addRow);
 container._rows = rows;
});

// fallback structured renderers (kept for compatibility)
GRC.registerStructuredRenderer('roles', function(container, value){
 const arr = Array.isArray(value)? value : (value? [value]:[]);
 const ul = document.createElement('ul'); ul.style.paddingLeft='18px'; arr.forEach(r=>{ const li=document.createElement('li'); li.textContent = String(r); ul.appendChild(li); }); container.appendChild(ul);
});
