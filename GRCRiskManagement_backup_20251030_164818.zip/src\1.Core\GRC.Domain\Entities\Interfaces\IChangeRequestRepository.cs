﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GRC.Domain.Entities.ChangeManagement;

using GRC.Domain.Interfaces;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Interfaces
{
    /// <summary>
    /// Repository interface for ChangeRequest
    /// </summary>
    public interface IChangeRequestRepository : IGenericRepository<ChangeRequest>
    {
        Task<IEnumerable<ChangeRequest>> GetActiveAsync();
        Task<ChangeRequest> GetByCodeAsync(string code);
        Task<IEnumerable<ChangeRequest>> SearchAsync(string searchTerm);
        Task<bool> ExistsAsync(Guid id);
    }
}




