using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using GRC.Domain.Entities.RiskManagement;
using GRC.Domain.Interfaces.Repositories;
using GRC.Infrastructure.Data.Content;

namespace GRC.Infrastructure.Data.Repositories
{
    public class RiskRepository : IRiskRepository
    {
        protected readonly GRCDbContext _context;
        protected readonly DbSet<Risk> _dbSet;

        public RiskRepository(GRCDbContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _dbSet = context.Set<Risk>();
        }

        public async Task<Risk?> GetByIdAsync(int id, CancellationToken cancellationToken = default)
        {
            return await _dbSet.FindAsync(new object[] { id }, cancellationToken);
        }

        public async Task<IReadOnlyList<Risk>> GetAllAsync(CancellationToken cancellationToken = default)
        {
            return await _dbSet.ToListAsync(cancellationToken);
        }

        public async Task<IReadOnlyList<Risk>> GetAllWithCategoryAsync(CancellationToken cancellationToken = default)
        {
            return await _dbSet.Include(r => r.Category).ToListAsync(cancellationToken);
        }

        public async Task<IReadOnlyList<Risk>> FindAsync(Expression<Func<Risk, bool>> predicate, CancellationToken cancellationToken = default)
        {
            return await _dbSet.Where(predicate).ToListAsync(cancellationToken);
        }

        public async Task<Risk?> FirstOrDefaultAsync(Expression<Func<Risk, bool>> predicate, CancellationToken cancellationToken = default)
        {
            return await _dbSet.FirstOrDefaultAsync(predicate, cancellationToken);
        }

        public async Task<Risk> AddAsync(Risk entity, CancellationToken cancellationToken = default)
        {
            await _dbSet.AddAsync(entity, cancellationToken);
            return entity;
        }

        public void Update(Risk entity)
        {
            _dbSet.Update(entity);
        }

        public void Delete(Risk entity)
        {
            _dbSet.Remove(entity);
        }

        public async Task<bool> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            return await _context.SaveChangesAsync(cancellationToken) > 0;
        }

        // IRiskRepository specific methods
        public async Task<Risk?> GetByIdWithDetailsAsync(int id, CancellationToken cancellationToken = default)
        {
            return await _dbSet.Include(r => r.Category).FirstOrDefaultAsync(r => r.Id == id, cancellationToken);
        }

        public async Task<IEnumerable<Risk>> GetByCategoryAsync(int categoryId, CancellationToken cancellationToken = default)
        {
            return await _dbSet
                .Where(r => r.CategoryId == categoryId)
                .ToListAsync(cancellationToken);
        }

        public async Task<IEnumerable<Risk>> GetHighRisksAsync(CancellationToken cancellationToken = default)
        {
            return await _dbSet
                .Where(r => r.RiskLevel == "High" || r.RiskLevel == "Critical")
                .ToListAsync(cancellationToken);
        }

        public async Task<IReadOnlyList<Risk>> GetByOwner(string ownerId, CancellationToken cancellationToken = default)
        {
            return await _dbSet
                .Where(r => r.Owner == ownerId)
                .ToListAsync(cancellationToken);
        }

        public async Task<IReadOnlyList<Risk>> GetTopRisks(int count, CancellationToken cancellationToken = default)
        {
            return await _dbSet
                .Where(r => r.Status != "Closed")
                .OrderByDescending(r => r.RiskLevel)
                .Take(count)
                .ToListAsync(cancellationToken);
        }
    }
}
