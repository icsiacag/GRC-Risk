﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GRC.Domain.Entities.PolicyManagement;

using GRC.Domain.Interfaces;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Interfaces
{
    /// <summary>
    /// Repository interface for Policy
    /// </summary>
    public interface IPolicyRepository : IGenericRepository<Policy>
    {
        Task<IEnumerable<Policy>> GetActiveAsync();
        Task<Policy> GetByCodeAsync(string code);
        Task<IEnumerable<Policy>> SearchAsync(string searchTerm);
        Task<bool> ExistsAsync(Guid id);
    }
}




