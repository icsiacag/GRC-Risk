using System;
using System.Threading.Tasks;

namespace GRC.Application.Services;

public class ReportGenerationService
{
    public Task GenerateReportAsync()
    {
        // Implementasyon buraya gelecek
        return Task.CompletedTask;
    }
}



