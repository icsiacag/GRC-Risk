﻿using MediatR;

namespace GRC.SharedKernel.Events;

public interface IDomainEvent : INotification
{
    DateTime OccurredOn { get; }
}