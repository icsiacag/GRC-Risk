using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace GRC.Application.UseCases.Risks.Queries.GetRiskById
{
    public class GetRiskByIdQueryHandler : IRequestHandler<GetRiskByIdQuery, RiskDetailDto>
    {
        public async Task<RiskDetailDto> Handle(GetRiskByIdQuery request, CancellationToken cancellationToken)
        {
            // Ge�ici implementasyon - ger�ek implementasyonu sonra ekleyece�iz
            await Task.CompletedTask;

            return new RiskDetailDto
            {
                Id = request.Id,
                Title = "Sample Risk",
                Description = "Sample Description",
                Probability = 3,
                Impact = 2
            };
        }
    }
}

