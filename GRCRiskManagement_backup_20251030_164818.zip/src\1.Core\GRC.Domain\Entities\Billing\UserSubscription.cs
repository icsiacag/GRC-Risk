﻿using GRC.SharedKernel;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.Billing
{
    public class UserSubscription : AuditableEntity<int>
    {
        // Support string-based user identifiers (GUIDs or external ids)
        public string UserId { get; set; } = string.Empty;
        public int PlanId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public bool IsActive { get; set; }
        public string Status { get; set; } = string.Empty;
    }
}






