﻿namespace GRC.Domain.Entities.Enums
{
    public enum BreachSeverity
    {
        Minor = 1,
        Moderate = 2,
        Major = 3,
        Critical = 4
    }
}


