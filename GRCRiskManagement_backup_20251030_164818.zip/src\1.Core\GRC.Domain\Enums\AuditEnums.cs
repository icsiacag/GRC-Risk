﻿namespace GRC.Domain.Enums
{
    public enum AuditPlanStatus
    {
        Draft = 1,
        Planned = 2,
        InProgress = 3,
        Completed = 4,
        Cancelled = 5
    }

    public enum FindingStatus
    {
        Open = 1,
        InProgress = 2,
        Resolved = 3,
        Closed = 4
    }

    public enum SeverityLevel
    {
        Low = 1,
        Medium = 2,
        High = 3,
        Critical = 4
    }

    public enum CorrectiveActionStatus
    {
        Pending = 1,
        InProgress = 2,
        Completed = 3,
        Verified = 4
    }
}




























