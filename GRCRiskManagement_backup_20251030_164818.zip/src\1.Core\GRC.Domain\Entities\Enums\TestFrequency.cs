﻿namespace GRC.Domain.Entities.Enums
{
    public enum TestFrequency
    {
        Daily = 1,
        Weekly = 2,
        Monthly = 3,
        Quarterly = 4,
        Annually = 5
    }
}


