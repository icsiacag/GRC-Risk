using System.Collections.Generic;
using System.Threading.Tasks;
using GRC.Domain.Common;
using GRC.Domain.Entities.Risk;
using GRC.Infrastructure.Data.Repositories;

namespace GRC.Application.Services
{
 /// <summary>
 /// Service for managing I/O exchanges between risk categories
 /// </summary>
 public interface ICategoryExchangeService
 {
 Task<ExchangeResult> ExchangeDataAsync(int sourceId, int targetId);
 Task<List<ExchangeBenefit>> CalculateMutualBenefitsAsync(int categoryId);
 }

 public class CategoryExchangeService : ICategoryExchangeService
 {
 private readonly IRiskCategoryRepository _categoryRepository;

 public CategoryExchangeService(IRiskCategoryRepository categoryRepository)
 {
 _categoryRepository = categoryRepository;
 }

 public async Task<ExchangeResult> ExchangeDataAsync(int sourceId, int targetId)
 {
 var source = await _categoryRepository.GetByIdAsync(sourceId);
 var target = await _categoryRepository.GetByIdAsync(targetId);

 if (source == null || target == null)
 return ExchangeResult.Failed("Category not found");

 var output = source.ExportData();
 var input = new RiskCategoryInput
 {
 ImportedMetrics = output.Metrics,
 SourceCategory = output.CategoryType
 };
 target.ImportData(input);
 await _categoryRepository.UpdateAsync(target);
 return ExchangeResult.Success("Data exchanged successfully");
 }

 public async Task<List<ExchangeBenefit>> CalculateMutualBenefitsAsync(int categoryId)
 {
 var category = await _categoryRepository.GetByIdAsync(categoryId);
 if (category == null) return new List<ExchangeBenefit>();
 var benefits = new List<ExchangeBenefit>();
 if (category is GRC.Domain.Entities.Risk.Categories.ProgrammaticProjectRiskCategory projectCategory)
 {
 var strategicCategories = await _categoryRepository.GetByTypeAsync<GRC.Domain.Entities.Risk.Categories.StrategicRiskCategory>();
 foreach (var strategic in strategicCategories)
 {
 benefits.Add(new ExchangeBenefit
 {
 SourceCategory = "ProgrammaticProject",
 TargetCategory = "Strategic",
 BenefitType = "Timeline Insights",
 Description = "Project milestones inform strategic target deadlines",
 ImpactScore =0.75m
 });
 }
 }
 return benefits;
 }
 }

 public class ExchangeResult
 {
 public bool IsSuccess { get; set; }
 public string Message { get; set; } = string.Empty;
 public static ExchangeResult Success(string message) => new() { IsSuccess = true, Message = message };
 public static ExchangeResult Failed(string message) => new() { IsSuccess = false, Message = message };
 }

 public class ExchangeBenefit
 {
 public string SourceCategory { get; set; } = string.Empty;
 public string TargetCategory { get; set; } = string.Empty;
 public string BenefitType { get; set; } = string.Empty;
 public string Description { get; set; } = string.Empty;
 public decimal ImpactScore { get; set; }
 }
}
