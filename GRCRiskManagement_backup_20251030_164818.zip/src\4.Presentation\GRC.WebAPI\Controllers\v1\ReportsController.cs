using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Mvc;

namespace GRC.WebAPI.Controllers.v1
{
 [ApiController]
 [Route("api/v1/reports")]
 public class ReportsController : ControllerBase
 {
 [HttpPost("export")]
 public IActionResult Export([FromBody] ExportRequestDto dto)
 {
 var csv = new StringBuilder(); csv.AppendLine("Id,Name,Value"); csv.AppendLine($"{Guid.NewGuid()},Sample,123");
 var bytes = Encoding.UTF8.GetBytes(csv.ToString());
 return File(bytes, "text/csv", "report.csv");
 }
 public class ExportRequestDto{ public string ReportName { get; set; } }
 }
}
