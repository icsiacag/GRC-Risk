using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;

namespace GRC.WebAPI.Controllers.v1
{
 [ApiController]
 [Route("api/v1/selfassessments")]
 public class SelfAssessmentController : ControllerBase
 {
 private static readonly List<SelfAssessmentDto> Items = new List<SelfAssessmentDto>
 {
 new SelfAssessmentDto{ Id = Guid.NewGuid(), Title = "Quarterly Control Check", Date = DateTime.UtcNow }
 };

 [HttpGet]
 public ActionResult<IEnumerable<SelfAssessmentDto>> GetAll() => Ok(Items);

 [HttpPost]
 public ActionResult<SelfAssessmentDto> Create([FromBody] CreateDto dto)
 {
 var item = new SelfAssessmentDto{ Id = Guid.NewGuid(), Title = dto.Title, Date = DateTime.UtcNow };
 Items.Add(item);
 return CreatedAtAction(nameof(GetAll), new { id=item.Id }, item);
 }

 public class SelfAssessmentDto{ public Guid Id { get; set; } public string Title { get; set; } public DateTime Date { get; set; } }
 public class CreateDto{ public string Title { get; set; } }
 }
}
