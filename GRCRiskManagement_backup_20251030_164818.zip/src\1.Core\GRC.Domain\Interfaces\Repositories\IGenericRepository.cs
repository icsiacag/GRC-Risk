using System;
using System.Collections.Generic;
using System;
using System.Collections.Generic;
using System.Linq.Expressions; // Bu sat�r� ekleyin
using System.Threading;
using System.Threading.Tasks;

namespace GRC.Domain.Interfaces.Repositories
{
    public interface IGenericRepository<T> where T : class
    {
        Task<T> GetByIdAsync(Guid id, CancellationToken cancellationToken = default);
        Task<IEnumerable<T>> GetAllAsync(CancellationToken cancellationToken = default);
        Task<T> AddAsync(T entity, CancellationToken cancellationToken = default);
        Task<T> UpdateAsync(T entity, CancellationToken cancellationToken = default);
        Task DeleteAsync(T entity, CancellationToken cancellationToken = default);
        Task<bool> ExistsAsync(Expression<Func<T, bool>> predicate, CancellationToken cancellationToken = default);
        Task<T> FindAsync(Expression<Func<T, bool>> predicate, CancellationToken cancellationToken = default);
    }
}


