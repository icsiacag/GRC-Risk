﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GRC.Domain.Entities.DataPrivacy;

using GRC.Domain.Interfaces;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Interfaces
{
    /// <summary>
    /// Repository interface for DataAsset
    /// </summary>
    public interface IDataAssetRepository : IGenericRepository<DataAsset>
    {
        Task<IEnumerable<DataAsset>> GetActiveAsync();
        Task<DataAsset> GetByCodeAsync(string code);
        Task<IEnumerable<DataAsset>> SearchAsync(string searchTerm);
        Task<bool> ExistsAsync(Guid id);
    }
}




