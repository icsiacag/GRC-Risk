using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using GRC.Domain.Entities.Compliance;
using GRC.Domain.Enums;
using GRC.Infrastructure.Data.Content;

namespace GRC.Infrastructure.Data.Seeds;

public static class ComplianceFrameworkSeed
{
    public static async Task SeedAsync(GRCDbContext context)
    {
        if (context.ComplianceFrameworks.Any())
            return;

        var frameworks = new List<ComplianceFramework>
        {
            ComplianceFramework.Create(
                "ISO/IEC 27001:2022",
                "Information Security Management System",
                ComplianceFrameworkType.ISO27001,
                "2022",
                "System",
                requiresCertification: true),

            ComplianceFramework.Create(
                "SOC 2 Type II",
                "Service Organization Control 2",
                ComplianceFrameworkType.SOC2,
                "2023",
                "System",
                requiresCertification: true),

            ComplianceFramework.Create(
                "GDPR",
                "General Data Protection Regulation",
                ComplianceFrameworkType.GDPR,
                "2018",
                "System",
                requiresCertification: false),

            ComplianceFramework.Create(
                "KVKK",
                "Ki�isel Verilerin Korunmas� Kanunu",
                ComplianceFrameworkType.KVKK,
                "2016",
                "System",
                requiresCertification: false)
        };

        foreach (var framework in frameworks)
        {
            framework.SetCreatedBy("System");
        }

        await context.ComplianceFrameworks.AddRangeAsync(frameworks);
        await context.SaveChangesAsync();
    }
}


