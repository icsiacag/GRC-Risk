using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using GRC.Application.Services.AI;
using GRC.Infrastructure.Data.Content;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;

namespace GRC.WebAPI.Controllers.v1
{
 [ApiController]
 [Route("api/v1/predictions")]
 [Authorize]
 public class RiskPredictionController : ControllerBase
 {
 private readonly RiskPredictionService _predictionService;
 private readonly GRCDbContext _db;
 public RiskPredictionController(RiskPredictionService predictionService, GRCDbContext db) { _predictionService = predictionService; _db = db; }

 [HttpPost("train")]
 [Authorize(Roles = "Admin,MLEngineer")]
 public async Task<IActionResult> Train()
 {
 // Simple: use recent risks as training data (demo only)
 var risks = await _db.Risks.Include(r => r.Likelihood).Include(r => r.Impact).Take(500).ToListAsync();
 var training = new System.Collections.Generic.List<RiskTrainingData>();
 foreach (var r in risks)
 {
 var catScore = (float)(await r.Category.CalculateRiskScoreAsync(r)).InherentScore;
 training.Add(new RiskTrainingData { Description = r.Description, LikelihoodScore = r.Likelihood.Score, ImpactScore = r.Impact.Score, CategoryScore = catScore, AppetiteScore = r.RiskAppetite?.ToleranceScore ??0, InherentScore = (float)r.InherentScore, CreatedDaysAgo = (float)(System.DateTime.UtcNow - r.IdentifiedDate).TotalDays, CategoryType = r.Category?.GetType().Name ?? string.Empty });
 }
 await _predictionService.TrainModelAsync(training);
 return Ok("Model trained (demo)");
 }

 [HttpGet("predict/{riskId}")]
 public async Task<IActionResult> Predict([FromRoute] int riskId)
 {
 var risk = await _db.Risks.Include(r => r.Likelihood).Include(r => r.Impact).Include(r => r.Category).FirstOrDefaultAsync(r => r.Id == riskId);
 if (risk == null) return NotFound();
 var pred = await _predictionService.PredictAsync(risk);
 return Ok(pred);
 }
 }
}
