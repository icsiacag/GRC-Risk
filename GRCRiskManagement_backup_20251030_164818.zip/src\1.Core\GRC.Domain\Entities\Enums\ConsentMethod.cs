﻿namespace GRC.Domain.Entities.Enums
{
    public enum ConsentMethod
    {
        Explicit = 1,
        Implicit = 2,
        OptIn = 3,
        OptOut = 4
    }
}


