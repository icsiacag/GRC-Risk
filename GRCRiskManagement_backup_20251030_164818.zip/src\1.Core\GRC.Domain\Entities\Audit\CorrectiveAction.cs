﻿using GRC.SharedKernel;
using GRC.Domain.Common;
using System;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.Audit
{
    public class CorrectiveAction : AuditableEntity<int>
    {
        public string Description { get; set; }
        public DateTime DueDate { get; set; }
        public string Status { get; set; }
        public int RiskId { get; set; }
        public string AssignedTo { get; set; }
        public DateTime? CompletedDate { get; set; }
        public string Result { get; set; }
    }
}






