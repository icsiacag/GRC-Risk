﻿using System;
using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.Risk.Categories
{
 public class FinancialRiskCategory : GRC.Domain.Entities.RiskManagement.RiskCategory
 {
 public string? CurrencyExposures { get; set; }
 public FinancialRiskCategory() : base() { }
 public FinancialRiskCategory(string code, string name, string description) : base() { Code = code; Name = name; Description = description; }
 }
}




