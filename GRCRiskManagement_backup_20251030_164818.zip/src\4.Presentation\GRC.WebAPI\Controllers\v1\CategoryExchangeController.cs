using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using GRC.Application.Services;
using Microsoft.AspNetCore.Authorization;

namespace GRC.WebAPI.Controllers.v1
{
 [ApiController]
 [Route("api/v1/category-exchange")]
 [Authorize]
 public class CategoryExchangeController : ControllerBase
 {
 private readonly ICategoryExchangeService _exchangeService;
 public CategoryExchangeController(ICategoryExchangeService exchangeService) { _exchangeService = exchangeService; }

 [HttpPost("exchange")]
 [Authorize(Roles = "Admin,Configurator")]
 public async Task<IActionResult> Exchange([FromQuery] int sourceId, [FromQuery] int targetId)
 {
 var res = await _exchangeService.ExchangeDataAsync(sourceId, targetId);
 if (!res.IsSuccess) return BadRequest(res.Message);
 return Ok(res.Message);
 }

 [HttpGet("benefits/{categoryId}")]
 public async Task<IActionResult> Benefits([FromRoute] int categoryId)
 {
 var b = await _exchangeService.CalculateMutualBenefitsAsync(categoryId);
 return Ok(b);
 }
 }
}
