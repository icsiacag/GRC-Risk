﻿using System;
using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.Risk.Categories
{
 public class ITCyberRiskCategory : GRC.Domain.Entities.RiskManagement.RiskCategory
 {
 public string? TechDomain { get; set; }
 public ITCyberRiskCategory() : base() { }
 }
}




