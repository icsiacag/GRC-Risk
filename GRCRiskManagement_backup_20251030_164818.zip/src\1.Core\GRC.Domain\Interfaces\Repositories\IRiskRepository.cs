using GRC.Domain.Entities.RiskManagement;

namespace GRC.Domain.Interfaces.Repositories
{
    public interface IRiskRepository : IRepository<Risk>
    {
        Task<Risk?> GetByIdWithDetailsAsync(int id, CancellationToken cancellationToken = default);
        Task<IEnumerable<Risk>> GetByCategoryAsync(int categoryId, CancellationToken cancellationToken = default);
        Task<IEnumerable<Risk>> GetHighRisksAsync(CancellationToken cancellationToken = default);
        Task<IReadOnlyList<Risk>> GetByOwner(string ownerId, CancellationToken cancellationToken = default);
        Task<IReadOnlyList<Risk>> GetTopRisks(int count, CancellationToken cancellationToken = default);
    }
}
