﻿using System;
using System.Collections.Generic;
using GRC.SharedKernel;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.VendorRiskManagement
{
    /// <summary>
    /// VendorAssessment entity for GRC system
    /// Generated on: 2025-10-30 16:18:22
    /// </summary>
    public class VendorAssessment : GRC.SharedKernel.Entities.BaseEntity
    {
        public Guid VendorId { get; set; }
        public AssessmentType Type { get; set; }
        public DateTime AssessmentDate { get; set; }
        public string AssessedBy { get; set; }
        public decimal Score { get; set; }
        public RiskLevel OverallRating { get; set; }
        public string Findings { get; set; }
        public string Recommendations { get; set; }
        public DateTime? NextReviewDate { get; set; }
        
        // Navigation properties and domain logic can be added here
        
        /// <summary>
        /// Validates the entity state
        /// </summary>
        
        /// <summary>
        /// Domain event when entity is created
        /// </summary>
        public void OnCreated()
        {
            CreatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
        
        /// <summary>
        /// Domain event when entity is updated
        /// </summary>
        public void OnUpdated()
        {
            UpdatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
    }
}



