using System.Collections.Generic;

namespace GRC.Domain.Common
{
 /// <summary>
 /// Interface for I/O exchange between risk categories
 /// </summary>
 public interface IRiskCategoryExchange
 {
 RiskCategoryOutput ExportData();
 void ImportData(RiskCategoryInput input);
 }

 public class RiskCategoryOutput
 {
 public int CategoryId { get; set; }
 public string CategoryType { get; set; } = string.Empty;
 public Dictionary<string, object> Metrics { get; set; } = new();
 public List<string> RelatedRisks { get; set; } = new();
 }

 public class RiskCategoryInput
 {
 public Dictionary<string, object> ImportedMetrics { get; set; } = new();
 public string SourceCategory { get; set; } = string.Empty;
 }
}
