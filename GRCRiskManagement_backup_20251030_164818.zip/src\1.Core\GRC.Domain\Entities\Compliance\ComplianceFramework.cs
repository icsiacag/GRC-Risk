﻿using GRC.SharedKernel;
using GRC.Domain.Common;
using GRC.Domain.Enums;
using System;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.Compliance
{
    public class ComplianceFramework : AuditableEntity<int>
    {
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string Version { get; set; } = string.Empty;
        public ComplianceFrameworkType Type { get; set; }
        public string Applicability { get; set; } = string.Empty;
        public DateTime EffectiveDate { get; set; }
        public ComplianceStatus Status { get; set; }
        public bool RequiresCertification { get; set; }

        // Private constructor for EF Core
        private ComplianceFramework() { }

        // Factory method
        public static ComplianceFramework Create(
            string name,
            string description,
            ComplianceFrameworkType type,
            string version,
            string createdBy,
            bool requiresCertification = false)
        {
            return new ComplianceFramework
            {
                Name = name,
                Description = description,
                Type = type,
                Version = version,
                RequiresCertification = requiresCertification,
                EffectiveDate = DateTime.UtcNow,
                Status = ComplianceStatus.NotStarted,
                Applicability = "General"
            };
        }
    }
}










