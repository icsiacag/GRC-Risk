using MediatR;
using GRC.Domain.Interfaces.Repositories;
using GRC.Domain.Entities.RiskManagement;

namespace GRC.Application.UseCases.Risks.Commands.CreateRisk
{
    public class CreateRiskCommandHandler : IRequestHandler<CreateRiskCommand, Guid>
    {
        private readonly IRiskRepository _riskRepository;

        public CreateRiskCommandHandler(IRiskRepository riskRepository)
        {
            _riskRepository = riskRepository;
        }

        public async Task<Guid> Handle(CreateRiskCommand request, CancellationToken cancellationToken)
        {
            var risk = new Risk
            {
                Title = request.Title,
                Description = request.Description,
                CategoryId = request.RiskCategoryId,
                Likelihood = request.LikelihoodLevel,
                Impact = request.ImpactLevel,
                Owner = request.OwnerId,
                Status = "Open",
                IdentifiedDate = DateTime.UtcNow,
                Treatment = string.Empty,
                RiskLevel = CalculateRiskLevel(request.LikelihoodLevel, request.ImpactLevel)
            };

            await _riskRepository.AddAsync(risk, cancellationToken);
            await _riskRepository.SaveChangesAsync(cancellationToken);

            return Guid.NewGuid(); // Risk.Id int oldu�u i�in ge�ici ��z�m
        }

        private string CalculateRiskLevel(string likelihood, string impact)
        {
            // Basit risk seviyesi hesaplama
            return "Medium"; // Ger�ek hesaplama mant��� eklenebilir
        }
    }
}
