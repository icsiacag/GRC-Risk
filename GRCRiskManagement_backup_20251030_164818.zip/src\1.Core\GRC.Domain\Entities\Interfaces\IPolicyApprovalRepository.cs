﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GRC.Domain.Entities.PolicyManagement;

using GRC.Domain.Interfaces;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Interfaces
{
    /// <summary>
    /// Repository interface for PolicyApproval
    /// </summary>
    public interface IPolicyApprovalRepository : IGenericRepository<PolicyApproval>
    {
        Task<IEnumerable<PolicyApproval>> GetActiveAsync();
        Task<PolicyApproval> GetByCodeAsync(string code);
        Task<IEnumerable<PolicyApproval>> SearchAsync(string searchTerm);
        Task<bool> ExistsAsync(Guid id);
    }
}




