using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using GRC.Application.Common.Behaviors;
using FluentValidation;
using System.Reflection;
using GRC.Application.Services;
using GRC.Application.Services.AI;

namespace GRC.Application;

public static class DependencyInjection
{
    public static IServiceCollection AddApplication(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddMediatR(cfg =>
        {
            cfg.RegisterServicesFromAssembly(Assembly.GetExecutingAssembly());
            cfg.AddOpenBehavior(typeof(ValidationBehavior<,>));
            cfg.AddOpenBehavior(typeof(LoggingBehavior<,>));
            cfg.AddOpenBehavior(typeof(PerformanceBehavior<,>));
            cfg.AddOpenBehavior(typeof(TransactionBehavior<,>));
        });

        // FluentValidation - requires FluentValidation.DependencyInjectionExtensions package
        // services.AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());
        // AutoMapper profiles
        services.AddAutoMapper(typeof(DependencyInjection).Assembly);

        return services;
    }

    public static IServiceCollection AddApplicationServices(this IServiceCollection services)
    {
        // AutoMapper registration is expected elsewhere; register application services here
        services.AddScoped<ICategoryExchangeService, CategoryExchangeService>();
        // ML service: singleton to reuse MLContext and compiled model
        services.AddSingleton<RiskPredictionService>();
        services.AddSingleton<IModelPersistence, ModelRegistry>();

        return services;
    }
}



