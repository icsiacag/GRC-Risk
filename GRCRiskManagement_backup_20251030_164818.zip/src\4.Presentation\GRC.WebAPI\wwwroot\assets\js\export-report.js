// Export report helper used by dashboard
// Uses fetch and creates a download link. Shows toasts on failure/success.
async function exportReport() {
    try {
        const resp = await fetch('/api/v1/reports/export', { method: 'POST', credentials: 'same-origin' });
        if (!resp.ok) {
            GRC && GRC.showToast ? GRC.showToast('Export failed', 'error') : alert('Export failed');
            return;
        }
        const blob = await resp.blob();
        const contentDisposition = resp.headers.get('Content-Disposition') || '';
        let filename = 'report.csv';
        const m = /filename="?([^";]+)"?/.exec(contentDisposition);
        if (m) filename = m[1];
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(url);
        if (GRC && GRC.showToast) GRC.showToast('Export started');
    } catch (e) {
        console.error(e);
        GRC && GRC.showToast ? GRC.showToast('Export failed: ' + e.message, 'error') : alert('Export failed: ' + e.message);
    }
}
