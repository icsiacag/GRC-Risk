using System.Collections.Generic;

namespace GRC.Application.Contracts.DTOs.Categories
{
 public class SupplyChainDetailsDto
 {
 public List<string>? SupplierDependencies { get; set; }
 public List<string>? DisruptionScenarios { get; set; }
 public List<object>? LinkedSubsidiaries { get; set; }
 }
}