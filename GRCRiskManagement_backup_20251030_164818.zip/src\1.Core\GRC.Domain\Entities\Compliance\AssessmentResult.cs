﻿using GRC.SharedKernel;
using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.Compliance
{
    public class AssessmentResult : AuditableEntity<int>
    {
        public int AssessmentId { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Result { get; set; } = string.Empty;
        public int Score { get; set; }
        public DateTime AssessmentDate { get; set; }
        public string Status { get; set; } = string.Empty;
    }
}




