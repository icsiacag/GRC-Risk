using Microsoft.EntityFrameworkCore.Migrations;
using System;

#nullable disable

namespace GRC.Infrastructure.Data.Migrations
{
 public partial class RiskCategoryTphDiscriminator : Migration
 {
 protected override void Up(MigrationBuilder migrationBuilder)
 {
 migrationBuilder.AddColumn<string>(
 name: "CategoryType",
 table: "RiskCategories",
 type: "nvarchar(max)",
 nullable: true);

 migrationBuilder.AddColumn<string>(
 name: "MetadataJson",
 table: "RiskCategories",
 type: "nvarchar(max)",
 nullable: true);
 }

 protected override void Down(MigrationBuilder migrationBuilder)
 {
 migrationBuilder.DropColumn(
 name: "CategoryType",
 table: "RiskCategories");

 migrationBuilder.DropColumn(
 name: "MetadataJson",
 table: "RiskCategories");
 }
 }
}
