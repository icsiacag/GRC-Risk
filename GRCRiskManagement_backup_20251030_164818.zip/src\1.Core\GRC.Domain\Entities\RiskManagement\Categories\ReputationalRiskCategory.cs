﻿using System;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.RiskManagement.Categories
{
 public class ReputationalRiskCategory : RiskCategory
 {
 public string MonitoringKeywords { get; set; } = string.Empty;
 public string MediaSources { get; set; } = string.Empty;
 public ReputationalRiskCategory() : base() { }
 public ReputationalRiskCategory(string name, string description, string color) : base(name, description, color) { }
 }
}



