﻿# Generate EF Core migrations for new entities
cd "C:\Users\ahmetefe\source\repos\GRCRiskManagement\src\3.Infrastructure\GRC.Infrastructure.Data"

# Add migrations for new modules
dotnet ef migrations add AddPolicyManagement --context GRCDbContext
dotnet ef migrations add AddVendorRiskManagement --context GRCDbContext
dotnet ef migrations add AddIncidentManagement --context GRCDbContext
dotnet ef migrations add AddKRI_KPI --context GRCDbContext
dotnet ef migrations add AddDataPrivacy --context GRCDbContext
dotnet ef migrations add AddControlTesting --context GRCDbContext
dotnet ef migrations add AddRiskAppetite --context GRCDbContext
dotnet ef migrations add AddChangeManagement --context GRCDbContext

# Apply migrations (use with caution in production)
# dotnet ef database update --context GRCDbContext
