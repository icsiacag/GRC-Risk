using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using GRC.Infrastructure.Data.Entities;

namespace GRC.Infrastructure.Data.Configurations
{
 public class KpiSnapshotConfiguration : IEntityTypeConfiguration<KpiSnapshot>
 {
 public void Configure(EntityTypeBuilder<KpiSnapshot> builder)
 {
 builder.ToTable("KpiSnapshots");
 builder.HasKey(x => x.Id);
 builder.Property(x => x.SnapshotAt).IsRequired();
 builder.Property(x => x.JsonPayload).HasColumnType("nvarchar(max)");
 builder.HasIndex(x => x.SnapshotAt);
 }
 }
}
