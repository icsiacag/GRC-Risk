﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GRC.Domain.Entities.ControlTesting;

using GRC.Domain.Interfaces;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Interfaces
{
    /// <summary>
    /// Repository interface for ControlDeficiency
    /// </summary>
    public interface IControlDeficiencyRepository : IGenericRepository<ControlDeficiency>
    {
        Task<IEnumerable<ControlDeficiency>> GetActiveAsync();
        Task<ControlDeficiency> GetByCodeAsync(string code);
        Task<IEnumerable<ControlDeficiency>> SearchAsync(string searchTerm);
        Task<bool> ExistsAsync(Guid id);
    }
}




