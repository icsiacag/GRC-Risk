﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using GRC.Domain.Entities.RiskManagement;
using GRC.Domain.Common;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.Risk.Categories
{
 /// <summary>
 /// Supply chain risks including supplier dependencies and disruption scenarios
 /// </summary>
 public class SupplyChainRiskCategory : GRC.Domain.Entities.RiskManagement.RiskCategory
 {
 public string? SupplierDependencies { get; set; } // JSON
 public string? DisruptionScenarios { get; set; } // JSON array

 // Use object for linked subsidiaries to avoid missing domain type dependency
 public List<object> LinkedSubsidiaries { get; set; } = new();

 public SupplyChainRiskCategory() : base() { }

 );
 }

 

 public override async Task<List<string>> GetAIRecommendationsAsync()
 {
 var rec = new List<string>();
 rec.Add("Simulate supplier failure scenarios and develop contingency plans.");
 rec.Add("Evaluate dual-sourcing for critical components.");
 return await Task.FromResult(rec);
 }

 private List<string> DeserializeArray(string? json)
 {
 if (string.IsNullOrWhiteSpace(json)) return new();
 try { return JsonSerializer.Deserialize<List<string>>(json) ?? new(); } catch { return new(); }
 }

 private string DetermineLevel(decimal score)
 {
 return score switch
 {
 <3 => "Low",
 <6 => "Medium",
 <9 => "High",
 _ => "Critical"
 };
 }

 public override RiskCategoryOutput ExportData()
 {
 var o = base.ExportData();
 o.Metrics["SupplierCount"] = DeserializeArray(SupplierDependencies).Count;
 return o;
 }
 }
}





