﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GRC.Domain.Entities.ControlTesting;

using GRC.Domain.Interfaces;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Interfaces
{
    /// <summary>
    /// Repository interface for ControlTest
    /// </summary>
    public interface IControlTestRepository : IGenericRepository<ControlTest>
    {
        Task<IEnumerable<ControlTest>> GetActiveAsync();
        Task<ControlTest> GetByCodeAsync(string code);
        Task<IEnumerable<ControlTest>> SearchAsync(string searchTerm);
        Task<bool> ExistsAsync(Guid id);
    }
}




