﻿using System;
using System.Collections.Generic;
using GRC.SharedKernel;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.ControlTesting
{
    /// <summary>
    /// ControlDeficiency entity for GRC system
    /// Generated on: 2025-10-30 16:18:22
    /// </summary>
    public class ControlDeficiency : GRC.SharedKernel.Entities.BaseEntity
    {
        public Guid ControlTestId { get; set; }
        public DeficiencySeverity Severity { get; set; }
        public string Description { get; set; }
        public string Impact { get; set; }
        public string RootCause { get; set; }
        public string RemediationPlan { get; set; }
        public DateTime IdentifiedDate { get; set; }
        public DateTime? TargetDate { get; set; }
        public DateTime? ResolvedDate { get; set; }
        public string ResponsiblePerson { get; set; }
        public DeficiencyStatus Status { get; set; }
        
        // Navigation properties and domain logic can be added here
        
        /// <summary>
        /// Validates the entity state
        /// </summary>
        
        /// <summary>
        /// Domain event when entity is created
        /// </summary>
        public void OnCreated()
        {
            CreatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
        
        /// <summary>
        /// Domain event when entity is updated
        /// </summary>
        public void OnUpdated()
        {
            UpdatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
    }
}



