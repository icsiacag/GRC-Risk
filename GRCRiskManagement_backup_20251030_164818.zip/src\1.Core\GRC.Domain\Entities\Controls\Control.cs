﻿using GRC.SharedKernel;
using GRC.Domain.Entities.RiskManagement;
using System.Collections.Generic;
using GRC.Domain.Enums;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.Controls
{
    public class Control : AuditableEntity<int>
    {
        public string ControlCode { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string ControlType { get; set; } = string.Empty;
        public string Category { get; set; } = string.Empty;
        public bool IsActive { get; set; } = true;

        // Frequency of this control (e.g., Daily, Weekly, Monthly)
        public string Frequency { get; set; } = string.Empty;

        // Who is accountable/responsible for the control
        public string Owner { get; set; } = string.Empty;

        // Action type (primary action associated with the control)
        public ControlActionType? ActionType { get; set; }

        // Optional scope/unit selection (branch, delegation, head office unit, company)
        public int? ControlUnitId { get; set; }
        public ControlUnit? ControlUnit { get; set; }

        // Navigation properties
        public int? RiskId { get; set; }
        public GRC.Domain.Entities.RiskManagement.Risk? Risk { get; set; }

        // Test records
        public List<ControlTestRecord> TestRecords { get; set; } = new();
    }
}








