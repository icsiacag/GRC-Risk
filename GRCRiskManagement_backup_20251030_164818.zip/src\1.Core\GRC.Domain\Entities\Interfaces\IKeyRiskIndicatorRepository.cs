﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GRC.Domain.Entities.KRI_KPI;

using GRC.Domain.Interfaces;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Interfaces
{
    /// <summary>
    /// Repository interface for KeyRiskIndicator
    /// </summary>
    public interface IKeyRiskIndicatorRepository : IGenericRepository<KeyRiskIndicator>
    {
        Task<IEnumerable<KeyRiskIndicator>> GetActiveAsync();
        Task<KeyRiskIndicator> GetByCodeAsync(string code);
        Task<IEnumerable<KeyRiskIndicator>> SearchAsync(string searchTerm);
        Task<bool> ExistsAsync(Guid id);
    }
}




