﻿using System;
using System.Collections.Generic;
using GRC.SharedKernel;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.DataPrivacy
{
    /// <summary>
    /// PrivacyImpactAssessment entity for GRC system
    /// Generated on: 2025-10-30 16:18:22
    /// </summary>
    public class PrivacyImpactAssessment : GRC.SharedKernel.Entities.BaseEntity
    {
        public string PIANumber { get; set; }
        public Guid DataAssetId { get; set; }
        public DateTime AssessmentDate { get; set; }
        public string AssessedBy { get; set; }
        public RiskLevel PrivacyRisk { get; set; }
        public string Findings { get; set; }
        public string Recommendations { get; set; }
        public PIAStatus Status { get; set; }
        public DateTime? ReviewDate { get; set; }
        
        // Navigation properties and domain logic can be added here
        
        /// <summary>
        /// Validates the entity state
        /// </summary>
        
        /// <summary>
        /// Domain event when entity is created
        /// </summary>
        public void OnCreated()
        {
            CreatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
        
        /// <summary>
        /// Domain event when entity is updated
        /// </summary>
        public void OnUpdated()
        {
            UpdatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
    }
}



