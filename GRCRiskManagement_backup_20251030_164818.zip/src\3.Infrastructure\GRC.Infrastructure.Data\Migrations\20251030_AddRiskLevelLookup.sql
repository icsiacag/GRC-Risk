-- SQL seed for RiskLevelLookup (if running migrations manually)
CREATE TABLE RiskLevelLookup (
 Id INT IDENTITY(1,1) PRIMARY KEY,
 Label NVARCHAR(100) NOT NULL,
 Keywords NVARCHAR(1000) NULL
);

INSERT INTO RiskLevelLookup (Label, Keywords) VALUES
('Critical','critical,crit,kritik'),
('High','high,yuksek,y�ksek'),
('Medium','medium,med,orta'),
('Low','low,dusuk,d���k');
