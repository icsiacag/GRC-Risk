using FluentValidation;

namespace GRC.Application.UseCases.Risks.Commands.UpdateRisk
{
    public class UpdateRiskCommandValidator : AbstractValidator<UpdateRiskCommand>
    {
        public UpdateRiskCommandValidator()
        {
            RuleFor(x => x.Id)
                .GreaterThan(0).WithMessage("Id must be greater than 0");

            RuleFor(x => x.Title)
                .NotEmpty().WithMessage("Title is required")
                .MaximumLength(200).WithMessage("Title must not exceed 200 characters");
        }
    }
}



