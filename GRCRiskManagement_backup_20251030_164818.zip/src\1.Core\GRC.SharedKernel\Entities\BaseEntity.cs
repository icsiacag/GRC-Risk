using GRC.SharedKernel.Interfaces;

namespace GRC.SharedKernel.Entities
{
    public abstract class BaseEntity : EntityBase
    {
        public string? CreatedBy { get; set; }
        public string? LastModifiedBy { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime? LastModifiedAt { get; set; }
    }
}
