using System;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace GRC.Infrastructure.Data.Workers
{
 public class KpiSnapshotWorker : BackgroundService
 {
 private readonly IServiceProvider _services;
 private readonly ILogger<KpiSnapshotWorker> _logger;
 private readonly TimeSpan _period = TimeSpan.FromMinutes(5);

 public KpiSnapshotWorker(IServiceProvider services, ILogger<KpiSnapshotWorker> logger)
 {
 _services = services;
 _logger = logger;
 }
 protected override async Task ExecuteAsync(CancellationToken stoppingToken)
 {
 _logger.LogInformation("KpiSnapshotWorker started");
 while (!stoppingToken.IsCancellationRequested)
 {
 try
 {
 using var scope = _services.CreateScope();
 var db = scope.ServiceProvider.GetRequiredService<Content.GRCDbContext>();
 var total = await db.Risks.AsNoTracking().CountAsync(stoppingToken);
 var critical = await db.Risks.AsNoTracking().CountAsync(r => r.RiskLevelId != null && db.Set<GRC.Infrastructure.Data.Entities.RiskLevelLookup>().Any(l=>l.Id==r.RiskLevelId && l.Label=="Critical"), stoppingToken);
 var high = await db.Risks.AsNoTracking().CountAsync(r => r.RiskLevelId != null && db.Set<GRC.Infrastructure.Data.Entities.RiskLevelLookup>().Any(l=>l.Id==r.RiskLevelId && l.Label=="High"), stoppingToken);
 var medium = await db.Risks.AsNoTracking().CountAsync(r => r.RiskLevelId != null && db.Set<GRC.Infrastructure.Data.Entities.RiskLevelLookup>().Any(l=>l.Id==r.RiskLevelId && l.Label=="Medium"), stoppingToken);
 var low = await db.Risks.AsNoTracking().CountAsync(r => r.RiskLevelId != null && db.Set<GRC.Infrastructure.Data.Entities.RiskLevelLookup>().Any(l=>l.Id==r.RiskLevelId && l.Label=="Low"), stoppingToken);
 var closed = await db.Risks.AsNoTracking().CountAsync(r => r.Status != null && (EF.Functions.Like(r.Status, "%closed%") || EF.Functions.Like(r.Status, "%kapal�%")), stoppingToken);
 var complianceRate = total ==0 ?100 : (int)Math.Round(100.0 * closed / total);

 var payload = new { total, critical, high, medium, low, complianceRate };
 var snapshot = new GRC.Infrastructure.Data.Entities.KpiSnapshot
 {
 SnapshotAt = DateTime.UtcNow,
 TotalRisks = total,
 CriticalCount = critical,
 HighCount = high,
 MediumCount = medium,
 LowCount = low,
 ComplianceRate = complianceRate,
 JsonPayload = JsonSerializer.Serialize(payload)
 };

 var repo = scope.ServiceProvider.GetRequiredService<GRC.Infrastructure.Data.Repositories.KpiSnapshotRepository>();
 await repo.InsertSnapshotAsync(snapshot);
 _logger.LogInformation("Kpi snapshot saved at {Time}", snapshot.SnapshotAt);
 }
 catch (Exception ex)
 {
 _logger.LogError(ex, "KpiSnapshotWorker error");
 }
 await Task.Delay(_period, stoppingToken);
 }
 }
 }
}
