using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using System.IO;

namespace GRC.Infrastructure.Data.Content
{
    public class GRCDbContextFactory : IDesignTimeDbContextFactory<GRCDbContext>
    {
        public GRCDbContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<GRCDbContext>();
            
            // Connection string'i d�zelt
            var connectionString = "Server=(localdb)\\mssqllocaldb;Database=GRCRiskManagement;Trusted_Connection=true;MultipleActiveResultSets=true";
            optionsBuilder.UseSqlServer(connectionString);

            return new GRCDbContext(optionsBuilder.Options);
        }
    }
}




