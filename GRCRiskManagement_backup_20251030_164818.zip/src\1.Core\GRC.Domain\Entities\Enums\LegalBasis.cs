﻿namespace GRC.Domain.Entities.Enums
{
    public enum LegalBasis
    {
        Consent = 1,
        Contract = 2,
        LegalObligation = 3,
        VitalInterests = 4,
        PublicTask = 5,
        LegitimateInterests = 6
    }
}


