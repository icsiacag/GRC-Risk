using System.Collections.Generic;

namespace GRC.Application.Contracts.DTOs.Categories
{
 public class HumanCapitalDetailsDto
 {
 public double? TalentRetentionMetrics { get; set; }
 public Dictionary<string,double>? DiversityIndices { get; set; }
 public List<object>? LinkedProcesses { get; set; }
 }
}