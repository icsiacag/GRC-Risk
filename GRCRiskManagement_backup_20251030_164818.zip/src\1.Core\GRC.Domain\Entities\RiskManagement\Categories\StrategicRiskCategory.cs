﻿using System;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.RiskManagement.Categories
{
 public class StrategicRiskCategory : RiskCategory
 {
 public string StrategicObjective { get; set; } = string.Empty;
 public StrategicRiskCategory() : base() { }
 public StrategicRiskCategory(string name, string description, string color) : base(name, description, color) { }
 }
}



