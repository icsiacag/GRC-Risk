﻿namespace GRC.Domain.Entities.Enums
{
    public enum RiskCategory
    {
        Strategic = 1,
        Operational = 2,
        Financial = 3,
        Compliance = 4,
        Reputational = 5,
        Technology = 6
    }
}


