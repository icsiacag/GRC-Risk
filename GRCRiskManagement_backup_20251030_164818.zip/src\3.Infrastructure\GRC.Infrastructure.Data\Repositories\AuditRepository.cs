﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using GRC.Domain.Entities.Audit;
using GRC.Domain.Entities.RiskManagement;
using GRC.Domain.Interfaces.Repositories;
using GRC.Infrastructure.Data.Content;

namespace GRC.Infrastructure.Data.Repositories;

// IDE0290: Birincil oluşturucu kullanıldı
public class AuditRepository(GRCDbContext context) : IAuditRepository
{
    private readonly DbSet<AuditPlan> _dbSet = context.Set<AuditPlan>();

    // IDE0270: Null denetimi kolaylaştırıldı
    public async Task<AuditPlan> GetPlanByIdAsync(int id, CancellationToken cancellationToken = default)
    {
        var entity = await _dbSet.FindAsync([id], cancellationToken);
        return entity ?? throw new KeyNotFoundException($"AuditPlan not found with id {id}");
    }

    public async Task<List<AuditPlan>> GetAllPlansAsync(CancellationToken cancellationToken = default)
        => await _dbSet.ToListAsync(cancellationToken);

    public async Task<AuditPlan> AddPlanAsync(AuditPlan plan, CancellationToken cancellationToken = default)
    {
        await _dbSet.AddAsync(plan, cancellationToken);
        await context.SaveChangesAsync(cancellationToken);
        return plan;
    }

    public async Task UpdatePlanAsync(AuditPlan plan, CancellationToken cancellationToken = default)
    {
        context.Entry(plan).State = EntityState.Modified;
        await context.SaveChangesAsync(cancellationToken);
    }

    public async Task DeletePlanAsync(AuditPlan plan, CancellationToken cancellationToken = default)
    {
        _dbSet.Remove(plan);
        await context.SaveChangesAsync(cancellationToken);
    }

    public async Task<AuditExecution> GetExecutionByIdAsync(int id, CancellationToken cancellationToken = default)
    {
        var entity = await context.Set<AuditExecution>().FindAsync([id], cancellationToken);
        return entity ?? throw new KeyNotFoundException($"AuditExecution not found with id {id}");
    }

    public async Task<List<AuditExecution>> GetExecutionsByPlanIdAsync(int planId, CancellationToken cancellationToken = default)
        => await context.Set<AuditExecution>().Where(e => e.AuditPlanId == planId).ToListAsync(cancellationToken);

    public async Task<AuditExecution> AddExecutionAsync(AuditExecution execution, CancellationToken cancellationToken = default)
    {
        await context.Set<AuditExecution>().AddAsync(execution, cancellationToken);
        await context.SaveChangesAsync(cancellationToken);
        return execution;
    }

    public async Task UpdateExecutionAsync(AuditExecution execution, CancellationToken cancellationToken = default)
    {
        context.Entry(execution).State = EntityState.Modified;
        await context.SaveChangesAsync(cancellationToken);
    }

    public async Task DeleteExecutionAsync(AuditExecution execution, CancellationToken cancellationToken = default)
    {
        context.Set<AuditExecution>().Remove(execution);
        await context.SaveChangesAsync(cancellationToken);
    }

    public async Task<AuditFinding> GetFindingByIdAsync(int id, CancellationToken cancellationToken = default)
    {
        var entity = await context.Set<AuditFinding>().FindAsync([id], cancellationToken);
        return entity ?? throw new KeyNotFoundException($"AuditFinding not found with id {id}");
    }

    public async Task<List<AuditFinding>> GetFindingsByExecutionIdAsync(int executionId, CancellationToken cancellationToken = default)
        => await context.Set<AuditFinding>().Where(f => f.AuditExecutionId == executionId).ToListAsync(cancellationToken);

    public async Task<AuditFinding> AddFindingAsync(AuditFinding finding, CancellationToken cancellationToken = default)
    {
        await context.Set<AuditFinding>().AddAsync(finding, cancellationToken);
        await context.SaveChangesAsync(cancellationToken);
        return finding;
    }

    public async Task UpdateFindingAsync(AuditFinding finding, CancellationToken cancellationToken = default)
    {
        context.Entry(finding).State = EntityState.Modified;
        await context.SaveChangesAsync(cancellationToken);
    }

    public async Task DeleteFindingAsync(AuditFinding finding, CancellationToken cancellationToken = default)
    {
        context.Set<AuditFinding>().Remove(finding);
        await context.SaveChangesAsync(cancellationToken);
    }

    public async Task<Risk> GetRiskByIdAsync(int id, CancellationToken cancellationToken = default)
    {
        var entity = await context.Set<Risk>().FindAsync([id], cancellationToken);
        return entity ?? throw new KeyNotFoundException($"Risk not found with id {id}");
    }

    public async Task<List<Risk>> GetAllRisksAsync(CancellationToken cancellationToken = default)
        => await context.Set<Risk>().ToListAsync(cancellationToken);

    public async Task<Risk> AddRiskAsync(Risk risk, CancellationToken cancellationToken = default)
    {
        await context.Set<Risk>().AddAsync(risk, cancellationToken);
        await context.SaveChangesAsync(cancellationToken);
        return risk;
    }

    public async Task UpdateRiskAsync(Risk risk, CancellationToken cancellationToken = default)
    {
        context.Entry(risk).State = EntityState.Modified;
        await context.SaveChangesAsync(cancellationToken);
    }

    public async Task DeleteRiskAsync(Risk risk, CancellationToken cancellationToken = default)
    {
        context.Set<Risk>().Remove(risk);
        await context.SaveChangesAsync(cancellationToken);
    }
}

public class RiskDto // veya ne ise sınıf adı
{
    public string Title { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string Likelihood { get; set; } = string.Empty;
    public string Impact { get; set; } = string.Empty;
    public string RiskLevel { get; set; } = string.Empty;
    public string Treatment { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public string Owner { get; set; } = string.Empty;
}

