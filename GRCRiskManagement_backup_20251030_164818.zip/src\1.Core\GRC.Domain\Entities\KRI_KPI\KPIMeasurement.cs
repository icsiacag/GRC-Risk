﻿using System;
using System.Collections.Generic;
using GRC.SharedKernel;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.KRI_KPI
{
    /// <summary>
    /// KPIMeasurement entity for GRC system
    /// Generated on: 2025-10-30 16:18:22
    /// </summary>
    public class KPIMeasurement : GRC.SharedKernel.Entities.BaseEntity
    {
        public Guid KPIId { get; set; }
        public DateTime MeasurementDate { get; set; }
        public decimal ActualValue { get; set; }
        public decimal TargetValue { get; set; }
        public decimal Variance { get; set; }
        public string Comments { get; set; }
        
        // Navigation properties and domain logic can be added here
        
        /// <summary>
        /// Validates the entity state
        /// </summary>
        
        /// <summary>
        /// Domain event when entity is created
        /// </summary>
        public void OnCreated()
        {
            CreatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
        
        /// <summary>
        /// Domain event when entity is updated
        /// </summary>
        public void OnUpdated()
        {
            UpdatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
    }
}



