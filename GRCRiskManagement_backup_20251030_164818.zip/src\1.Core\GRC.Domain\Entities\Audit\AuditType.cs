﻿using GRC.Domain.Common;
using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.Audit
{
    public enum AuditType
    {
        Internal,
        External,
        Compliance,
        Special
    }
}








