using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using GRC.Domain.Entities.Risk;
using GRC.Domain.Entities.Risk.Categories;

namespace GRC.Infrastructure.Data.Configurations
{
    public class RiskCategoryConfiguration : IEntityTypeConfiguration<RiskCategory>
    {
        public void Configure(EntityTypeBuilder<RiskCategory> builder)
        {
            builder.ToTable("RiskCategories");
            
            builder.HasKey(x => x.Id);
            
            builder.Property(x => x.Code)
                .IsRequired()
                .HasMaxLength(50);
            
            builder.Property(x => x.Name)
                .IsRequired()
                .HasMaxLength(200);
            
            builder.Property(x => x.Description)
                .HasMaxLength(2000);
            
            // Configure TPH discriminator
            builder.HasDiscriminator<string>("CategoryType")
                .HasValue<GRC.Domain.Entities.Risk.Categories.OperationalRiskCategory>("Operational")
                .HasValue<GRC.Domain.Entities.Risk.Categories.FinancialRiskCategory>("Financial")
                .HasValue<GRC.Domain.Entities.Risk.Categories.StrategicRiskCategory>("Strategic")
                .HasValue<GRC.Domain.Entities.Risk.Categories.ComplianceRiskCategory>("Compliance")
                .HasValue<GRC.Domain.Entities.Risk.Categories.ReputationalRiskCategory>("Reputational")
                .HasValue<GRC.Domain.Entities.Risk.Categories.ITCyberRiskCategory>("ITCyber")
                .HasValue<GRC.Domain.Entities.Risk.Categories.EnvironmentalRiskCategory>("Environmental")
                .HasValue<GRC.Domain.Entities.Risk.Categories.ProgrammaticProjectRiskCategory>("ProgrammaticProject")
                .HasValue<GRC.Domain.Entities.Risk.Categories.TechnologicRiskCategory>("Technologic")
                .HasValue<GRC.Domain.Entities.Risk.Categories.SafeguardingSecurityRiskCategory>("SafeguardingSecurity")
                .HasValue<GRC.Domain.Entities.Risk.Categories.ESGRiskCategory>("ESG")
                .HasValue<GRC.Domain.Entities.Risk.Categories.HumanCapitalRiskCategory>("HumanCapital")
                .HasValue<GRC.Domain.Entities.Risk.Categories.SupplyChainRiskCategory>("SupplyChain")
                .HasValue<GRC.Domain.Entities.Risk.Categories.LegalRegulatoryRiskCategory>("LegalRegulatory")
                .HasValue<GRC.Domain.Entities.Risk.Categories.GeopoliticalRiskCategory>("Geopolitical")
                .HasValue<GRC.Domain.Entities.Risk.Categories.InnovationRiskCategory>("Innovation");
            
            // Add owned/complex property mappings for subclass-specific fields
            // Use OwnsOne to keep subclass-specific scalars organized if desired.
            // Note: casting expression used because base type does not expose subclass typed navigation.
            builder.OwnsOne(x => ((ProgrammaticProjectRiskCategory)x), pprc =>
            {
                pprc.Property(p => p.BudgetVariances).HasColumnName("BudgetVariances");
                pprc.Property(p => p.ProjectComplexityScore).HasColumnName("ProjectComplexityScore");
                pprc.Property(p => p.MilestoneDependencies).HasColumnName("MilestoneDependencies");
                pprc.Property(p => p.CriticalPath).HasColumnName("CriticalPath");
            });
            
            builder.OwnsOne(x => ((ESGRiskCategory)x), esg =>
            {
                esg.Property(p => p.CarbonFootprint).HasColumnName("CarbonFootprint");
                esg.Property(p => p.DiversityScore).HasColumnName("DiversityScore");
                esg.Property(p => p.SustainabilityReportingStandards).HasColumnName("SustainabilityReportingStandards");
                esg.Property(p => p.ESGPillars).HasColumnName("ESGPillars");
            });
            
            // Repeat/extend OwnsOne mappings for other subclasses as needed. Examples:
            // builder.OwnsOne(x => ((TechnologicRiskCategory)x), tech => { tech.Property(t => t.ObsolescenceScore).HasColumnName("ObsolescenceScore"); });
            // builder.OwnsOne(x => ((SafeguardingSecurityRiskCategory)x), s => { s.Property(t => t.AssetProtectionLevels).HasColumnName("AssetProtectionLevels"); });
            
            // Self-referencing relationship
            builder.HasOne(x => x.Parent)
                .WithMany(x => x.Children)
                .HasForeignKey(x => x.ParentId)
                .OnDelete(DeleteBehavior.Restrict);
            
            // Index for performance
            builder.HasIndex(x => x.Code).IsUnique();
            builder.HasIndex(x => x.ParentId);
        }
    }
}


