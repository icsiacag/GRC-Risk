﻿namespace GRC.Domain.Entities.Enums
{
    public enum RetentionPeriod
    {
        OneYear = 1,
        ThreeYears = 3,
        FiveYears = 5,
        SevenYears = 7,
        TenYears = 10,
        Permanent = 99
    }
}


