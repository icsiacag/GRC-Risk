using GRC.Domain.Entities.RiskManagement;

namespace GRC.Domain.Interfaces.Services
{
    public interface IRiskCalculationService
    {
        decimal CalculateRiskScore(Risk risk);
        string DetermineRiskLevel(decimal score);
    }
}
