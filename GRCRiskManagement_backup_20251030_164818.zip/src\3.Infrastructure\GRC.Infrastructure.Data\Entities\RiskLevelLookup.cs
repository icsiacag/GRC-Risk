using System;

namespace GRC.Infrastructure.Data.Entities
{
 public class RiskLevelLookup
 {
 public int Id { get; set; }
 // Normalized label, e.g. Critical, High, Medium, Low
 public string Label { get; set; } = string.Empty;
 // Comma-separated keywords used to match free-text Risk.RiskLevel values
 public string Keywords { get; set; } = string.Empty;
 }
}
