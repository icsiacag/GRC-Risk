﻿using System;
using System.Collections.Generic;
using GRC.SharedKernel;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.ControlTesting
{
    /// <summary>
    /// ControlTest entity for GRC system
    /// Generated on: 2025-10-30 16:18:22
    /// </summary>
    public class ControlTest : GRC.SharedKernel.Entities.BaseEntity
    {
        public string TestNumber { get; set; }
        public Guid ControlId { get; set; }
        public TestType Type { get; set; }
        public TestFrequency Frequency { get; set; }
        public DateTime PlannedDate { get; set; }
        public DateTime? ExecutionDate { get; set; }
        public string TestProcedure { get; set; }
        public string TestExecutor { get; set; }
        public string TestReviewer { get; set; }
        public TestResult Result { get; set; }
        public string Findings { get; set; }
        public string Evidence { get; set; }
        public List<ControlDeficiency> Deficiencies { get; set; }
        
        // Navigation properties and domain logic can be added here
        
        /// <summary>
        /// Validates the entity state
        /// </summary>
        
        /// <summary>
        /// Domain event when entity is created
        /// </summary>
        public void OnCreated()
        {
            CreatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
        
        /// <summary>
        /// Domain event when entity is updated
        /// </summary>
        public void OnUpdated()
        {
            UpdatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
    }
}



