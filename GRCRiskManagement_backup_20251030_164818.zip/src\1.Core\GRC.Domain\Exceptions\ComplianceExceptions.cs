using System;

namespace GRC.Domain.Exceptions
{
    public class ComplianceNotFoundException : Exception
    {
        public ComplianceNotFoundException(string message) : base(message) { }
    }

    public class ComplianceValidationException : Exception
    {
        public ComplianceValidationException(string message) : base(message) { }
    }
}


