﻿namespace GRC.Domain.Entities.Enums
{
    public enum AssessmentType
    {
        Initial = 1,
        Annual = 2,
        Triggered = 3,
        Audit = 4
    }
}


