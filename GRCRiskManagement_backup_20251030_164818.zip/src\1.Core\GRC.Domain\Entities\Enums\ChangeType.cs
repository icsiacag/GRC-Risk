﻿namespace GRC.Domain.Entities.Enums
{
    public enum ChangeType
    {
        Minor = 1,
        Major = 2,
        Emergency = 3,
        Standard = 4
    }
}


