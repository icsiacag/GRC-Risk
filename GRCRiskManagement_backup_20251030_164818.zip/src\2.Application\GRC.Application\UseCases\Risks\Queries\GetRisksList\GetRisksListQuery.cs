using MediatR;
using GRC.Application.Common.Models;
using GRC.Application.Contracts.DTOs.Risks;

namespace GRC.Application.UseCases.Risks.Queries.GetRisksList
{
    public class GetRisksListQuery : IRequest<PaginatedList<RiskListItemDto>>
    {
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 10;
    }
}







