﻿namespace GRC.Domain.Entities.Enums
{
    public enum DeficiencyStatus
    {
        Open = 1,
        InProgress = 2,
        Resolved = 3,
        Closed = 4
    }
}


