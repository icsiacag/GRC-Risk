using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GRC.Infrastructure.Data.Content;
using GRC.Domain.Entities.Controls;

namespace GRC.Infrastructure.Data.Seeds
{
 public static class ControlUnitSeed
 {
 public static async Task EnsureSeedAsync(IServiceProvider services)
 {
 using var scope = services.CreateScope();
 var db = scope.ServiceProvider.GetRequiredService<GRCDbContext>();
 if (await db.Set<ControlUnit>().AnyAsync()) return;

 var units = new List<ControlUnit>
 {
 new ControlUnit { Name = "Head Office", Type = ControlUnitType.HeadOfficeUnit, Code = "HO" },
 new ControlUnit { Name = "Istanbul Branch", Type = ControlUnitType.Branch, Code = "BR-IST" },
 new ControlUnit { Name = "Ankara Branch", Type = ControlUnitType.Branch, Code = "BR-ANK" },
 new ControlUnit { Name = "Izmir Branch", Type = ControlUnitType.Branch, Code = "BR-IZM" },
 new ControlUnit { Name = "Regional Delegation Marmara", Type = ControlUnitType.Delegation, Code = "DEL-MAR" },
 new ControlUnit { Name = "Company: GRC Services Ltd.", Type = ControlUnitType.Company, Code = "COMP-GRC" }
 };

 await db.ControlUnits.AddRangeAsync(units);
 await db.SaveChangesAsync();
 }
 }
}
