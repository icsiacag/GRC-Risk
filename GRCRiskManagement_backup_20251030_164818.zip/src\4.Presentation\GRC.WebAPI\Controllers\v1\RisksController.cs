using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using GRC.Infrastructure.Data.Content;
using GRC.Domain.Entities.RiskManagement;
using GRC.Infrastructure.Data.Repositories;
using GRC.Application.Contracts.DTOs.Categories;
using System.Text.Json;
using System.Reflection;

namespace GRC.WebAPI.Controllers.v1
{
 [ApiController]
 [Route("api/v1/risks")]
 public class RisksController : ControllerBase
 {
 private readonly GRCDbContext _db;
 private readonly IRiskRepository _riskRepo;

 public RisksController(GRCDbContext db, IRiskRepository riskRepo)
 {
 _db = db;
 _riskRepo = riskRepo;
 }

 public class RiskCreateDto
 {
 public string Title { get; set; } = string.Empty;
 public string Description { get; set; } = string.Empty;
 public int CategoryId { get; set; }
 public string Unit { get; set; } = string.Empty;
 public string Level { get; set; } = string.Empty;
 public CategoryDto? CategoryDetails { get; set; }
 }

 [HttpPost]
 public async Task<IActionResult> Create([FromBody] RiskCreateDto dto)
 {
 // map category details into TPH entity if provided
 if (dto.CategoryDetails != null)
 {
 var cat = await _db.RiskCategories.FindAsync(dto.CategoryId);
 if (cat != null)
 {
 MapCategoryDtoToEntity(dto.CategoryDetails, cat);
 _db.RiskCategories.Update(cat);
 await _db.SaveChangesAsync();
 }
 }

 var risk = new Risk
 {
 Title = dto.Title,
 Description = dto.Description,
 CategoryId = dto.CategoryId,
 IdentifiedDate = System.DateTime.UtcNow,
 Owner = string.Empty,
 Status = "Open",
 Treatment = string.Empty,
 RiskLevel = dto.Level
 };

 await _riskRepo.AddAsync(risk);
 await _riskRepo.SaveChangesAsync();

 return CreatedAtAction(nameof(GetById), new { id = risk.Id }, new { id = risk.Id });
 }

 [HttpGet("{id}")]
 public async Task<IActionResult> GetById([FromRoute] int id)
 {
 var r = await _riskRepo.GetByIdWithDetailsAsync(id);
 if (r == null) return NotFound();
 return Ok(r);
 }

 private void MapCategoryDtoToEntity(CategoryDto dto, Domain.Entities.Risk.RiskCategory entity)
 {
 // Map strongly-typed sub DTOs
 try
 {
 if (dto.TechnologicDetails != null)
 {
 var t = dto.TechnologicDetails;
 if (t.TechStackVulnerabilities != null)
 {
 // tech stack vulnerabilities may be array or string; store as JSON string
 if (t.TechStackVulnerabilities is string s)
 {
 entity.GetType().GetProperty("TechStackVulnerabilities", BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase)?.SetValue(entity, s);
 }
 else
 {
 var json = JsonSerializer.Serialize(t.TechStackVulnerabilities);
 entity.GetType().GetProperty("TechStackVulnerabilities", BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase)?.SetValue(entity, json);
 }
 }
 // InnovationAdoptionRate
 var propAdopt = entity.GetType().GetProperty("InnovationAdoptionRate", BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase);
 if (propAdopt != null) propAdopt.SetValue(entity, t.InnovationAdoptionRate);
 }

 if (dto.ProgrammaticProjectDetails != null)
 {
 var p = dto.ProgrammaticProjectDetails;
 if (p.MilestoneDependencies != null)
 {
 entity.GetType().GetProperty("MilestoneDependencies", BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase)?.SetValue(entity, p.MilestoneDependencies);
 }
 if (p.BudgetVariances != null)
 {
 entity.GetType().GetProperty("BudgetVariances", BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase)?.SetValue(entity, p.BudgetVariances);
 }
 }

 if (dto.ESGDetails != null)
 {
 var e = dto.ESGDetails;
 if (e.ESGPillars != null)
 {
 var json = JsonSerializer.Serialize(e.ESGPillars);
 entity.GetType().GetProperty("ESGPillars", BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase)?.SetValue(entity, json);
 }
 if (e.SustainabilityReportingStandards != null)
 {
 var json = JsonSerializer.Serialize(e.SustainabilityReportingStandards);
 entity.GetType().GetProperty("SustainabilityReportingStandards", BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase)?.SetValue(entity, json);
 }
 }

 if (dto.HumanCapitalDetails != null)
 {
 var h = dto.HumanCapitalDetails;
 var propTR = entity.GetType().GetProperty("TalentRetentionMetrics", BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase);
 if (propTR != null) propTR.SetValue(entity, h.TalentRetentionMetrics);
 if (h.DiversityIndices != null)
 {
 var json = JsonSerializer.Serialize(h.DiversityIndices);
 entity.GetType().GetProperty("DiversityIndices", BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase)?.SetValue(entity, json);
 }
 }

 if (dto.SupplyChainDetails != null)
 {
 var s = dto.SupplyChainDetails;
 if (s.SupplierDependencies != null)
 {
 var json = JsonSerializer.Serialize(s.SupplierDependencies);
 entity.GetType().GetProperty("SupplierDependencies", BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase)?.SetValue(entity, json);
 }
 if (s.DisruptionScenarios != null)
 {
 var json = JsonSerializer.Serialize(s.DisruptionScenarios);
 entity.GetType().GetProperty("DisruptionScenarios", BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase)?.SetValue(entity, json);
 }
 }

 // Generic details dictionary: attempt to set any matching property
 if (dto.Details != null)
 {
 foreach (var kv in dto.Details)
 {
 var name = kv.Key;
 var val = kv.Value;
 var pi = entity.GetType().GetProperty(name, BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase);
 if (pi == null) continue;
 try
 {
 if (pi.PropertyType == typeof(string))
 {
 if (val == null) pi.SetValue(entity, null);
 else if (val is string) pi.SetValue(entity, (string)val);
 else pi.SetValue(entity, JsonSerializer.Serialize(val));
 }
 else
 {
 // try convert
 var converted = Convert.ChangeType(val, pi.PropertyType);
 pi.SetValue(entity, converted);
 }
 }
 catch { /* ignore individual mapping errors */ }
 }
 }
 }
 catch
 {
 // swallow mapping exceptions to avoid breaking create flow
 }
 }
 }
}
