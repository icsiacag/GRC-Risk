﻿using GRC.SharedKernel;

namespace GRC.Domain.Common
{
    // EntityBase wraps SharedKernel's EntityBase
    public abstract class EntityBase : GRC.SharedKernel.EntityBase
    {
    }
}
