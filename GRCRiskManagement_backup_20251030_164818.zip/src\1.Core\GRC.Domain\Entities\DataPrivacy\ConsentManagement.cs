﻿using System;
using System.Collections.Generic;
using GRC.SharedKernel;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.DataPrivacy
{
    /// <summary>
    /// ConsentManagement entity for GRC system
    /// Generated on: 2025-10-30 16:18:22
    /// </summary>
    public class ConsentManagement : GRC.SharedKernel.Entities.BaseEntity
    {
        public Guid DataSubjectId { get; set; }
        public string Purpose { get; set; }
        public bool ConsentGiven { get; set; }
        public DateTime ConsentDate { get; set; }
        public DateTime? WithdrawalDate { get; set; }
        public ConsentMethod Method { get; set; }
        public string ConsentText { get; set; }
        
        // Navigation properties and domain logic can be added here
        
        /// <summary>
        /// Validates the entity state
        /// </summary>
        
        /// <summary>
        /// Domain event when entity is created
        /// </summary>
        public void OnCreated()
        {
            CreatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
        
        /// <summary>
        /// Domain event when entity is updated
        /// </summary>
        public void OnUpdated()
        {
            UpdatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
    }
}



