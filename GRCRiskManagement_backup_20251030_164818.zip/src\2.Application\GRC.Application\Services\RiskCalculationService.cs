﻿namespace GRC.Application.Services
{
    public class RiskCalculationService
    {
        public string CalculateRiskLevel(int probability, int impact)
        {
            var RiskAssessmentScore = probability * impact;

            if (RiskAssessmentScore >= 16) return "Critical";
            if (RiskAssessmentScore >= 9) return "High";
            if (RiskAssessmentScore >= 4) return "Medium";
            return "Low";
        }

        public decimal CalculateRiskExposure(decimal probability, decimal impact)
        {
            return probability * impact;
        }
    }
}



