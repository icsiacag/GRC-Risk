﻿namespace GRC.Domain.Entities.Enums
{
    public enum ResponseStatus
    {
        Pending = 1,
        InProgress = 2,
        Completed = 3
    }
}


