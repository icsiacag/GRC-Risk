using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Identity;
using System.Threading.Tasks;

namespace GRC.WebAPI
{
 public static class DataSeeder
 {
 public static async Task SeedAsync(IServiceProvider services)
 {
 var userManager = services.GetRequiredService<UserManager<IdentityUser>>();
 var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();

 // Create default admin user if none exists
 var adminEmail = "admin@local";
 var admin = await userManager.FindByEmailAsync(adminEmail);
 if (admin == null)
 {
 admin = new IdentityUser { UserName = adminEmail, Email = adminEmail, EmailConfirmed = true };
 await userManager.CreateAsync(admin, "Admin123!");
 await userManager.AddToRoleAsync(admin, "Admin");
 }
 }
 }
}
