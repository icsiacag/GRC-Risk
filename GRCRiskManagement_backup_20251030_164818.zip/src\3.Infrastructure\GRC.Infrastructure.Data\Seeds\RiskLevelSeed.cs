using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Linq;

namespace GRC.Infrastructure.Data.Seeds
{
 public static class RiskLevelSeed
 {
 public static void EnsureSeed(IServiceProvider services)
 {
 using var scope = services.CreateScope();
 var db = scope.ServiceProvider.GetRequiredService<Content.GRCDbContext>();
 if (!db.Set<GRC.Infrastructure.Data.Entities.RiskLevelLookup>().Any())
 {
 db.Set<GRC.Infrastructure.Data.Entities.RiskLevelLookup>().AddRange(
 new GRC.Infrastructure.Data.Entities.RiskLevelLookup { Label = "Critical", Keywords = "critical,crit,kritik" },
 new GRC.Infrastructure.Data.Entities.RiskLevelLookup { Label = "High", Keywords = "high,yuksek,y�ksek" },
 new GRC.Infrastructure.Data.Entities.RiskLevelLookup { Label = "Medium", Keywords = "medium,med,orta" },
 new GRC.Infrastructure.Data.Entities.RiskLevelLookup { Label = "Low", Keywords = "low,dusuk,d���k" }
 );
 db.SaveChanges();
 }
 }
 }
