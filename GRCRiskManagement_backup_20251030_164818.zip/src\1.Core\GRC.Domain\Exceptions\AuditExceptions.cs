﻿namespace GRC.Domain.Exceptions;

public class AuditNotFoundException : Exception
{
    public AuditNotFoundException(string message) : base(message) { }
    
    public AuditNotFoundException(int auditId)
        : base($"Audit with ID {auditId} was not found.") { }
}

public class AuditValidationException : Exception
{
    public AuditValidationException(string message) : base(message) { }
    
    public AuditValidationException(string field, string error)
        : base($"Validation failed for {field}: {error}") { }
}

