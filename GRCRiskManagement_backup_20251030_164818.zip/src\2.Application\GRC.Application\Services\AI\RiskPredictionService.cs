using System.Threading.Tasks;
using System.Collections.Generic;
using Microsoft.ML;
using Microsoft.ML.Data;
using GRC.Domain.Entities.RiskManagement;
using System;

namespace GRC.Application.Services.AI
{
 public class RiskPredictionService
 {
 private readonly MLContext _mlContext;
 private ITransformer? _model;
 private readonly IModelPersistence? _persistence;

 public RiskPredictionService(IModelPersistence? persistence = null)
 {
 _mlContext = new MLContext(seed:0);
 _persistence = persistence;
 }

 /// <summary>
 /// Train model with extended feature engineering for production-quality predictions.
 /// Features: text featurization (TF-IDF), normalized numeric features, category one-hot encoding and temporal feature (days since identified).
 /// Label: InherentScore (float) � consider revising to a calibrated/normalized label for production.
 /// </summary>
 public async Task TrainModelAsync(List<RiskTrainingData> trainingData, string modelName = "risk_default")
 {
 var data = _mlContext.Data.LoadFromEnumerable(trainingData);

 // Feature pipeline: text -> TFIDF, category -> one-hot, normalize numerics, concat into Features
 var pipeline = _mlContext.Transforms.Text.FeaturizeText("TextFeatures", nameof(RiskTrainingData.Description))
 .Append(_mlContext.Transforms.Conversion.MapValueToKey("CategoryKey", nameof(RiskTrainingData.CategoryType)))
 .Append(_mlContext.Transforms.Categorical.OneHotEncoding("CategoryOneHot", "CategoryKey"))
 .Append(_mlContext.Transforms.NormalizeMeanVariance(nameof(RiskTrainingData.LikelihoodScore)))
 .Append(_mlContext.Transforms.NormalizeMeanVariance(nameof(RiskTrainingData.ImpactScore)))
 .Append(_mlContext.Transforms.NormalizeMeanVariance(nameof(RiskTrainingData.CategoryScore)))
 .Append(_mlContext.Transforms.NormalizeMeanVariance(nameof(RiskTrainingData.AppetiteScore)))
 .Append(_mlContext.Transforms.NormalizeMeanVariance(nameof(RiskTrainingData.CreatedDaysAgo)))
 .Append(_mlContext.Transforms.Concatenate("Features", "TextFeatures", nameof(RiskTrainingData.LikelihoodScore), nameof(RiskTrainingData.ImpactScore), nameof(RiskTrainingData.CategoryScore), nameof(RiskTrainingData.AppetiteScore), nameof(RiskTrainingData.CreatedDaysAgo), "CategoryOneHot"))
 // You can experiment with other trainers (FastTree, LightGbm, Sdca)
 .Append(_mlContext.Regression.Trainers.FastTree(labelColumnName: "Label", featureColumnName: "Features"));

 _model = pipeline.Fit(data);

 // persist model if persistence available
 if (_persistence != null)
 {
 using var ms = new System.IO.MemoryStream();
 _mlContext.Model.Save(_model, data.Schema, ms);
 ms.Position =0;
 await _persistence.SaveModelAsync(modelName, ms);
 }
 }

 public async Task<bool> TryLoadModelAsync(string modelName = "risk_default")
 {
 if (_persistence == null) return false;
 if (!await _persistence.ExistsAsync(modelName)) return false;
 var stream = await _persistence.LoadModelAsync(modelName);
 if (stream == null) return false;
 stream.Position =0;
 _model = _mlContext.Model.Load(stream, out var schema);
 return true;
 }

 public async Task<RiskPrediction> PredictAsync(GRC.Domain.Entities.RiskManagement.Risk risk)
 {
 if (_model == null)
 throw new System.InvalidOperationException("Model not trained or loaded");
 var engine = _mlContext.Model.CreatePredictionEngine<RiskTrainingData, RiskPredictionResult>(_model);
 var catScore = (float)(await risk.Category.CalculateRiskScoreAsync(risk)).InherentScore;
 var createdDaysAgo = (float)(DateTime.UtcNow - risk.IdentifiedDate).TotalDays;
 var input = new RiskTrainingData
 {
 Description = risk.Description,
 LikelihoodScore = risk.Likelihood?.Score ??0,
 ImpactScore = risk.Impact?.Score ??0,
 CategoryScore = catScore,
 AppetiteScore = risk.RiskAppetite != null ? (float)risk.RiskAppetite.ToleranceScore :0,
 CreatedDaysAgo = createdDaysAgo,
 CategoryType = risk.Category?.GetType().Name ?? string.Empty
 };
 var result = engine.Predict(input);
 return new RiskPrediction
 {
 PredictedScore = result.Score,
 Confidence = result.Confidence,
 RecommendedActions = await GenerateRecommendationsAsync(result.Score)
 };
 }

 private async Task<List<string>> GenerateRecommendationsAsync(float score)
 {
 return score switch
 {
 >=8 => new List<string>{"Immediate escalation required","Implement critical controls"},
 >=6 => new List<string>{"Review mitigation strategies","Increase monitoring"},
 >=4 => new List<string>{"Maintain current controls","Periodic review"},
 _ => new List<string>{"Accept risk","Document decision"}
 };
 }
 }

 public class RiskTrainingData
 {
 public string Description { get; set; } = string.Empty;
 public float LikelihoodScore { get; set; }
 public float ImpactScore { get; set; }
 public float CategoryScore { get; set; }
 public float AppetiteScore { get; set; }
 public float CreatedDaysAgo { get; set; }
 public string CategoryType { get; set; } = string.Empty;
 [ColumnName("Label")]
 public float InherentScore { get; set; }
 }

 public class RiskPredictionResult
 {
 [ColumnName("Score")]
 public float Score { get; set; }
 public float Confidence { get; set; }
 }

 public class RiskPrediction
 {
 public float PredictedScore { get; set; }
 public float Confidence { get; set; }
 public List<string> RecommendedActions { get; set; } = new();
 }
}
