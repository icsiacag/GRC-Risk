using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;
using GRC.Infrastructure.Data.Content;
using Microsoft.Extensions.Caching.Memory;
using GRC.WebAPI.DTOs;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Logging;
using Microsoft.ApplicationInsights;
using Microsoft.Extensions.Caching.Distributed;
using System.Text.Json;

namespace GRC.WebAPI.Controllers.v1
{
 [ApiController]
 [Route("api/v1/[controller]")]
 public class GovernanceController : ControllerBase
 {
 private readonly GRCDbContext _db;
 private readonly IDistributedCache _cache; // Use distributed cache for production scalability
 private readonly ILogger<GovernanceController> _logger;
 private readonly TelemetryClient _telemetry;
 private const string CacheKey = "governance_tree_v1";

 public GovernanceController(GRCDbContext db, IDistributedCache cache, ILogger<GovernanceController> logger, TelemetryClient telemetry)
 { _db = db; _cache = cache; _logger = logger; _telemetry = telemetry; }

 [HttpGet("tree")]
 [Authorize(Policy = "RequireActiveSubscription")] // require authenticated access with active subscription
 public async Task<IActionResult> GetTree()
 {
 var startTime = DateTime.UtcNow;
 var userId = User?.Identity?.Name ?? "anonymous";

 try
 {
 // try distributed cache first (Redis in production)
 var cachedData = await _cache.GetStringAsync(CacheKey);
 if (!string.IsNullOrEmpty(cachedData))
 {
 var cached = JsonSerializer.Deserialize<GovernanceNodeDto>(cachedData);
 _logger.LogInformation("Governance tree served from distributed cache for user {UserId}", userId);
 _telemetry.TrackMetric("GovernanceTree.CacheHit", 1);
 return Ok(cached);
 }

 var units = await _db.GovernanceUnits.OrderBy(u => u.SortOrder).ToListAsync();
 _telemetry.TrackMetric("GovernanceTree.UnitsFetched", units.Count);

 if (!units.Any())
 {
 _logger.LogWarning("No governance units found in database, using fallback for user {UserId}", userId);
 var fallback = new GovernanceNodeDto { Name = "T�rk K�z�lay Genel Kurulu", Type = "assembly" };
 fallback.Children.AddRange(new[] {
 new GovernanceNodeDto { Name = "Y�netim Kurulu ve Genel Ba�kanl�k", Type = "board" },
 new GovernanceNodeDto { Name = "Denetim Kurulu", Type = "committee" },
 new GovernanceNodeDto { Name = "Destek Hizmetleri Genel M�d�rl���", Type = "department" },
 new GovernanceNodeDto { Name = "Afet Y�netimi ve �klim De�i�ikli�i Genel M�d�rl���", Type = "department" },
 new GovernanceNodeDto { Name = "Toplumsal Hizmetler Genel M�d�rl���", Type = "department" },
 new GovernanceNodeDto { Name = "Finans ve Mali ��ler Genel M�d�rl���", Type = "department" },
 new GovernanceNodeDto { Name = "�leti�im ve Ba��� Y�netimi Genel M�d�rl���", Type = "department" },
 new GovernanceNodeDto { Name = "Uluslararas� ��ler ve G�� Hizmetleri Genel M�d�rl���", Type = "department" },
 new GovernanceNodeDto { Name = "Kan Hizmetleri Genel M�d�rl���", Type = "department" },
 new GovernanceNodeDto { Name = "Y�neti�im Ofisi Genel M�d�rl���", Type = "department" },
 new GovernanceNodeDto { Name = "Ta��nmaz Y�netimi Genel M�d�rl���", Type = "department" }
 });

 var fallbackJson = JsonSerializer.Serialize(fallback);
 await _cache.SetStringAsync(CacheKey, fallbackJson, new DistributedCacheEntryOptions
 {
 AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(15)
 });
 _telemetry.TrackMetric("GovernanceTree.FallbackUsed", 1);
 return Ok(fallback);
 }

 // map flat list to DTO tree
 var map = units.ToDictionary(u => u.Id, u => new GovernanceNodeDto { Id = u.Id, Name = u.Name, Type = u.Type });
 GovernanceNodeDto rootNode = new GovernanceNodeDto { Name = "T�rk K�z�lay Genel Kurulu", Type = "assembly" };

 foreach (var u in units)
 {
 var node = map[u.Id];
 if (u.ParentId.HasValue && map.ContainsKey(u.ParentId.Value)) map[u.ParentId.Value].Children.Add(node);
 else rootNode.Children.Add(node);
 }

 // cache result using distributed cache (Redis in production)
 var jsonData = JsonSerializer.Serialize(rootNode);
 await _cache.SetStringAsync(CacheKey, jsonData, new DistributedCacheEntryOptions
 {
 AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(15)
 });

 var duration = DateTime.UtcNow - startTime;
 _logger.LogInformation("Governance tree built and cached in {Duration}ms for user {UserId}", duration.TotalMilliseconds, userId);
 _telemetry.TrackMetric("GovernanceTree.BuildDuration", duration.TotalMilliseconds);
 _telemetry.TrackMetric("GovernanceTree.NodesBuilt", rootNode.Children.Count);

 return Ok(rootNode);
 }
 catch (Exception ex)
 {
 _logger.LogError(ex, "Error retrieving governance tree for user {UserId}", userId);
 _telemetry.TrackException(ex);
 return StatusCode(500, "Internal server error");
 }
 }
