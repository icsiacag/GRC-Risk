using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using GRC.Infrastructure.Data.Content;
using GRC.Domain.Entities.Billing;

namespace GRC.Infrastructure.Identity.Services
{
 public class UserSubscriptionService : IUserSubscriptionService
 {
 private readonly GRCDbContext _db;
 private readonly ILogger<UserSubscriptionService> _logger;

 public UserSubscriptionService(GRCDbContext db, ILogger<UserSubscriptionService> logger)
 {
 _db = db;
 _logger = logger;
 }

 public async Task<UserSubscription?> GetActiveSubscriptionAsync(string userId)
 {
 if (string.IsNullOrWhiteSpace(userId)) return null;
 return await _db.UserSubscriptions
 .Where(s => s.UserId == userId && s.IsActive)
 .OrderByDescending(s => s.StartDate)
 .FirstOrDefaultAsync();
 }

 public async Task<UserSubscription> CreateSubscriptionAsync(string userId, int planId, int durationMonths)
 {
 if (string.IsNullOrWhiteSpace(userId)) throw new ArgumentException("userId is required", nameof(userId));
 var plan = await _db.MembershipPlans.FindAsync(planId);
 if (plan == null) throw new ArgumentException($"Plan {planId} not found", nameof(planId));
 if (durationMonths <=0) throw new ArgumentException("durationMonths must be positive", nameof(durationMonths));

 var sub = new UserSubscription
 {
 UserId = userId,
 PlanId = planId,
 StartDate = DateTime.UtcNow,
 EndDate = DateTime.UtcNow.AddMonths(durationMonths),
 IsActive = true,
 Status = "Active"
 };
 _db.UserSubscriptions.Add(sub);
 await _db.SaveChangesAsync();
 _logger.LogInformation("Created subscription {Id} for user {UserId}", sub.Id, userId);
 return sub;
 }

 public async Task<bool> CancelSubscriptionAsync(int subscriptionId, string userId)
 {
 var sub = await _db.UserSubscriptions.FindAsync(subscriptionId);
 if (sub == null) return false;
 if (!string.Equals(sub.UserId, userId, StringComparison.OrdinalIgnoreCase)) return false;
 sub.IsActive = false;
 sub.Status = "Cancelled";
 sub.EndDate = DateTime.UtcNow;
 await _db.SaveChangesAsync();
 _logger.LogInformation("Cancelled subscription {Id} for user {UserId}", subscriptionId, userId);
 return true;
 }
 }
}
