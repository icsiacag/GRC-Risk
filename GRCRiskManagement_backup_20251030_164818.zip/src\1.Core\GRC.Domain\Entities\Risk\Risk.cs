﻿using System.Collections.Generic;
using System.Threading.Tasks;
using GRC.SharedKernel;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.Risk
{
 /// <summary>
 /// Enhanced risk entity with polymorphic category references
 /// </summary>
 public class Risk : AuditableEntity<int>
 {
 public string Title { get; set; } = string.Empty;
 public string Description { get; set; } = string.Empty;

 // Polymorphic category reference
 public int CategoryId { get; set; }
 public RiskCategory Category { get; set; } = null!;

 // Risk scoring
 public int LikelihoodId { get; set; }
 public Probability Likelihood { get; set; } = null!;

 public int ImpactId { get; set; }
 public Impact Impact { get; set; } = null!;

 public decimal InherentScore { get; set; }
 public decimal ResidualScore { get; set; }
 public GRC.Domain.Enums.RiskLevel Level { get; set; }

 // Risk appetite compliance
 public bool AppetiteCompliance { get; set; }
 public int? RiskAppetiteId { get; set; }
 public GRC.Domain.ValueObjects.RiskAppetite? RiskAppetite { get; set; }

 // Relationships
 public List<GRC.Domain.Entities.RiskManagement.Control> Controls { get; set; } = new();
 public List<GRC.Domain.Entities.RiskManagement.Mitigation> Mitigations { get; set; } = new();
 public List<GRC.Domain.Entities.RiskManagement.RootCause> RootCauses { get; set; } = new();

 // Project-specific (for ProgrammaticProjectRiskCategory)
 public string? ProjectId { get; set; }

 // Methods
 public async Task<GRC.Domain.Entities.Risk.RiskScore> CalculateInherentScoreAsync()
 {
 // Delegate to category-specific calculation
 return await Category.CalculateRiskScoreAsync(this);
 }

 public async Task<bool> EscalateBasedOnCategoryAsync()
 {
 var score = await CalculateInherentScoreAsync();
 if (score.InherentScore >=8)
 {
 // Trigger escalation workflow (placeholder)
 return true;
 }
 return false;
 }

 public void UpdateRiskLevel()
 {
 Level = InherentScore switch
 {
 <3 => GRC.Domain.Enums.RiskLevel.Low,
 <6 => GRC.Domain.Enums.RiskLevel.Medium,
 <9 => GRC.Domain.Enums.RiskLevel.High,
 _ => GRC.Domain.Enums.RiskLevel.Critical
 };
 }
 }

 public class Probability : AuditableEntity<int>
 {
 public string Name { get; set; } = string.Empty;
 public int Score { get; set; } //1-5
 }

 public class Impact : AuditableEntity<int>
 {
 public string Name { get; set; } = string.Empty;
 public int Score { get; set; } //1-5
 }
}



