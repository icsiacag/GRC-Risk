﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GRC.Domain.Entities.DataPrivacy;

using GRC.Domain.Interfaces;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Interfaces
{
    /// <summary>
    /// Repository interface for DataProcessingActivity
    /// </summary>
    public interface IDataProcessingActivityRepository : IGenericRepository<DataProcessingActivity>
    {
        Task<IEnumerable<DataProcessingActivity>> GetActiveAsync();
        Task<DataProcessingActivity> GetByCodeAsync(string code);
        Task<IEnumerable<DataProcessingActivity>> SearchAsync(string searchTerm);
        Task<bool> ExistsAsync(Guid id);
    }
}




