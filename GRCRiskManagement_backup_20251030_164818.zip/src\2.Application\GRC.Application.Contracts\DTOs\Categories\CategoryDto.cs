using System.Collections.Generic;

namespace GRC.Application.Contracts.DTOs.Categories
{
 public class CategoryDto
 {
 public int Id { get; set; }
 public string Name { get; set; } = string.Empty;
 public string Description { get; set; } = string.Empty;
 public string Color { get; set; } = string.Empty;
 public string CategoryType { get; set; } = string.Empty;
 public string? MetadataJson { get; set; }
 public Dictionary<string, object?> Details { get; set; } = new();
 
 // Strongly-typed detail DTOs
 public TechnologicDetailsDto? TechnologicDetails { get; set; }
 public ProgrammaticProjectDetailsDto? ProgrammaticProjectDetails { get; set; }
 public ESGDetailsDto? ESGDetails { get; set; }
 public HumanCapitalDetailsDto? HumanCapitalDetails { get; set; }
 public SupplyChainDetailsDto? SupplyChainDetails { get; set; }
 }
}
