using System;

namespace GRC.Infrastructure.Data.Entities
{
 public class UserSession
 {
 public string Id { get; set; } = Guid.NewGuid().ToString();
 public string? UserId { get; set; }
 public DateTime LoginTime { get; set; }
 public DateTime? LogoutTime { get; set; }
 public string? IpAddress { get; set; }
 public string? UserAgent { get; set; }
 public bool IsActive { get; set; } = true;
 }
}
