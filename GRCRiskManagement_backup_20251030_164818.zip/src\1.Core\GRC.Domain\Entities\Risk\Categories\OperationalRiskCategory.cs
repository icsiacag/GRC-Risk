﻿using System;
using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.Risk.Categories
{
 public class OperationalRiskCategory : GRC.Domain.Entities.RiskManagement.RiskCategory
 {
 public OperationalRiskCategory() : base() { }
 public OperationalRiskCategory(string code, string name, string description) : base()
 {
 Code = code; Name = name; Description = description;
 }
 }
}




