using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using GRC.Domain.Entities.Audit;

namespace GRC.Domain.Interfaces.Repositories
{
    public interface IAuditRepository
    {
        Task<AuditPlan> GetPlanByIdAsync(int id, CancellationToken cancellationToken = default);
        Task<List<AuditPlan>> GetAllPlansAsync(CancellationToken cancellationToken = default);
        Task<AuditPlan> AddPlanAsync(AuditPlan plan, CancellationToken cancellationToken = default);
        Task UpdatePlanAsync(AuditPlan plan, CancellationToken cancellationToken = default);
        Task DeletePlanAsync(AuditPlan plan, CancellationToken cancellationToken = default);
        
        Task<AuditExecution> GetExecutionByIdAsync(int id, CancellationToken cancellationToken = default);
        Task<List<AuditExecution>> GetExecutionsByPlanIdAsync(int planId, CancellationToken cancellationToken = default);
        Task<AuditExecution> AddExecutionAsync(AuditExecution execution, CancellationToken cancellationToken = default);
        Task UpdateExecutionAsync(AuditExecution execution, CancellationToken cancellationToken = default);
        Task DeleteExecutionAsync(AuditExecution execution, CancellationToken cancellationToken = default);
        
        Task<AuditFinding> GetFindingByIdAsync(int id, CancellationToken cancellationToken = default);
        Task<List<AuditFinding>> GetFindingsByExecutionIdAsync(int executionId, CancellationToken cancellationToken = default);
        Task<AuditFinding> AddFindingAsync(AuditFinding finding, CancellationToken cancellationToken = default);
        Task UpdateFindingAsync(AuditFinding finding, CancellationToken cancellationToken = default);
        Task DeleteFindingAsync(AuditFinding finding, CancellationToken cancellationToken = default);
    }
}


