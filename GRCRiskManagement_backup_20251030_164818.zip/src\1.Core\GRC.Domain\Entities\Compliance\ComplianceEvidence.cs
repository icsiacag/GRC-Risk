﻿using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.Compliance
{
    public class ComplianceEvidence
    {
        public int Id { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public DateTime CollectedDate { get; set; }
        public string CollectedBy { get; set; } = string.Empty;
    }
}



