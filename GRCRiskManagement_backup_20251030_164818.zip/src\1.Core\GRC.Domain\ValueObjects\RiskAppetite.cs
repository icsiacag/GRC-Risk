﻿namespace GRC.Domain.ValueObjects
{
    public enum RiskAppetite
    {
        Low = 1,
        Medium = 2,
        High = 3
    }
}

