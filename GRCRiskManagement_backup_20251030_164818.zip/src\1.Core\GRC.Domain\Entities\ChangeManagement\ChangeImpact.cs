﻿using System;
using System.Collections.Generic;
using GRC.SharedKernel;

using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.ChangeManagement
{
    /// <summary>
    /// ChangeImpact entity for GRC system
    /// Generated on: 2025-10-30 16:18:22
    /// </summary>
    public class ChangeImpact : GRC.SharedKernel.Entities.BaseEntity
    {
        public Guid ChangeRequestId { get; set; }
        public ImpactArea Area { get; set; }
        public ImpactLevel Level { get; set; }
        public string Description { get; set; }
        public string MitigationPlan { get; set; }
        
        // Navigation properties and domain logic can be added here
        
        /// <summary>
        /// Validates the entity state
        /// </summary>
        
        /// <summary>
        /// Domain event when entity is created
        /// </summary>
        public void OnCreated()
        {
            CreatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
        
        /// <summary>
        /// Domain event when entity is updated
        /// </summary>
        public void OnUpdated()
        {
            UpdatedDate = DateTime.UtcNow;
            // Add domain event logic
        }
    }
}



