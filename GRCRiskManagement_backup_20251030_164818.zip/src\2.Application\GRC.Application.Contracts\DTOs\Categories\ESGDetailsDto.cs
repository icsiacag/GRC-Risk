using System.Collections.Generic;

namespace GRC.Application.Contracts.DTOs.Categories
{
 public class ESGDetailsDto
 {
 public Dictionary<string, decimal>? ESGPillars { get; set; }
 public List<string>? SustainabilityReportingStandards { get; set; }
 public decimal? CarbonFootprint { get; set; }
 public int? DiversityScore { get; set; }
 public int? GovernanceScore { get; set; }
 }
}