﻿namespace GRC.Application.Contracts.DTOs.Reports;

public class ReportDto
{
    public Guid Id { get; set; }
    public string Title { get; set; } = string.Empty;
    public DateTime GeneratedDate { get; set; }
}


