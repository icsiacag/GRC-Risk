﻿namespace GRC.Domain.Entities.Enums
{
    public enum ProcessingPurpose
    {
        Marketing = 1,
        Analytics = 2,
        Operations = 3,
        Legal = 4,
        Research = 5
    }
}


