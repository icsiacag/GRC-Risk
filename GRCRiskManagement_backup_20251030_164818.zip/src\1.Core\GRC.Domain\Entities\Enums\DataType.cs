﻿namespace GRC.Domain.Entities.Enums
{
    public enum DataType
    {
        Personal = 1,
        Sensitive = 2,
        Financial = 3,
        Health = 4,
        Proprietary = 5
    }
}


