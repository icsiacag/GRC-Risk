using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using GRC.Infrastructure.Data.Content;
using GRC.Infrastructure.Data.Entities;
using System.Threading.Tasks;

namespace GRC.Infrastructure.Identity.Services
{
 public class UserSessionService : IUserSessionService
 {
 private readonly GRCDbContext _context;
 private readonly ILogger<UserSessionService> _logger;

 public UserSessionService(GRCDbContext context, ILogger<UserSessionService> logger)
 {
 _context = context;
 _logger = logger;
 }

 public async Task TrackUserSessionAsync(string userId, string ipAddress, string userAgent)
 {
 var session = new UserSession
 {
 UserId = userId,
 LoginTime = System.DateTime.UtcNow,
 IpAddress = ipAddress,
 UserAgent = userAgent,
 IsActive = true
 };

 _context.Add(session);
 await _context.SaveChangesAsync();
 _logger.LogDebug("Tracked session {SessionId} for user {UserId}", session.Id, userId);
 }

 public async Task EndUserSessionAsync(string sessionId)
 {
 var session = await _context.Set<UserSession>().FindAsync(sessionId);
 if (session != null && session.IsActive)
 {
 session.IsActive = false;
 session.LogoutTime = System.DateTime.UtcNow;
 await _context.SaveChangesAsync();
 _logger.LogDebug("Ended session {SessionId}", sessionId);
 }
 }

 public async Task CleanupExpiredSessionsAsync()
 {
 var expired = await _context.Set<UserSession>()
 .Where(s => s.IsActive && s.LoginTime < System.DateTime.UtcNow.AddDays(-30))
 .ToListAsync();
 foreach (var s in expired)
 {
 s.IsActive = false;
 s.LogoutTime = System.DateTime.UtcNow;
 }
 await _context.SaveChangesAsync();
 _logger.LogInformation("Cleaned up {Count} expired sessions", expired.Count);
 }
 }
}
