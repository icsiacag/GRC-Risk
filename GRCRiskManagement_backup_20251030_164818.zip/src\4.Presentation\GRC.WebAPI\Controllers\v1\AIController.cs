using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using GRC.Application.Services.AI;
using GRC.Infrastructure.Data.Content;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace GRC.WebAPI.Controllers.v1
{
 [ApiController]
 [Route("api/v1/ai")]
 public class AIController : ControllerBase
 {
 private readonly RiskPredictionService _prediction;
 private readonly GRCDbContext _db;
 public AIController(RiskPredictionService prediction, GRCDbContext db) { _prediction = prediction; _db = db; }

 [HttpPost("train")]
 public async Task<IActionResult> Train([FromQuery] string modelName = "risk_default")
 {
 var risks = await _db.Risks.Include(r => r.Likelihood).Include(r => r.Impact).Include(r => r.Category).Take(2000).ToListAsync();
 var training = new System.Collections.Generic.List<RiskTrainingData>();
 foreach (var r in risks)
 {
 var catScore = (float)(await r.Category.CalculateRiskScoreAsync(r)).InherentScore;
 training.Add(new RiskTrainingData { Description = r.Description, LikelihoodScore = r.Likelihood.Score, ImpactScore = r.Impact.Score, CategoryScore = catScore, AppetiteScore = r.RiskAppetite?.ToleranceScore ??0, InherentScore = (float)r.InherentScore });
 }
 await _prediction.TrainModelAsync(training, modelName);
 return Ok("Model trained and persisted (demo)");
 }

 [HttpGet("load/{modelName}")]
 public async Task<IActionResult> Load([FromRoute] string modelName)
 {
 var ok = await _prediction.TryLoadModelAsync(modelName);
 if (!ok) return NotFound();
 return Ok("Model loaded");
 }
 }
}
