using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using GRC.Infrastructure.Data.Content;
using Microsoft.EntityFrameworkCore;
using GRC.Application.Contracts.DTOs.Categories;
using AutoMapper;
using System.Linq;

namespace GRC.WebAPI.Controllers.v1
{
 [ApiController]
 [Route("api/v1/categories")]
 public class CategoriesController : ControllerBase
 {
 private readonly GRCDbContext _db;
 private readonly IMapper _mapper;
 public CategoriesController(GRCDbContext db, IMapper mapper) { _db = db; _mapper = mapper; }

 [HttpGet]
 public async Task<IActionResult> GetAll()
 {
 var cats = await _db.RiskCategories.AsNoTracking().ToListAsync();
 var dto = cats.Select(c => _mapper.Map<CategoryDto>(c));
 return Ok(dto);
 }
 }
}
