using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GRC.Infrastructure.Data.Migrations
{
 public partial class AddRiskLevelIdToRisks : Migration
 {
 protected override void Up(MigrationBuilder migrationBuilder)
 {
 migrationBuilder.AddColumn<int>(
 name: "RiskLevelId",
 table: "Risks",
 type: "int",
 nullable: true);

 migrationBuilder.CreateIndex(
 name: "IX_Risks_RiskLevelId",
 table: "Risks",
 column: "RiskLevelId");

 migrationBuilder.AddForeignKey(
 name: "FK_Risks_RiskLevelLookup_RiskLevelId",
 table: "Risks",
 column: "RiskLevelId",
 principalTable: "RiskLevelLookup",
 principalColumn: "Id",
 onDelete: ReferentialAction.Restrict);
 }

 protected override void Down(MigrationBuilder migrationBuilder)
 {
 migrationBuilder.DropForeignKey(
 name: "FK_Risks_RiskLevelLookup_RiskLevelId",
 table: "Risks");

 migrationBuilder.DropIndex(
 name: "IX_Risks_RiskLevelId",
 table: "Risks");

 migrationBuilder.DropColumn(
 name: "RiskLevelId",
 table: "Risks");
 }
 }
}
