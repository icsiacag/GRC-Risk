﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using GRC.Domain.Entities.RiskManagement;
using GRC.Infrastructure.Data.Content;
using GRC.Domain.Entities.RiskManagement.Categories;

namespace GRC.Infrastructure.Data.Seeds
{
    /// <summary>
    /// Seed data for risk categories (expanded subclasses)
    /// </summary>
    public static class RiskCategorySeed
    {
        public static async Task SeedAsync(GRCDbContext context)
        {
            if (await context.RiskCategories.AnyAsync())
                return; // Already seeded

            var categories = new List<RiskCategory>
            {
                new StrategicRiskCategory("Strategic Risks","Risks that affect the organization's strategic objectives and long-term goals","#dc3545"),
                RiskCategory.CreateBase("Operational Risks", "Risks arising from internal processes, people, and systems", "#fd7e14"),
                RiskCategory.CreateBase("Financial Risks", "Risks related to financial losses, market changes, and credit", "#ffc107"),
                RiskCategory.CreateBase("Compliance Risks", "Risks of non-compliance with laws, regulations, and policies", "#20c997"),
                new ReputationalRiskCategory("Reputational Risks","Risks that could damage the organization's reputation","#17a2b8") { MonitoringKeywords = "brand,media,trust" },
                new TechnologicRiskCategory("Technology Risks","Risks related to IT systems, cybersecurity, and data","#6610f2") { TechDomain = "Infrastructure", RequiresPenTest = true },
                new ESGRiskCategory("Environmental, Social & Governance","Risks across environmental, social and governance domains","#28a745") { EnvironmentalFocus = true, SocialFocus = true, GovernanceFocus = true },
                new HumanCapitalRiskCategory("Human Resources Risks","Risks related to workforce, talent, and employee relations","#6c757d") { RequiresTrainingPrograms = true }
            };

            // Set audit fields
            foreach (var category in categories)
            {
                // Ensure created metadata exists
                category.SetMetadata(category.MetadataJson ?? string.Empty);
                category.SetCreatedBy("System");
            }

            await context.RiskCategories.AddRangeAsync(categories);
            await context.SaveChangesAsync();
        }
    }
}



