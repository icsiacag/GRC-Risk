using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GRC.Infrastructure.Data.Migrations
{
 public partial class AddRiskLevelLookup : Migration
 {
 protected override void Up(MigrationBuilder migrationBuilder)
 {
 migrationBuilder.CreateTable(
 name: "RiskLevelLookup",
 columns: table => new
 {
 Id = table.Column<int>(type: "int", nullable: false)
 .Annotation("SqlServer:Identity", "1,1"),
 Label = table.Column<string>(type: "nvarchar(100)", maxLength:100, nullable: false),
 Keywords = table.Column<string>(type: "nvarchar(1000)", maxLength:1000, nullable: true)
 },
 constraints: table =>
 {
 table.PrimaryKey("PK_RiskLevelLookup", x => x.Id);
 });

 // seed common levels
 migrationBuilder.InsertData(
 table: "RiskLevelLookup",
 columns: new[] { "Label", "Keywords" },
 values: new object[,]
 {
 { "Critical", "critical,crit,kritik" },
 { "High", "high,yuksek,y�ksek" },
 { "Medium", "medium,med,orta" },
 { "Low", "low,dusuk,d���k" }
 });
 }

 protected override void Down(MigrationBuilder migrationBuilder)
 {
 migrationBuilder.DropTable(
 name: "RiskLevelLookup");
 }
 }
}
