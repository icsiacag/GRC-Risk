﻿namespace GRC.Domain.Entities.Enums
{
    public enum PIAStatus
    {
        NotStarted = 1,
        InProgress = 2,
        Completed = 3,
        Approved = 4
    }
}


