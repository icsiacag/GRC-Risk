﻿namespace GRC.Application.UseCases.Risks.Queries.GetRiskById
{
    public class RiskDetailDto
    {
        public int Id { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public int Probability { get; set; }
        public int Impact { get; set; }
    }
}


