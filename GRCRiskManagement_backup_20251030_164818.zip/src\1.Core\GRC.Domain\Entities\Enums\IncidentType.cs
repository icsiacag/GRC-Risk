﻿namespace GRC.Domain.Entities.Enums
{
    public enum IncidentType
    {
        Security = 1,
        DataBreach = 2,
        SystemFailure = 3,
        Operational = 4,
        Compliance = 5
    }
}


