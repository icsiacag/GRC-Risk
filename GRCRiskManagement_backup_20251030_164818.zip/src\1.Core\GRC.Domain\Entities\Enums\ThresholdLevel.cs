﻿namespace GRC.Domain.Entities.Enums
{
    public enum ThresholdLevel
    {
        Green = 1,
        Yellow = 2,
        Orange = 3,
        Red = 4
    }
}


