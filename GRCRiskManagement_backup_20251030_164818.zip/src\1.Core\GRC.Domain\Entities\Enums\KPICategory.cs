﻿namespace GRC.Domain.Entities.Enums
{
    public enum KPICategory
    {
        Financial = 1,
        Operational = 2,
        Customer = 3,
        Process = 4,
        Compliance = 5
    }
}


