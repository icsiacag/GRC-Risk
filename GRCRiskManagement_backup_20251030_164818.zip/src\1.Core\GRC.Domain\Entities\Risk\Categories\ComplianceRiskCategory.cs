﻿using System;
using GRC.Domain.Entities.Enums;
using GRC.SharedKernel.Entities;
namespace GRC.Domain.Entities.Risk.Categories
{
 public class ComplianceRiskCategory : GRC.Domain.Entities.RiskManagement.RiskCategory
 {
 public string? RegulatoryReferences { get; set; }
 public ComplianceRiskCategory() : base() { }
 }
}




